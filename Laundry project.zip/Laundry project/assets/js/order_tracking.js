/**
 * Live order tracking map (customer Order Details + public QR track page).
 *
 * Expects the page to provide a #trackingMap div plus a global TRACK_CONFIG:
 *   TRACK_CONFIG = {
 *       apiUrl:   '../../php/api/tracking.php',   // endpoint (page-relative)
 *       orderId:  12,                             // omit + use token instead
 *       token:    'abc...',                       // public QR token (optional)
 *       pollMs:   5000,                           // refresh interval
 *       statusEl: 'trackStatus'                   // id of an optional status line
 *   };
 *
 * Renders: station pin, pickup pin, live courier marker and the trail
 * polyline. Polls the API so the courier marker MOVES in real time.
 */
(function () {
    'use strict';

    var cfg = window.TRACK_CONFIG || {};
    if (!cfg.apiUrl || typeof L === 'undefined') return;
    var mapEl = document.getElementById('trackingMap');
    if (!mapEl) return;

    var KAMPALA = [0.3136, 32.5811];
    var map, stationPin, pickupPin, courierPin, accuracyCircle, trailLine;
    var fitted = false;

    try {
        map = L.map('trackingMap').setView(KAMPALA, 12);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap'
        }).addTo(map);
    } catch (e) {
        var st = document.getElementById(cfg.statusEl || 'trackStatus');
        if (st) st.innerHTML = '<i class="fas fa-exclamation-triangle text-danger me-1"></i>Map could not load - check your internet connection.';
        return;
    }

    function setStatus(html) {
        var el = document.getElementById(cfg.statusEl || 'trackStatus');
        if (el) el.innerHTML = html;
    }

    function divIcon(bg, fa, size) {
        size = size || 30;
        return L.divIcon({
            className: 'track-pin',
            html: '<div style="background:' + bg + ';border:3px solid #fff;border-radius:50%;width:' + size + 'px;height:' + size + 'px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.35);"><i class="fas ' + fa + '" style="color:#fff;font-size:' + Math.round(size * 0.42) + 'px;"></i></div>',
            iconSize: [size, size],
            iconAnchor: [size / 2, size / 2]
        });
    }

    function buildQuery() {
        var q = [];
        if (cfg.orderId) q.push('order_id=' + encodeURIComponent(cfg.orderId));
        if (cfg.token) q.push('token=' + encodeURIComponent(cfg.token));
        return q.join('&');
    }

    function renderStatic(data) {
        if (data.station && !stationPin) {
            stationPin = L.marker([data.station.lat, data.station.lng], {
                icon: divIcon('#0077b6', 'fa-store', 30),
                zIndexOffset: -100
            }).addTo(map).bindPopup('<strong>' + (data.order.business_name || 'Laundry station') + '</strong><br><small>Station</small>');
        }
        if (data.pickup && !pickupPin) {
            pickupPin = L.marker([data.pickup.lat, data.pickup.lng], {
                icon: divIcon('#6f42c1', 'fa-house', 28),
                zIndexOffset: -100
            }).addTo(map).bindPopup('<strong>Pickup point</strong><br><small>' + (data.pickup.name || '') + '</small>');
        }
    }

    function renderLive(data) {
        var pos = [data.position.lat, data.position.lng];
        if (courierPin) {
            courierPin.setLatLng(pos);
        } else {
            courierPin = L.marker(pos, {
                icon: divIcon('#dc3545', 'fa-truck-fast', 34),
                zIndexOffset: 500
            }).addTo(map);
            var who = data.order.driver_name ? 'Driver: ' + data.order.driver_name : 'Courier';
            var phone = data.order.driver_phone
                ? '<br><a href="tel:' + String(data.order.driver_phone).replace(/[^\d+]/g, '') + '"><i class="fas fa-phone me-1"></i>' + data.order.driver_phone + '</a>'
                : '';
            courierPin.bindPopup('<strong>' + who + '</strong><br><small>Live location</small>' + phone);
        }

        if (data.position.accuracy && data.position.accuracy > 5) {
            if (!accuracyCircle) {
                accuracyCircle = L.circle(pos, {
                    radius: data.position.accuracy,
                    color: '#dc3545',
                    weight: 1,
                    fillColor: '#dc3545',
                    fillOpacity: 0.08
                }).addTo(map);
            } else {
                accuracyCircle.setLatLng(pos);
                accuracyCircle.setRadius(data.position.accuracy);
            }
        }

        if (data.trail && data.trail.length > 1) {
            var latlngs = data.trail.map(function (p) { return [p.lat, p.lng]; });
            if (trailLine) trailLine.setLatLngs(latlngs);
            else trailLine = L.polyline(latlngs, { color: '#dc3545', weight: 3, opacity: 0.65, dashArray: '8 6' }).addTo(map);
        }

        setStatus('<i class="fas fa-circle text-danger me-1" style="font-size:.6rem;vertical-align:middle;"></i> ' +
            (data.order.status === 'active' ? 'Courier is on the way to pick up your clothes' : 'Courier is on the move') +
            ' &middot; updated ' + Math.max(0, Math.round(data.position.age)) + 's ago' +
            (data.order.driver_name ? ' &middot; ' + data.order.driver_name : ''));

        if (!fitted) {
            var pts = [pos];
            if (data.station) pts.push([data.station.lat, data.station.lng]);
            if (data.pickup) pts.push([data.pickup.lat, data.pickup.lng]);
            try { map.fitBounds(L.latLngBounds(pts).pad(0.25)); } catch (e2) { map.setView(pos, 14); }
            fitted = true;
        } else {
            try {
                if (!map.getBounds().contains(courierPin.getLatLng())) map.panTo(pos);
            } catch (e3) { /* ignore */ }
        }
    }

    function renderIdle(data) {
        var pts = [];
        if (data.station) pts.push([data.station.lat, data.station.lng]);
        if (data.pickup) pts.push([data.pickup.lat, data.pickup.lng]);
        if (pts.length && !fitted) {
            try { map.fitBounds(L.latLngBounds(pts).pad(0.3)); } catch (e4) { /* keep view */ }
            fitted = true;
        }

        var msg;
        switch (data.order.status) {
            case 'pending':
                msg = 'Waiting for the provider to accept your order&hellip;';
                break;
            case 'active':
                msg = 'Order accepted &mdash; live location appears once the courier starts sharing.';
                break;
            case 'in_progress':
                msg = 'Your clothes are at the station being cleaned.';
                break;
            case 'out_for_delivery':
                msg = 'Out for delivery &mdash; waiting for the courier\u2019s first location update&hellip;';
                break;
            case 'delivered':
            case 'completed':
                msg = '<i class="fas fa-check-circle text-success me-1"></i>Order delivered.';
                break;
            default:
                msg = 'Live tracking unavailable for this order.';
        }
        setStatus('<i class="fas fa-info-circle text-primary me-1"></i>' + msg);
    }

    function render(data) {
        if (!data || !data.ok) {
            if (data && data.error === 'not_logged_in') {
                setStatus('<i class="fas fa-lock me-1"></i>Please log in to view live tracking.');
            }
            return;
        }
        window.TRACK_DATA = data; /* expose for debugging / other scripts */
        renderStatic(data);
        if (data.live && data.position) renderLive(data);
        else renderIdle(data);
    }

    function poll() {
        var url = cfg.apiUrl + '?' + buildQuery() + '&_=' + Date.now();
        fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(render)
            .catch(function () { /* transient network error — keep last view */ });
    }

    poll();
    var timer = setInterval(poll, Math.max(2000, cfg.pollMs || 5000));
    /* Pause polling while the tab is hidden, resume (and refresh) on return. */
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) {
            clearInterval(timer);
        } else {
            poll();
            timer = setInterval(poll, Math.max(2000, cfg.pollMs || 5000));
        }
    });
})();
