// Provider JavaScript

// Add pricing row dynamically (business settings page)
let pricingIndex = 1;

function addPricingRow() {
    const container = document.getElementById('pricingItems');
    if (!container) return;

    const options = (typeof SERVICE_OPTIONS !== 'undefined' && SERVICE_OPTIONS.length)
        ? SERVICE_OPTIONS
        : ['Wash & Fold', 'Dry Cleaning', 'Pressing Only'];

    const selectOptions = options.map(o => `<option value="${o}">${o}</option>`).join('');

    const div = document.createElement('div');
    div.className = 'pricing-row mb-3 p-3 border rounded';
    div.innerHTML = `
        <div class="mb-2">
            <select name="services[${pricingIndex}][service_name]" class="form-control">${selectOptions}</select>
        </div>
        <div class="mb-2">
            <input type="text" name="services[${pricingIndex}][clothing_type]" class="form-control" placeholder="Clothing Type (e.g. Shirt)">
        </div>
        <div class="mb-2">
            <input type="number" name="services[${pricingIndex}][price]" class="form-control" placeholder="Price (UGX)" step="1" min="1">
        </div>
        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.pricing-row').remove()">
            <i class="fas fa-trash"></i> Remove
        </button>
    `;
    container.appendChild(div);
    pricingIndex++;
}

// Auto-refresh pending orders hint
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('pendingOrdersCount')) {
        setInterval(function() {
            console.log('Checking for new orders...');
        }, 30000);
    }

    // ===== Station Location map (business settings) =====
    initStationMap();
});

// ---------------- Station Locator (business settings) ----------------
let stationMap = null;
let stationPin = null;
let stationInitialized = false;

function setStationStatus(html) {
    const el = document.getElementById('stationGpsStatus');
    if (el) el.innerHTML = html;
}

function initStationMap() {
    const mount = document.getElementById('stationMap');
    if (!mount || typeof L === 'undefined' || stationInitialized) return;
    stationInitialized = true;

    const latV = parseFloat(document.getElementById('stationLat')?.value || '');
    const lngV = parseFloat(document.getElementById('stationLng')?.value || '');
    const has = isFinite(latV) && isFinite(lngV);
    const start = has ? [latV, lngV] : [0.3136, 32.5811]; /* saved pin or Kampala */

    try {
        stationMap = L.map('stationMap').setView(start, 13);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(stationMap);

        /* click anywhere on the map to drop the pin */
        try {
            stationMap.on('click', function(e) {
                /* Both Leaflet 1.x and 2.x expose the click coordinates as e.latlng */
                const ll = (e && (e.latlng || e.coords)) || null;
                if (!ll) return;
                const lat = ll.lat ?? ll.latitude ?? null;
                const lng = ll.lng ?? ll.longitude ?? null;
                if (lat !== null && lng !== null && isFinite(lat) && isFinite(lng)) setStationPin(lat, lng);
            });
        } catch (e1) { /* older Leaflet — GPS button still works */ }

        if (has) setStationPin(latV, lngV);
    } catch (e2) {
        setStationStatus('<i class="fas fa-exclamation-triangle text-danger me-1"></i>Map could not load — check your internet connection.');
    }
}

function setStationPin(lat, lng) {
    if (!stationInitialized || !isFinite(lat) || !isFinite(lng)) return;
    lat = parseFloat(lat); lng = parseFloat(lng);

    /* replace the old pin (simple + reliable across Leaflet versions) */
    if (stationPin) {
        try { stationMap.removeLayer(stationPin); } catch (e1) {}
        try { stationPin.remove(); } catch (e2) {}
        stationPin = null;
    }
    stationPin = L.marker([lat, lng], {
        icon: L.divIcon({
            className: 'station-pin',
            html: '<div style="background:#0077b6;border:3px solid #fff;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3);"><i class="fas fa-store" style="color:#fff;font-size:12px;"></i></div>',
            iconSize: [28, 28],
            iconAnchor: [14, 14]
        })
    }).addTo(stationMap).bindPopup('<strong>Your station</strong><br>' + lat.toFixed(6) + ', ' + lng.toFixed(6));

    /* sync the form so Save Station Position persists these coordinates */
    const latH = document.getElementById('stationLat');
    const lngH = document.getElementById('stationLng');
    const latT = document.getElementById('stationLatText');
    const lngT = document.getElementById('stationLngText');
    const save = document.getElementById('stationSaveBtn');
    if (latH) latH.value = lat.toFixed(6);
    if (lngH) lngH.value = lng.toFixed(6);
    if (latT) latT.value = lat.toFixed(6);
    if (lngT) lngT.value = lng.toFixed(6);
    if (save) save.disabled = false;

    setStationStatus('<i class="fas fa-check-circle text-success me-1"></i>Pin at ' + lat.toFixed(5) + ', ' + lng.toFixed(5) + ' — press Save below.');
}

function initStationLocator() {
    if (!stationInitialized) {
        setStationStatus('<i class="fas fa-spinner fa-spin me-1"></i>Preparing map…');
        initStationMap();
    }
    if (!navigator.geolocation || typeof navigator.geolocation.getCurrentPosition !== 'function') {
        setStationStatus('<i class="fas fa-exclamation-triangle text-danger me-1"></i>GPS not supported here — click the map to drop your station pin instead.');
        return;
    }
    setStationStatus('<i class="fas fa-spinner fa-spin me-1"></i>Locating your station…');
    navigator.geolocation.getCurrentPosition(
        (pos) => setStationPin(pos.coords.latitude, pos.coords.longitude),
        (err) => {
            const msgs = { 1: 'Location permission denied — allow access and retry, or click the map to drop the pin.', 2: 'Position unavailable. Try again.', 3: 'Location request timed out. Try again.' };
            setStationStatus('<i class="fas fa-exclamation-triangle text-warning me-1"></i>' + (msgs[err.code] || 'Could not get your location.'));
        },
        { timeout: 10000 }
    );
}

function clearStationPin() {
    if (stationPin) {
        try { stationMap.removeLayer(stationPin); } catch (e1) {}
        try { stationPin.remove(); } catch (e2) {}
        stationPin = null;
    }
    const latH = document.getElementById('stationLat');
    const lngH = document.getElementById('stationLng');
    const latT = document.getElementById('stationLatText');
    const lngT = document.getElementById('stationLngText');
    const save = document.getElementById('stationSaveBtn');
    if (latH) latH.value = '';
    if (lngH) lngH.value = '';
    if (latT) latT.value = '—';
    if (lngT) lngT.value = '—';
    if (save) save.disabled = true;
    setStationStatus('<i class="fas fa-info-circle me-1"></i>Pin cleared — set it again or press Save to keep the previous position (map keeps showing the saved pin).');
}
