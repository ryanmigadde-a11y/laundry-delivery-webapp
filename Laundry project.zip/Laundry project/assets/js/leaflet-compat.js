/**
 * Leaflet 2.0.0-alpha.1 compatibility shim.
 *
 * The 2.x global build (assets/vendor/leaflet/leaflet-global.js) only exports
 * classes (L.Map, L.Marker, L.TileLayer …). The classic 1.x factory functions
 * (L.map(), L.marker(), L.tileLayer(), L.divIcon(), …) that this project's
 * pages rely on were removed in 2.x. This file re-adds them so all existing
 * code keeps working while we benefit from the locally hosted 2.x build.
 *
 * Load order: leaflet-global.js -> leaflet-compat.js -> page scripts.
 */
(function (global) {
    'use strict';

    var L = global.L || global.leaflet;
    if (!L) return; /* Leaflet not loaded — nothing to patch */

    /* Make sure the classic `L` name is always available. */
    global.L = L;

    /* ---- Layer / map factories (1.x API) ---- */
    if (typeof L.map !== 'function') {
        L.map = function (el, options) { return new L.Map(el, options); };
    }
    if (typeof L.tileLayer !== 'function') {
        L.tileLayer = function (urlTemplate, options) { return new L.TileLayer(urlTemplate, options); };
    }
    if (typeof L.marker !== 'function') {
        L.marker = function (latlng, options) { return new L.Marker(latlng, options); };
    }
    if (typeof L.divIcon !== 'function') {
        L.divIcon = function (options) { return new L.DivIcon(options); };
    }
    if (typeof L.polyline !== 'function') {
        L.polyline = function (latlngs, options) { return new L.Polyline(latlngs, options); };
    }
    if (typeof L.polygon !== 'function') {
        L.polygon = function (latlngs, options) { return new L.Polygon(latlngs, options); };
    }
    if (typeof L.circle !== 'function') {
        L.circle = function (latlng, options) { return new L.Circle(latlng, options); };
    }
    if (typeof L.circleMarker !== 'function') {
        L.circleMarker = function (latlng, options) { return new L.CircleMarker(latlng, options); };
    }
    if (typeof L.rectangle !== 'function') {
        L.rectangle = function (latlngBounds, options) { return new L.Rectangle(latlngBounds, options); };
    }
    if (typeof L.layerGroup !== 'function') {
        L.layerGroup = function (layers, options) { return new L.LayerGroup(layers, options); };
    }
    if (typeof L.featureGroup !== 'function') {
        L.featureGroup = function (layers, options) { return new L.FeatureGroup(layers, options); };
    }

    /* ---- Coordinate helpers (accept both array and lat/lng forms like 1.x) ---- */
    if (typeof L.latLng !== 'function') {
        L.latLng = function (a, b, c) {
            if (Array.isArray(a)) return new L.LatLng(a[0], a[1]);
            if (a && typeof a === 'object') return new L.LatLng(a.lat, a.lng);
            return new L.LatLng(a, b);
        };
    }
    if (typeof L.latLngBounds !== 'function') {
        L.latLngBounds = function (corner1, corner2) { return new L.LatLngBounds(corner1, corner2); };
    }

    /* ---- Controls namespace (L.control.layers(), L.control.scale(), …) ---- */
    if (typeof L.control !== 'object' || L.control === null) L.control = {};
    if (typeof L.control.layers !== 'function' && typeof L.Control !== 'undefined' && L.Control.Layers) {
        L.control.layers = function (baseLayers, overlays, options) { return new L.Control.Layers(baseLayers, overlays, options); };
    }
    if (typeof L.control.scale !== 'function' && typeof L.Control !== 'undefined' && L.Control.Scale) {
        L.control.scale = function (options) { return new L.Control.Scale(options); };
    }
    if (typeof L.control.zoom !== 'function' && typeof L.Control !== 'undefined' && L.Control.Zoom) {
        L.control.zoom = function (options) { return new L.Control.Zoom(options); };
    }
    if (typeof L.control.attribution !== 'function' && typeof L.Control !== 'undefined' && L.Control.Attribution) {
        L.control.attribution = function (options) { return new L.Control.Attribution(options); };
    }

    /* ---- Icon.Default image path (so plain markers still show) ---- */
    try {
        if (L.Icon && L.Icon.Default && !L.Icon.Default.prototype.options.imagePath) {
            var cssLinks = document.getElementsByTagName('link');
            for (var i = 0; i < cssLinks.length; i++) {
                var href = cssLinks[i].getAttribute('href') || '';
                if (href.indexOf('leaflet.css') !== -1) {
                    L.Icon.Default.imagePath = href.replace(/leaflet\\.css.*$/, '');
                    break;
                }
            }
        }
    } catch (e) { /* never block page rendering on icon path detection */ }
})(typeof window !== 'undefined' ? window : this);
