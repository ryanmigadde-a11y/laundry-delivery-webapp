/**
 * Courier live-location sharing (provider Order Details page).
 *
 * Expects a #shareMap preview div and global SHARE_CONFIG:
 *   SHARE_CONFIG = {
 *       apiUrl:  '../../php/api/tracking.php',
 *       orderId: 12,
 *       status:  'out_for_delivery'   // order status drives the phase label
 *   };
 *
 * Uses navigator.geolocation.watchPosition and POSTs a ping every
 * SHARE_CONFIG.intervalMs (default 5s) while sharing is enabled.
 */
(function () {
    'use strict';

    var cfg = window.SHARE_CONFIG || {};
    var startBtn = document.getElementById('shareStartBtn');
    var stopBtn = document.getElementById('shareStopBtn');
    var statusEl = document.getElementById('shareStatus');
    var mapEl = document.getElementById('shareMap');
    if (!cfg.apiUrl || !cfg.orderId) return;

    var watchId = null;
    var lastSentAt = 0;
    var sentCount = 0;
    var map = null;
    var previewPin = null;

    function setStatus(html) { if (statusEl) statusEl.innerHTML = html; }

    function showButtons(sharing) {
        if (startBtn) startBtn.style.display = sharing ? 'none' : '';
        if (stopBtn) stopBtn.style.display = sharing ? '' : 'none';
    }

    function initPreviewMap(lat, lng) {
        if (!mapEl || typeof L === 'undefined' || map) return;
        try {
            map = L.map('shareMap').setView([lat, lng], 14);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map);
        } catch (e) { /* preview map is optional */ }
    }

    function updatePreview(lat, lng) {
        initPreviewMap(lat, lng);
        if (!map) return;
        if (previewPin) previewPin.setLatLng([lat, lng]);
        else {
            previewPin = L.marker([lat, lng], {
                icon: L.divIcon({
                    className: 'share-pin',
                    html: '<div style="background:#198754;border:3px solid #fff;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.35);"><i class="fas fa-truck-fast" style="color:#fff;font-size:12px;"></i></div>',
                    iconSize: [28, 28],
                    iconAnchor: [14, 14]
                })
            }).addTo(map);
        }
        try { map.setView([lat, lng], map.getZoom()); } catch (e) { /* ignore */ }
    }

    function sendPing(pos) {
        var now = Date.now();
        var interval = Math.max(2000, cfg.intervalMs || 5000);
        if (now - lastSentAt < interval) return; /* throttle */
        lastSentAt = now;

        var body = new FormData();
        body.append('order_id', cfg.orderId);
        body.append('lat', pos.coords.latitude);
        body.append('lng', pos.coords.longitude);
        if (pos.coords.accuracy) body.append('accuracy', Math.round(pos.coords.accuracy));
        if (typeof pos.coords.speed === 'number' && pos.coords.speed >= 0) {
            body.append('speed', (pos.coords.speed * 3.6).toFixed(1)); /* m/s -> km/h */
        }

        fetch(cfg.apiUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data && data.ok) {
                    sentCount++;
                    setStatus('<i class="fas fa-satellite-dish text-success me-1"></i>Sharing live location &middot; ' +
                        sentCount + ' update' + (sentCount === 1 ? '' : 's') + ' sent &middot; last ' +
                        new Date().toLocaleTimeString());
                } else if (data && data.error === 'order_not_active') {
                    setStatus('<i class="fas fa-info-circle text-warning me-1"></i>Order is no longer active &mdash; sharing stopped.');
                    stopSharing();
                } else {
                    setStatus('<i class="fas fa-exclamation-triangle text-warning me-1"></i>Could not share location &mdash; retrying&hellip;');
                }
            })
            .catch(function () {
                setStatus('<i class="fas fa-exclamation-triangle text-warning me-1"></i>Network hiccup &mdash; still trying&hellip;');
            });
    }

    function onPos(pos) {
        updatePreview(pos.coords.latitude, pos.coords.longitude);
        sendPing(pos);
    }

    function onErr(err) {
        var msgs = {
            1: 'Location permission denied &mdash; please allow GPS access to share your position.',
            2: 'Position unavailable. Check GPS and network.',
            3: 'Location request timed out. Try again.'
        };
        setStatus('<i class="fas fa-exclamation-triangle text-warning me-1"></i>' + (msgs[err.code] || 'Could not get your location.'));
        if (err.code === 1) stopSharing();
    }

    function startSharing() {
        if (!navigator.geolocation || typeof navigator.geolocation.watchPosition !== 'function') {
            setStatus('<i class="fas fa-exclamation-triangle text-danger me-1"></i>GPS not supported in this browser.');
            return;
        }
        watchId = navigator.geolocation.watchPosition(onPos, onErr, { enableHighAccuracy: true, maximumAge: 3000, timeout: 15000 });
        showButtons(true);
        setStatus('<i class="fas fa-spinner fa-spin me-1"></i>Acquiring GPS fix&hellip;');
    }

    function stopSharing() {
        if (watchId !== null && navigator.geolocation) {
            try { navigator.geolocation.clearWatch(watchId); } catch (e) { /* ignore */ }
        }
        watchId = null;
        showButtons(false);
        setStatus('<i class="fas fa-pause-circle me-1"></i>Location sharing is off. The customer only sees your position while you share.');
    }

    window.startShareLocation = startSharing;
    window.stopShareLocation = stopSharing;

    if (startBtn) startBtn.addEventListener('click', startSharing);
    if (stopBtn) stopBtn.addEventListener('click', stopSharing);

    /* Sensible initial state text */
    if (statusEl && !statusEl.innerHTML.trim()) {
        setStatus('<i class="fas fa-info-circle me-1"></i>Share your GPS position so the customer can watch the pickup/delivery live on their map.');
    }
})();
