// Authentication JavaScript

// Password validation
function validatePassword(password) {
    return password.length >= 6;
}

// Phone validation (Uganda)
function validatePhone(phone) {
    const cleaned = phone.replace(/[^0-9]/g, '');
    return /^(256|0)[0-9]{9}$/.test(cleaned);
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const password = form.querySelector('input[type="password"]');
            if (password && password.value.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters');
            }
        });
    });
});