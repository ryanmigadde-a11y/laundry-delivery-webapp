// LaundryExpress Uganda - Landing Page Scripts

document.addEventListener('DOMContentLoaded', function () {
    // Scroll reveal animations
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

    // Navbar scroll effect
    const navbar = document.querySelector('.navbar-custom');
    if (navbar) {
        window.addEventListener('scroll', function () {
            navbar.style.background = window.scrollY > 50 ? 'rgba(3, 4, 94, 0.98)' : 'rgba(3, 4, 94, 0.95)';
        });
    }

    // Pricing estimator
    const prices = {
        wash_fold: { shirt: 500, trouser: 700, dress: 800, suit: 1000 },
        dry_clean: { shirt: 800, trouser: 900, dress: 1200, suit: 2500 },
        press: { shirt: 400, trouser: 500, dress: 700, suit: 900 }
    };

    function estimatePrice() {
        const serviceEl = document.getElementById('estService');
        const clothingEl = document.getElementById('estClothing');
        const qtyEl = document.getElementById('estQuantity');
        const resultEl = document.getElementById('estResult');
        if (!serviceEl || !clothingEl || !qtyEl || !resultEl) return;

        const service = serviceEl.value;
        const clothing = clothingEl.value;
        const qty = parseInt(qtyEl.value) || 1;
        const price = (prices[service] && prices[service][clothing] ? prices[service][clothing] : 0) * qty;
        resultEl.textContent = 'UGX ' + price.toLocaleString();
    }

    ['estService', 'estClothing', 'estQuantity'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', estimatePrice);
            el.addEventListener('input', estimatePrice);
        }
    });
    estimatePrice();
});
