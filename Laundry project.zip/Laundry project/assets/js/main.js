// Main JavaScript for LaundryExpress Uganda

document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        document.querySelectorAll('.alert-dismissible').forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Tooltip initialization
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(el) {
        return new bootstrap.Tooltip(el);
    });
    
    // Initialize all popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(el) {
        return new bootstrap.Popover(el);
    });
    
    // Panel sidebar (off-canvas) — mobile drawer
    var panelSidebar = document.querySelector('.panel-sidebar');
    var sidebarToggle = document.querySelector('.sidebar-toggle-btn');
    if (panelSidebar) {
        var backdrop = document.createElement('div');
        backdrop.className = 'sidebar-backdrop';
        document.body.appendChild(backdrop);

        function openSidebar() {
            panelSidebar.classList.add('show');
            backdrop.classList.add('show');
            document.body.classList.add('sidebar-open');
        }
        function closeSidebar() {
            panelSidebar.classList.remove('show');
            backdrop.classList.remove('show');
            document.body.classList.remove('sidebar-open');
        }
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function (e) {
                e.preventDefault();
                if (panelSidebar.classList.contains('show')) {
                    closeSidebar();
                } else {
                    openSidebar();
                }
            });
        }
        document.querySelectorAll('.sidebar-close').forEach(function (b) {
            b.addEventListener('click', closeSidebar);
        });
        backdrop.addEventListener('click', closeSidebar);
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSidebar(); });
        window.addEventListener('resize', function () { if (window.innerWidth >= 992) closeSidebar(); });

        // Navigate on link click -> close the drawer automatically
        var sidebarLinks = document.querySelectorAll('.panel-sidebar a');
        sidebarLinks.forEach(function (a) {
            a.addEventListener('click', function () { if (window.innerWidth < 992) closeSidebar(); });
        });
    } else if (sidebarToggle) {
        // No panel on this page (e.g. landing page) - hide the mobile button
        sidebarToggle.style.display = 'none';
    }
});