(function () {
    'use strict';

    var apiUrl = '../../php/api/provider_live_location.php';
    var startBtn = document.getElementById('providerLiveStart');
    var stopBtn = document.getElementById('providerLiveStop');
    var statusEl = document.getElementById('providerLiveStatus');
    var watchId = null;
    var lastSentAt = 0;
    var map = null;
    var pin = null;

    if (!startBtn || !stopBtn || !statusEl || typeof L === 'undefined') return;

    map = L.map('providerLiveMap').setView([0.3136, 32.5811], 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    function setStatus(message, type) {
        statusEl.className = 'small mt-3 mb-0 ' + (type || 'text-muted');
        statusEl.textContent = message;
    }

    function setSharingUi(isSharing) {
        startBtn.disabled = isSharing;
        stopBtn.disabled = !isSharing;
    }

    function sendPosition(position) {
        var now = Date.now();
        if (now - lastSentAt < 4000) return;
        lastSentAt = now;

        var lat = position.coords.latitude;
        var lng = position.coords.longitude;
        if (pin) pin.setLatLng([lat, lng]);
        else {
            pin = L.marker([lat, lng]).addTo(map).bindPopup('Your live provider location');
        }
        map.setView([lat, lng], Math.max(map.getZoom(), 15));

        var body = new FormData();
        body.append('action', 'ping');
        body.append('lat', lat);
        body.append('lng', lng);
        if (position.coords.accuracy) body.append('accuracy', Math.round(position.coords.accuracy));

        fetch(apiUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                if (data && data.ok) {
                    setStatus('Sharing is ON. Last GPS update: ' + new Date().toLocaleTimeString() + '. Keep this page open.', 'text-success');
                } else {
                    setStatus('Could not save GPS location. Check your provider account and try again.', 'text-danger');
                }
            })
            .catch(function () { setStatus('Network error while sending location. Retrying when GPS updates.', 'text-danger'); });
    }

    function gpsError(error) {
        var messages = {
            1: 'Location permission was denied. Allow location access in your browser and try again.',
            2: 'GPS position is unavailable. Check your device location settings.',
            3: 'GPS timed out. Move to an area with better signal and retry.'
        };
        setStatus(messages[error.code] || 'Could not access GPS.', 'text-danger');
        if (error.code === 1) stopSharing();
    }

    function startSharing() {
        if (!navigator.geolocation || !navigator.geolocation.watchPosition) {
            setStatus('This browser does not support GPS location sharing.', 'text-danger');
            return;
        }
        setSharingUi(true);
        setStatus('Requesting GPS permission and waiting for your position…', 'text-primary');
        watchId = navigator.geolocation.watchPosition(sendPosition, gpsError, {
            enableHighAccuracy: true,
            maximumAge: 3000,
            timeout: 15000
        });
    }

    function stopSharing() {
        if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
        watchId = null;
        var body = new FormData();
        body.append('action', 'stop');
        fetch(apiUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                setSharingUi(false);
                setStatus(data && data.ok ? 'Sharing is OFF. Customers can no longer see your live position.' : 'GPS watching stopped; the server may not have received the stop request.', data && data.ok ? 'text-muted' : 'text-warning');
            })
            .catch(function () {
                setSharingUi(false);
                setStatus('GPS watching stopped, but the stop request could not reach the server. The location will expire after two minutes.', 'text-warning');
            });
    }

    startBtn.addEventListener('click', startSharing);
    stopBtn.addEventListener('click', stopSharing);
    window.addEventListener('beforeunload', function () {
        if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    });
})();
