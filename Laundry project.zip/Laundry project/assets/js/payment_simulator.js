// Payment Simulator for Mobile Money (Uganda)
// Simulates MTN Mobile Money & Airtel Money USSD push, validated server-side
// through php/api/payment.php (initiate -> USSD prompt -> confirm callback).

let paymentConfirmed = false;

// Set by the payment page: window.BASE_PATH_AJAX = '../../../';
if (typeof BASE_PATH_AJAX === 'undefined') {
    var BASE_PATH_AJAX = '../';
}
// Which stream is being paid: 'order' | 'wallet' | 'subscription'
if (typeof PAYMENT_PURPOSE === 'undefined') {
    var PAYMENT_PURPOSE = 'order';
}

function selectPayment(method) {
    const paymentMethodInput = document.getElementById('paymentMethod');
    const mobileMoneyFields = document.getElementById('mobileMoneyFields');
    const walletFields = document.getElementById('walletFields');
    const completeOrderBtn = document.getElementById('completeOrderBtn');

    if (paymentMethodInput) paymentMethodInput.value = method;
    if (mobileMoneyFields) mobileMoneyFields.style.display = method === 'mobile_money' ? 'block' : 'none';
    if (walletFields) walletFields.style.display = method === 'wallet' ? 'block' : 'none';

    /* Cash + Wallet are confirmed immediately; Mobile Money waits for the USSD simulation. */
    paymentConfirmed = method !== 'mobile_money';
    if (completeOrderBtn) completeOrderBtn.disabled = !paymentConfirmed;
}

function simulatePayment() {
    const network = document.getElementById('mobileNetwork');
    const number = document.getElementById('mobileNumber');
    const simulation = document.getElementById('paymentSimulation');
    const tokenInput = document.getElementById('orderToken');

    if (!network || !number) return;

    const phone = number.value.trim();
    if (!phone) {
        alert('Please enter your mobile number');
        return;
    }
    if (!simulation) return;

    simulation.style.display = 'block';
    simulation.innerHTML = `
        <div class="text-center py-3">
            <div class="spinner-border text-primary" role="status"></div>
            <p class="mt-2 text-muted">Sending payment request...</p>
        </div>`;

    const formData = new FormData();
    formData.append('action', 'initiate');
    formData.append('network', network.value);
    formData.append('phone', phone);
    formData.append('purpose', PAYMENT_PURPOSE);
    formData.append('amount', document.getElementById('totalAmount') ? document.getElementById('totalAmount').value : 0);
    formData.append('order_token', tokenInput ? tokenInput.value : '');

    fetch(BASE_PATH_AJAX + 'php/api/payment.php', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (!data.ok) {
                simulation.innerHTML = `<div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i>Could not start the payment: ${data.message || 'please try again'}.</div>`;
                return;
            }

            /* Real MTN RequestToPay already returned SUCCESSFUL */
            if (data.status === 'success') {
                simulation.innerHTML = `<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Payment successful via ${data.network_name}!${data.reference ? ` <small class="d-block">Transaction ref: ${data.reference}</small>` : ''}</div>`;
                paymentConfirmed = true;
                const cb = document.getElementById('completeOrderBtn');
                if (cb) cb.disabled = false;
                return;
            }

            simulation.innerHTML = `
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Please check your phone. Dial <strong>${data.ussd}</strong> on your ${data.network_name} line
                    (${phone}) and enter your PIN to confirm the payment.
                </div>
                <div class="text-center py-3">
                    <div class="spinner-border text-primary" role="status"></div>
                    <p class="mt-2 text-muted">Waiting for payment confirmation...</p>
                </div>`;

            // Simulated gateway callback after ~6 seconds
            setTimeout(() => {
                const confirmData = new FormData();
                confirmData.append('action', 'confirm');
                confirmData.append('purpose', PAYMENT_PURPOSE);
                confirmData.append('order_token', tokenInput ? tokenInput.value : '');
                fetch(BASE_PATH_AJAX + 'php/api/payment.php', { method: 'POST', body: confirmData })
                    .then(r => r.json())
                    .then(res => {
                        if (res.ok && res.status === 'success') {
                            simulation.innerHTML = `<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Payment successful via ${data.network_name}!${res.reference ? ` <small class="d-block">Transaction ref: ${res.reference}</small>` : ''} You can now complete your order.</div>`;
                            paymentConfirmed = true;
                            const completeOrderBtn = document.getElementById('completeOrderBtn');
                            if (completeOrderBtn) completeOrderBtn.disabled = false;
                        } else {
                            simulation.innerHTML = '<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>Payment failed. Please try again.</div>';
                        }
                    });
            }, 6000);
        })
        .catch(() => {
            simulation.innerHTML = '<div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i>Network error. Please try again.</div>';
        });
}

window.selectPayment = selectPayment;
window.simulatePayment = simulatePayment;
