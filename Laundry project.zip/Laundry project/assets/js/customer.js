// Customer JavaScript
function incrementQty(btn) {
    const input = btn.parentElement.querySelector('.item-qty');
    if (input) {
        input.value = parseInt(input.value) + 1;
        updateTotals();
    }
}

function decrementQty(btn) {
    const input = btn.parentElement.querySelector('.item-qty');
    if (input && parseInt(input.value) > 0) {
        input.value = parseInt(input.value) - 1;
        updateTotals();
    }
}

function updateTotals() {
    let grandTotal = 0;
    document.querySelectorAll('.item-row').forEach(row => {
        const qty = parseInt(row.querySelector('.item-qty').value) || 0;
        const price = parseFloat(row.querySelector('.item-qty').dataset.price);
        const subtotal = qty * price;
        const subtotalEl = row.querySelector('.item-subtotal');
        if (subtotalEl) {
            subtotalEl.textContent = 'UGX ' + subtotal.toLocaleString();
        }
        grandTotal += subtotal;
    });
    const grandTotalEl = document.getElementById('grandTotal');
    if (grandTotalEl) {
        grandTotalEl.textContent = 'UGX ' + grandTotal.toLocaleString();
    }
    const scheduleBtn = document.getElementById('scheduleBtn');
    if (scheduleBtn) {
        scheduleBtn.disabled = grandTotal === 0;
    }
}

// Auto-calculate on page load
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.item-row')) {
        updateTotals();
    }
});