Upload customer profile pictures, provider logos and business images here.
Files are saved automatically by the system (assets/images/uploads/).
