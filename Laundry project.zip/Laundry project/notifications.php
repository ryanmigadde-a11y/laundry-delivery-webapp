<?php
/**
 * Notifications page (all roles) - list, mark read, mark all read.
 */
$BASE = '../';
require_once __DIR__ . '/includes/session.php';

/* Admins have their own panel - keep their notifications inside the admin area. */
if (is_admin()) {
    redirect($BASE . 'php/admin/dashboard.php');
}
require_login(null, $BASE);

$user = current_user();
$pdo = $GLOBALS['pdo'];

/* Mark all as read */
if (isset($_POST['mark_all'])) {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$user['user_id']]);
    flash('success', 'All notifications marked as read.');
    redirect('notifications.php');
}

/* Mark one as read */
if (isset($_POST['mark_one'])) {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?')
        ->execute([(int)$_POST['mark_one'], $user['user_id']]);
    redirect('notifications.php');
}

$stmt = $pdo->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
$stmt->execute([$user['user_id']]);
$notifications = $stmt->fetchAll();

$active = 'notifications';
$roleFolder = $_SESSION['user_type'] === 'provider' ? 'provider' : 'customer';
$page_title = 'Notifications';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/' . $roleFolder . '_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0"><i class="fas fa-bell me-2"></i>Notifications</h2>
            <form method="POST"><button class="btn btn-outline-primary btn-sm" name="mark_all" value="1"><i class="fas fa-check-double me-1"></i>Mark All Read</button></form>
        </div>

        <?php if (!$notifications): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                <p class="text-muted mb-0">No notifications yet. Updates about your orders will appear here.</p>
            </div>
        <?php endif; ?>

        <?php foreach ($notifications as $n): ?>
            <div class="card border-0 shadow-sm rounded-4 mb-3 <?php echo $n['is_read'] ? '' : 'border-start border-primary border-4'; ?>">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="fw-bold"><?php echo e($n['title']); ?></h6>
                            <p class="mb-1"><?php echo e($n['message']); ?></p>
                            <small class="text-muted"><?php echo time_ago($n['created_at']); ?></small>
                        </div>
                        <div class="text-end">
                            <?php if ($n['link']): ?>
                                <a href="<?php echo $BASE . e($n['link']); ?>" class="btn btn-sm btn-outline-primary mb-2"><i class="fas fa-arrow-right me-1"></i>View</a><br>
                            <?php endif; ?>
                            <?php if (!$n['is_read']): ?>
                            <form method="POST">
                                <button name="mark_one" value="<?php echo (int)$n['notification_id']; ?>" class="btn btn-sm btn-outline-success"><i class="fas fa-check"></i> Mark Read</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
