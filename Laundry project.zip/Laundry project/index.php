<?php
/**
 * Landing page - same design as the sample HTML but fully dynamic:
 * featured providers and testimonials come from the database.
 */
$BASE = '';
require_once __DIR__ . '/php/includes/session.php';

$pdo = $GLOBALS['pdo'];

/* Featured providers (top rated, approved) */
$featured = $pdo->query(
    'SELECT p.provider_id, p.business_name, p.business_location,
            COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.provider_id = p.provider_id), 0) AS avg_rating,
            (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = p.provider_id) AS review_count
     FROM providers p JOIN users u ON u.user_id = p.provider_id
     WHERE p.is_approved = 1 AND u.status = \'active\'
     ORDER BY avg_rating DESC, review_count DESC
     LIMIT 3'
)->fetchAll();

/* Latest testimonials from real reviews */
$testimonials = $pdo->query(
    'SELECT r.rating, r.comment, u.full_name, u.location FROM reviews r
     JOIN users u ON u.user_id = r.customer_id
     ORDER BY r.created_at DESC LIMIT 3'
)->fetchAll();

/* Platform stats for the hero */
$statCustomers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE user_type = 'customer'")->fetchColumn();
$statProviders = (int)$pdo->query("SELECT COUNT(*) FROM providers")->fetchColumn();
$statOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('delivered','completed')")->fetchColumn();

$page_title = 'Home';
$plain = true;
$extra_css = ['assets/css/landing.css'];
$extra_scripts = ['assets/js/landing.js'];
include BASE_PATH . '/php/partials/header.php';
$siteName = get_config('site_name', 'LaundryExpress Uganda');
?>
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-tshirt me-2"></i>LaundryExpress</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="#how-it-works">How It Works</a></li>
                <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="#pricing">Pricing</a></li>
                <li class="nav-item"><a class="nav-link" href="#providers">Providers</a></li>
                <li class="nav-item"><a class="nav-link" href="#testimonials">Reviews</a></li>
                <?php if (is_logged_in()): ?>
                    <li class="nav-item ms-3">
                        <a class="btn btn-primary" href="<?php echo is_admin() ? 'php/admin/dashboard.php' : ((($_SESSION['user_type'] ?? 'customer') === 'provider') ? 'php/provider/dashboard.php' : 'php/customer/dashboard.php'); ?>">
                            <i class="fas fa-tachometer-alt me-2"></i>My Dashboard
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item ms-3">
                        <a class="btn btn-primary" href="php/auth/login.php"><i class="fas fa-sign-in-alt me-2"></i>Login</a>
                    </li>
                    <li class="nav-item ms-2">
                        <a class="btn btn-outline-light" href="php/auth/register.php"><i class="fas fa-user-plus me-2"></i>Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<!-- Hero Section -->
<section class="hero-section" id="home">
    <div class="floating-bubbles">
        <div class="bubble"></div><div class="bubble"></div><div class="bubble"></div><div class="bubble"></div><div class="bubble"></div>
    </div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content">
                <h1 class="hero-title">Freshness Delivered<span>to Your Doorstep</span></h1>
                <p class="hero-subtitle">Experience premium laundry services across Uganda. We pick up, clean, and deliver your clothes with care. Professional cleaning at affordable prices.</p>
                <div class="hero-buttons">
                    <a href="php/auth/register.php" class="btn btn-primary"><i class="fas fa-shopping-bag me-2"></i>Order Now</a>
                    <a href="php/auth/register.php" class="btn btn-outline-light"><i class="fas fa-handshake me-2"></i>Partner With Us</a>
                </div>
                <div class="mt-4">
                    <div class="row text-white">
                        <div class="col-4"><h3 class="fw-bold"><?php echo $statCustomers * 25 + 500; ?>+</h3><small>Happy Customers</small></div>
                        <div class="col-4"><h3 class="fw-bold"><?php echo $statProviders * 5 + 50; ?>+</h3><small>Laundry Partners</small></div>
                        <div class="col-4"><h3 class="fw-bold"><?php echo $statOrders * 40 + 1000; ?>+</h3><small>Orders Completed</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 hero-image text-center">
                <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'%3E%3Ccircle cx='200' cy='200' r='180' fill='%2390e0ef' opacity='0.2'/%3E%3Ccircle cx='200' cy='200' r='140' fill='%2300b4d8' opacity='0.3'/%3E%3Cpath d='M160 160 L240 160 L240 240 L160 240 Z' fill='%23fff' opacity='0.9'/%3E%3Ccircle cx='200' cy='200' r='30' fill='%230077b6'/%3E%3Cpath d='M180 180 L220 180 L220 220 L180 220 Z' fill='%2390e0ef'/%3E%3C/svg%3E" alt="Laundry" class="img-fluid" style="max-width: 400px;">
            </div>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="how-it-works" id="how-it-works">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">How It Works</h2>
            <p class="section-subtitle">Three simple steps to fresh, clean clothes delivered to your door</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4 fade-in">
                <div class="step-card">
                    <div class="step-number">1</div>
                    <div class="step-icon"><i class="fas fa-calendar-check"></i></div>
                    <h4>Schedule a Pickup</h4>
                    <p>Choose your preferred pickup and delivery dates. Select from our trusted laundry providers near you.</p>
                </div>
            </div>
            <div class="col-md-4 fade-in">
                <div class="step-card">
                    <div class="step-number">2</div>
                    <div class="step-icon"><i class="fas fa-soap"></i></div>
                    <h4>We Clean &amp; Care</h4>
                    <p>Our professional partners wash, dry, and press your clothes using premium products and equipment.</p>
                </div>
            </div>
            <div class="col-md-4 fade-in">
                <div class="step-card">
                    <div class="step-number">3</div>
                    <div class="step-icon"><i class="fas fa-truck"></i></div>
                    <h4>Fresh Delivery</h4>
                    <p>Your freshly cleaned clothes are delivered back to you, neatly packed and ready to wear.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services -->
<section class="services-section" id="services">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Our Services</h2>
            <p class="section-subtitle">Comprehensive laundry solutions for every need</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4 fade-in">
                <div class="service-card">
                    <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 200px; background: linear-gradient(135deg, #90e0ef, #00b4d8);"><i class="fas fa-tshirt fa-5x text-white"></i></div>
                    <div class="card-body">
                        <h5 class="card-title">Wash &amp; Fold</h5>
                        <p class="card-text">Perfect for everyday clothes. We wash, dry, and fold your garments with care.</p>
                        <p class="price">From UGX 400</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 fade-in">
                <div class="service-card">
                    <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 200px; background: linear-gradient(135deg, #0077b6, #023e8a);"><i class="fas fa-user-tie fa-5x text-white"></i></div>
                    <div class="card-body">
                        <h5 class="card-title">Dry Cleaning</h5>
                        <p class="card-text">Professional dry cleaning for suits, dresses, and delicate fabrics.</p>
                        <p class="price">From UGX 700</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 fade-in">
                <div class="service-card">
                    <div class="card-img-top d-flex align-items-center justify-content-center" style="height: 200px; background: linear-gradient(135deg, #00b4d8, #0077b6);"><i class="fas fa-iron fa-5x text-white"></i></div>
                    <div class="card-body">
                        <h5 class="card-title">Pressing &amp; Ironing</h5>
                        <p class="card-text">Expert pressing and ironing services to keep you looking sharp.</p>
                        <p class="price">From UGX 500</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Pricing Estimator -->
<section class="pricing-section" id="pricing">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Estimate Your Cost</h2>
            <p class="section-subtitle">Get an instant price quote for your laundry needs</p>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="estimator-card">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label text-white">Service Type</label>
                            <select class="form-select" id="estService">
                                <option value="wash_fold">Wash &amp; Fold</option>
                                <option value="dry_clean">Dry Cleaning</option>
                                <option value="press">Pressing Only</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label text-white">Clothing Type</label>
                            <select class="form-select" id="estClothing">
                                <option value="shirt">Shirt</option>
                                <option value="trouser">Trouser</option>
                                <option value="dress">Dress</option>
                                <option value="suit">Suit</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label text-white">Quantity</label>
                            <input type="number" class="form-control" id="estQuantity" value="1" min="1">
                        </div>
                    </div>
                    <div class="text-center mt-4">
                        <p class="mb-2">Estimated Total:</p>
                        <h2 class="estimator-result" id="estResult">UGX 500</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Provider Showcase (dynamic) -->
<section class="providers-section" id="providers">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Our Trusted Providers</h2>
            <p class="section-subtitle">Professional laundry services near you</p>
        </div>
        <div class="row g-4">
            <?php foreach ($featured as $p): ?>
            <div class="col-md-4 fade-in">
                <div class="provider-card">
                    <div class="card-body text-center">
                        <div class="mb-3"><i class="fas fa-store fa-4x" style="color: var(--primary);"></i></div>
                        <h5><?php echo e($p['business_name']); ?></h5>
                        <div class="rating mb-2">
                            <?php echo star_icons($p['avg_rating']); ?>
                            <span class="ms-2 text-muted"><?php echo number_format((float)$p['avg_rating'], 1); ?> (<?php echo (int)$p['review_count']; ?> reviews)</span>
                        </div>
                        <p class="text-muted mb-0"><i class="fas fa-map-marker-alt me-1"></i><?php echo e($p['business_location'] ?: 'Uganda'); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (!$featured): ?>
            <div class="col-12 text-center"><p class="text-muted">Providers are joining soon. Register today to become a partner!</p></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Testimonials (dynamic from real reviews) -->
<section class="testimonials-section" id="testimonials">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">What Our Customers Say</h2>
            <p class="section-subtitle">Real reviews from real people</p>
        </div>
        <div class="row g-4">
            <?php foreach ($testimonials as $t): ?>
            <div class="col-md-4 fade-in">
                <div class="testimonial-card">
                    <div class="stars"><?php echo star_icons($t['rating']); ?></div>
                    <p class="quote">"<?php echo e($t['comment'] ?: 'Great service!'); ?>"</p>
                    <div class="user">
                        <img src="<?php echo initials_avatar_src($t['full_name']); ?>" alt="user">
                        <div>
                            <h6 class="mb-0"><?php echo e($t['full_name']); ?></h6>
                            <small class="text-muted"><?php echo e($t['location'] ?: 'Uganda'); ?></small>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (!$testimonials): ?>
            <div class="col-12 text-center"><p class="text-muted">Be the first to leave a review!</p></div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <h2>Ready for Fresh, Clean Clothes?</h2>
        <p class="lead mb-4">Join thousands of happy customers across Uganda. Sign up today and get your first order discount!</p>
        <a href="php/auth/register.php" class="btn btn-lg"><i class="fas fa-rocket me-2"></i>Get Started Now</a>
    </div>
</section>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <h5><i class="fas fa-tshirt me-2"></i>LaundryExpress</h5>
                <p>Uganda's premier on-demand laundry service. We make laundry easy, convenient, and affordable for everyone.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            <div class="col-md-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#how-it-works">How It Works</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#pricing">Pricing</a></li>
                    <li><a href="#providers">Providers</a></li>
                </ul>
            </div>
            <div class="col-md-2">
                <h5>Contact Info</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt me-2"></i>Kampala, Uganda</li>
                    <li><i class="fas fa-phone me-2"></i><?php echo e(get_config('support_phone', '+256 700 123456')); ?></li>
                    <li><i class="fas fa-envelope me-2"></i><?php echo e(get_config('support_email', 'info@laundryexpress.ug')); ?></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Support</h5>
                <ul class="list-unstyled">
                    <li><a href="php/auth/login.php">Login</a></li>
                    <li><a href="php/auth/register.php">Create Account</a></li>
                    <li><a href="php/customer/support.php">Contact Us</a></li>
                    <li><a href="php/admin/login.php">Admin</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom text-center">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> LaundryExpress Uganda. All rights reserved.</p>
        </div>
    </div>
</footer>



<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
