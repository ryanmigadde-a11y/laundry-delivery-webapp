<?php
/**
 * Forgot password - generates a reset token.
 * XAMPP has no mail server configured by default, so the reset link is
 * displayed on screen (development mode). Plug in PHPMailer / SMTP later.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth_functions.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $stmt = $GLOBALS['pdo']->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        generate_verification_code($email, 'reset', '');
        flash('info', 'A 6-digit verification code has been ' . (SMS_ENABLED ? 'sent to your phone' : 'generated (check the next page)') . '.');
        redirect('verify.php?email=' . urlencode($email) . '&purpose=reset');
    } else {
        $error = 'No account found with that email address.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/auth.css">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { background: linear-gradient(135deg, #00b4d8 0%, #0077b6 50%, #023e8a 100%); min-height: 100vh; display: flex; align-items: center; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="logo">
                <i class="fas fa-key"></i>
                <h3>Forgot Password</h3>
                <p class="text-muted">We will help you reset it</p>
            </div>

            <?php if ($error): ?><div class="alert alert-danger"><?php echo e($error); ?></div><?php endif; ?>
            <?php if ($notice): ?><div class="alert alert-success"><?php echo $notice; ?></div><?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your account email" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane me-2"></i>Send Reset Link</button>
            </form>

            <div class="auth-footer">
                Remembered it? <a href="login.php">Back to Login</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
