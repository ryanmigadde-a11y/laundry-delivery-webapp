<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/auth_functions.php';

if (is_logged_in()) {
    redirect($_SESSION['user_type'] === 'provider' ? $BASE . 'php/provider/dashboard.php' : $BASE . 'php/customer/dashboard.php');
}

$error = '';
$userType = $_POST['user_type'] ?? 'customer';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$valid, $err] = validate_registration($_POST);
    if (!$valid) {
        $error = $err;
        $userType = $_POST['user_type'] ?? 'customer';
    } else {
        /* Save the pending registration + send an OTP, then verify. */
        $_SESSION['pending_registration'] = $_POST;
        $email = strtolower(trim($_POST['email'] ?? ''));
        generate_verification_code($email, 'register', trim($_POST['phone'] ?? ''));
        $otpChannel = SMS_ENABLED
            ? 'sent to your phone'
            : ((defined('SENDGRID_API_KEY') && SENDGRID_API_KEY) || SMTP_ENABLED
                ? 'sent to your email'
                : 'generated (check the next page)');
        flash('info', 'A 6-digit verification code has been ' . $otpChannel . '.');
        redirect('verify.php?email=' . urlencode($email) . '&purpose=register');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/auth.css">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { background: linear-gradient(135deg, #00b4d8 0%, #0077b6 50%, #023e8a 100%); min-height: 100vh; display: flex; align-items: center; padding: 40px 0; }
        .auth-container { max-width: 550px; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="logo">
                <i class="fas fa-tshirt"></i>
                <h3>Create Account</h3>
                <p class="text-muted">Join us today</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?php echo e($error); ?></div>
            <?php endif; ?>
            <?php echo flash(); ?>

            <!-- User Type Toggle -->
            <div class="d-flex mb-4 gap-2">
                <button type="button" class="btn btn-outline-primary flex-fill <?php echo $userType === 'customer' ? 'active' : ''; ?>" onclick="switchType('customer')">
                    <i class="fas fa-user me-2"></i>Customer
                </button>
                <button type="button" class="btn btn-outline-primary flex-fill <?php echo $userType === 'provider' ? 'active' : ''; ?>" onclick="switchType('provider')">
                    <i class="fas fa-store me-2"></i>Provider
                </button>
            </div>

            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="user_type" id="userType" value="<?php echo e($userType); ?>">

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="full_name" class="form-control" placeholder="Full Name" required value="<?php echo e($_POST['full_name'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" placeholder="youremail@gmail.com" required value="<?php echo e($_POST['email'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Phone *</label>
                        <input type="tel" name="phone" class="form-control" placeholder="+256 700 000000" required value="<?php echo e($_POST['phone'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Location *</label>
                        <input type="text" name="location" class="form-control" placeholder="Kampala, Uganda" required value="<?php echo e($_POST['location'] ?? ''); ?>">
                    </div>
                </div>

                <!-- Provider Fields -->
                <div id="providerFields" style="display: <?php echo $userType === 'provider' ? 'block' : 'none'; ?>;">
                    <hr>
                    <h5 class="mb-3"><i class="fas fa-store me-2"></i>Business Information</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Business Name *</label>
                            <input type="text" name="business_name" class="form-control" placeholder="My Laundry Business" value="<?php echo e($_POST['business_name'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Business Phone</label>
                            <input type="tel" name="business_phone" class="form-control" placeholder="+256 700 000000" value="<?php echo e($_POST['business_phone'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Business Location</label>
                        <input type="text" name="business_location" class="form-control" placeholder="Kampala" value="<?php echo e($_POST['business_location'] ?? ''); ?>">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Confirm Password *</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary"><i class="fas fa-user-plus me-2"></i>Create Account</button>

            </form>
            <div class="divider"><span>or register with</span></div>

            <div class="text-center mb-3">
                <?php if (GOOGLE_CLIENT_ID): ?>
                    <div id="googleBtn"></div>
                <?php else: ?>
                    <button class="btn btn-outline-secondary w-100" onclick="alert('Google Sign-Up is not configured yet. Add your Google Client ID in php/includes/config.php')"><i class="fab fa-google me-2"></i>Sign up with Google</button>
                <?php endif; ?>
            </div>

            <div class="auth-footer">
                Already have an account? <a href="login.php">Sign In</a>
            </div>
            <div class="text-center mt-2">
                <small class="text-muted"><a href="../../index.php" class="text-decoration-none"><i class="fas fa-home me-1"></i>Back to Home</a></small>
            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $BASE; ?>assets/js/auth.js"></script>
    <script>
        function switchType(type) {
            document.getElementById('userType').value = type;
            document.getElementById('providerFields').style.display = type === 'provider' ? 'block' : 'none';
            document.querySelectorAll('.btn-outline-primary').forEach(function (btn) { btn.classList.remove('active'); });
            document.querySelectorAll('.btn-outline-primary')[type === 'customer' ? 0 : 1].classList.add('active');
        }
    </script>
    <?php if (GOOGLE_CLIENT_ID): ?>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <script>
        function handleGoogleRegister(response) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'google_callback.php';
            const c = document.createElement('input');
            c.type = 'hidden'; c.name = 'credential'; c.value = response.credential;
            const t = document.createElement('input');
            t.type = 'hidden'; t.name = 'type'; t.value = 'customer';
            form.appendChild(c); form.appendChild(t);
            document.body.appendChild(form);
            form.submit();
        }
        window.addEventListener('load', function () {
            if (typeof google !== 'undefined' && google.accounts && google.accounts.id) {
                google.accounts.id.initialize({
                    client_id: '<?php echo GOOGLE_CLIENT_ID; ?>',
                    callback: handleGoogleRegister
                });
                google.accounts.id.renderButton(document.getElementById('googleBtn'), { theme: 'outline', size: 'large', width: 320, text: 'continue_with' });
            } else {
                document.getElementById('googleBtn').innerHTML = '<button type="button" class="btn btn-outline-danger w-100" onclick="googlePopupRegister()"><i class="fab fa-google me-2"></i>Sign up with Google</button>';
            }
        });
        function googlePopupRegister() {
            const clientId = '<?php echo GOOGLE_CLIENT_ID; ?>';
            const redirectUri = location.origin + '/laundry%20project/php/auth/google_callback.php';
            const scope = 'email profile';
            const authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?client_id=' + encodeURIComponent(clientId) + '&redirect_uri=' + encodeURIComponent(redirectUri) + '&response_type=token&scope=' + encodeURIComponent(scope) + '&include_granted_scopes=true&prompt=select_account';
            window.location.href = authUrl;
        }
    </script>
    <?php endif; ?>

</body>
</html>
