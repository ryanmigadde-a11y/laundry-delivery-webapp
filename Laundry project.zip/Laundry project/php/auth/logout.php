<?php
$BASE = '../';
require_once __DIR__ . '/../includes/session.php';

session_unset();
session_destroy();
session_start();
flash('success', 'You have been logged out successfully.');
redirect('../../index.php'); // project root landing page (this file lives in php/auth/)
