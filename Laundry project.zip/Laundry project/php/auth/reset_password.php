<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';

$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$error = '';

// Validate token
$stmt = $GLOBALS['pdo']->prepare('SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW() LIMIT 1');
$stmt->execute([$token]);
$reset = $stmt->fetch();

if (!$reset) {
    $error = 'This reset link is invalid or has expired. Request a new one.';
}

if (!$error && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    if (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $stmt = $GLOBALS['pdo']->prepare('UPDATE users SET password_hash = ? WHERE email = ?');
        $stmt->execute([password_hash($password, PASSWORD_DEFAULT), $reset['email']]);
        $GLOBALS['pdo']->prepare('DELETE FROM password_resets WHERE email = ?')->execute([$reset['email']]);
        flash('success', 'Password updated successfully. You can now login.');
        redirect('login.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/auth.css">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { background: linear-gradient(135deg, #00b4d8 0%, #0077b6 50%, #023e8a 100%); min-height: 100vh; display: flex; align-items: center; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="logo">
                <i class="fas fa-lock"></i>
                <h3>Reset Password</h3>
                <p class="text-muted">Choose a new password</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
                <div class="text-center mt-3"><a href="forgot_password.php" class="btn btn-primary">Request New Link</a></div>
            <?php else: ?>
            <form method="POST" action="">
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required minlength="6">
                </div>
                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-check me-2"></i>Update Password</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
