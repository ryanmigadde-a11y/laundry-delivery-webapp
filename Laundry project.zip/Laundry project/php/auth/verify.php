<?php
/**
 * OTP verification page — used for BOTH registration and password reset.
 * In dev mode (SMS/SMTP not configured) the code is displayed in a box.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/auth_functions.php';

if (is_logged_in()) {
    redirect($BASE . 'php/customer/dashboard.php');
}

$purpose = $_GET['purpose'] ?? $_POST['purpose'] ?? 'register';
$email   = $_GET['email'] ?? $_POST['email'] ?? ($_SESSION['pending_registration']['email'] ?? '');
$email   = strtolower(trim($email));
$error   = '';
$verifiedReset = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'verify';
    $code = trim($_POST['code'] ?? '');

    if ($action === 'verify') {
        if (verify_code($email, $code, $purpose)) {
            if ($purpose === 'reset') {
                $verifiedReset = true; // show the new-password form
            } else {
                $data = $_SESSION['pending_registration'] ?? null;
                if (!$data) {
                    flash('danger', 'Your registration session expired. Please register again.');
                    redirect('register.php');
                }
                [$ok, $result] = register_user($data, []);
                if (!$ok) {
                    $error = $result;
                } else {
                    unset($_SESSION['pending_registration']);
                    $stmt = $GLOBALS['pdo']->prepare('SELECT * FROM users WHERE user_id = ?');
                    $stmt->execute([$result]);
                    login_session($stmt->fetch());
                    flash('success', 'Account verified & created. Welcome to LaundryExpress!');
                    redirect($_SESSION['user_type'] === 'provider' ? $BASE . 'php/provider/dashboard.php' : $BASE . 'php/customer/dashboard.php');
                }
            }
        } else {
            $error = 'Invalid or expired verification code. Please try again.';
        }
    }

    if ($action === 'do_reset') {
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';
        if (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } elseif (!verify_code($email, trim($_POST['reset_code'] ?? ''), 'reset')) {
            $error = 'Verification code invalid. Please restart the reset.';
        } else {
            $stmt = $GLOBALS['pdo']->prepare('UPDATE users SET password_hash = ? WHERE email = ?');
            if ($stmt->execute([password_hash($password, PASSWORD_DEFAULT), $email])) {
                $GLOBALS['pdo']->prepare('DELETE FROM password_resets WHERE email = ?')->execute([$email]);
                flash('success', 'Password updated successfully. You can now login.');
                redirect('login.php');
            } else {
                $error = 'Could not update the password.';
            }
        }
    }
}

/* Dev-only: expose the OTP that was "sent". */
$devCode = $_SESSION['otp_sent']['code'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Account | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/auth.css">
    <style>
        body { background: linear-gradient(135deg, #00b4d8 0%, #0077b6 50%, #023e8a 100%); min-height: 100vh; display: flex; align-items: center; padding: 40px 0; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <h3><?php echo $purpose === 'reset' ? 'Verify to Reset Password' : 'Verify Your Email / Phone'; ?></h3>
                <p class="text-muted">Enter the 6-digit code we sent to <strong><?php echo e($email); ?></strong></p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?php echo e($error); ?></div>
            <?php endif; ?>
            <?php echo flash(); ?>

            <?php
            /* Dev mode: show the verification code when SMTP/SMS is not configured
               OR always show a "receive code" section for the user to retrieve it. */
            $otpSession = $_SESSION['otp_sent'] ?? null;
            $showCode = $otpSession && ($otpSession['email'] ?? '') === $email && ($otpSession['purpose'] ?? '') === $purpose;
            if ($showCode):
            ?>
                <div class="alert alert-info text-center mb-3">
                    <i class="fas fa-info-circle me-2"></i><strong>Your Verification Code</strong>
                    <div class="mt-2">
                        <span class="badge bg-dark fs-4 px-4 py-2 letter-spacing-2"><?php echo e($otpSession['code']); ?></span>
                    </div>
                    <small class="d-block mt-2 text-muted">This code is valid for 15 minutes. Enter it below to verify.</small>
                    <?php if (!empty($otpSession['phone'])): ?>
                        <small class="d-block text-muted"><i class="fas fa-phone me-1"></i>Also sent to: <?php echo e($otpSession['phone']); ?></small>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ($purpose === 'reset' && $verifiedReset): ?>
                <!-- Step 2: set a new password after OTP verified -->
                <form method="POST">
                    <input type="hidden" name="action" value="do_reset">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <input type="hidden" name="reset_code" value="<?php echo e($_POST['code'] ?? ''); ?>">
                    <input type="hidden" name="purpose" value="reset">
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required minlength="6">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-key me-2"></i>Update Password</button>
                </form>
            <?php else: ?>
                <!-- Step 1: enter OTP -->
                <form method="POST">
                    <input type="hidden" name="action" value="verify">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <input type="hidden" name="purpose" value="<?php echo e($purpose); ?>">
                    <div class="mb-3">
                        <label class="form-label">6-Digit Verification Code</label>
                        <input type="text" name="code" class="form-control text-center" placeholder="••••••" maxlength="6" required autofocus>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-check-circle me-2"></i>Verify Code</button>
                </form>
                <div class="text-center mt-3">
                    <a href="<?php echo $purpose === 'reset' ? 'forgot_password.php' : 'register.php'; ?>" class="text-decoration-none small">Resend / change details?</a>
                </div>
                <?php if ($showCode): ?>
                <div class="text-center mt-2">
                    <small class="text-muted"><i class="fas fa-clock me-1"></i>Code expires in 15 minutes</small>
                </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="auth-footer">
                <a href="login.php">Back to Login</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>