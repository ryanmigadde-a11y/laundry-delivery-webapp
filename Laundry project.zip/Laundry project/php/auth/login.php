<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/auth_functions.php';

if (is_logged_in()) {
    redirect($_SESSION['user_type'] === 'provider' ? $BASE . 'php/provider/dashboard.php' : $BASE . 'php/customer/dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$ok, $result] = attempt_login($_POST['email'] ?? '', $_POST['password'] ?? '');
    if ($ok) {
        flash('success', 'Welcome back, ' . $result['full_name'] . '!');
        redirect($_SESSION['user_type'] === 'provider' ? $BASE . 'php/provider/dashboard.php' : $BASE . 'php/customer/dashboard.php');
    }
    $error = $result;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/auth.css">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { background: linear-gradient(135deg, #00b4d8 0%, #0077b6 50%, #023e8a 100%); min-height: 100vh; display: flex; align-items: center; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="logo">
                <i class="fas fa-tshirt"></i>
                <h3>Welcome Back</h3>
                <p class="text-muted">Sign in to your account</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?php echo e($error); ?></div>
            <?php endif; ?>
            <?php echo flash(); ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required value="<?php echo e($_POST['email'] ?? ''); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                <div class="mb-3 text-end">
                    <a href="forgot_password.php" class="text-decoration-none" style="color: #0077b6;">Forgot Password?</a>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-sign-in-alt me-2"></i>Sign In</button>
            </form>

            <div class="divider"><span>or continue with</span></div>

            <div class="text-center mb-3">
                <?php if (GOOGLE_CLIENT_ID): ?>
                    <div id="googleBtn"></div>
                <?php else: ?>
                    <button class="btn btn-outline-secondary w-100" onclick="alert('Google Sign-In is not configured yet. Add your Google Client ID in php/includes/config.php')"><i class="fab fa-google me-2"></i>Sign in with Google</button>
                <?php endif; ?>
            </div>

            <div class="auth-footer">
                Don't have an account? <a href="register.php">Create Account</a>
            </div>
            <div class="text-center mt-2">
                <small class="text-muted">
                    <a href="../../index.php" class="text-decoration-none"><i class="fas fa-home me-1"></i>Back to Home</a>
                    &nbsp;|&nbsp;
                    <a href="../admin/login.php" class="text-decoration-none"><i class="fas fa-user-shield me-1"></i>Admin</a>
                </small>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $BASE; ?>assets/js/auth.js"></script>
    <?php if (GOOGLE_CLIENT_ID): ?>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <script>
        function handleGoogleResponse(response) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'google_callback.php';
            const c = document.createElement('input');
            c.type = 'hidden'; c.name = 'credential'; c.value = response.credential;
            const t = document.createElement('input');
            t.type = 'hidden'; t.name = 'type'; t.value = 'customer';
            form.appendChild(c); form.appendChild(t);
            document.body.appendChild(form);
            form.submit();
        }
        window.addEventListener('load', function () {
            if (typeof google !== 'undefined' && google.accounts && google.accounts.id) {
                google.accounts.id.initialize({
                    client_id: '<?php echo GOOGLE_CLIENT_ID; ?>',
                    callback: handleGoogleResponse
                });
                google.accounts.id.renderButton(document.getElementById('googleBtn'), { theme: 'outline', size: 'large', width: 320, text: 'continue_with' });
                google.accounts.id.prompt(); /* show One Tap */
            } else {
                /* Fallback: show a clickable button that uses the OAuth popup flow */
                document.getElementById('googleBtn').innerHTML = '<button type="button" class="btn btn-outline-danger w-100" onclick="googlePopupLogin()"><i class="fab fa-google me-2"></i>Sign in with Google</button>';
            }
        });
        function googlePopupLogin() {
            const clientId = '<?php echo GOOGLE_CLIENT_ID; ?>';
            const redirectUri = location.origin + '/laundry%20project/php/auth/google_callback.php';
            const scope = 'email profile';
            const authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?client_id=' + encodeURIComponent(clientId) + '&redirect_uri=' + encodeURIComponent(redirectUri) + '&response_type=token&scope=' + encodeURIComponent(scope) + '&include_granted_scopes=true&prompt=select_account';
            window.location.href = authUrl;
        }
    </script>
    <?php endif; ?>
</body>
</html>
