<?php
/**
 * Google OAuth callback - handles BOTH:
 * 1. Google Identity Services credential (JWT) via POST
 * 2. OAuth 2.0 access token via GET (fallback popup flow)
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/auth_functions.php';

$type = ($_POST['type'] ?? $_GET['type'] ?? 'customer') === 'provider' ? 'provider' : 'customer';

/* Flow 1: Google Identity Services credential (JWT) */
$credential = $_POST['credential'] ?? '';
if ($credential) {
    $payload = google_verify_credential($credential);
    if (!$payload) {
        flash('danger', 'Google sign-in failed. Please use email & password.');
        redirect('login.php');
    }
    [$ok, $result] = google_login_or_register($payload, $type);
    if (!$ok) {
        flash('danger', $result);
        redirect('login.php');
    }
    flash('success', 'Signed in with Google. Welcome, ' . $result['full_name'] . '!');
    if ($type === 'provider' || $_SESSION['user_type'] === 'provider') {
        redirect($BASE . 'php/provider/dashboard.php');
    }
    redirect($BASE . 'php/customer/dashboard.php');
}

/* Flow 2: OAuth 2.0 access token (fallback popup flow) */
$accessToken = $_GET['access_token'] ?? '';
if ($accessToken) {
    /* Exchange access token for user info from Google */
    $userInfoUrl = 'https://www.googleapis.com/oauth2/v3/userinfo?access_token=' . urlencode($accessToken);
    $response = @file_get_contents($userInfoUrl);
    if ($response) {
        $payload = json_decode($response, true);
        if ($payload && !empty($payload['email'])) {
            /* Normalize to match google_verify_credential format */
            $payload['sub'] = $payload['sub'] ?? '';
            $payload['name'] = $payload['name'] ?? $payload['email'];
            $payload['email_verified'] = $payload['email_verified'] ?? 'true';
            [$ok, $result] = google_login_or_register($payload, $type);
            if ($ok) {
                flash('success', 'Signed in with Google. Welcome, ' . $result['full_name'] . '!');
                if ($type === 'provider' || $_SESSION['user_type'] === 'provider') {
                    redirect($BASE . 'php/provider/dashboard.php');
                }
                redirect($BASE . 'php/customer/dashboard.php');
            }
            flash('danger', $result);
            redirect('login.php');
        }
    }
    flash('danger', 'Failed to retrieve Google account info.');
    redirect('login.php');
}

/* No valid flow detected */
flash('danger', 'Google sign-in failed or is not configured. Please use email & password.');
redirect('login.php');
