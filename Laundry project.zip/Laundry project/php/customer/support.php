<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();

/* ---- Submit feedback / support ticket ---- */
if (isset($_POST['send_message'])) {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    if ($subject === '' || $message === '') {
        flash('danger', 'Subject and message are required.');
    } else {
        $stmt = $pdo->prepare('INSERT INTO support_messages (user_id, name, email, subject, message) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$user['user_id'], $user['full_name'], $user['email'], $subject, $message]);
        flash('success', 'Message sent! Our support team will get back to you soon.');
    }
    redirect('support.php');
}

$stmt = $pdo->prepare('SELECT * FROM support_messages WHERE user_id = ? ORDER BY created_at DESC LIMIT 20');
$stmt->execute([$user['user_id']]);
$myMessages = $stmt->fetchAll();

$active = 'support';
$page_title = 'Support';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-headset me-2"></i>Support &amp; Feedback</h2>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-paper-plane me-2" style="color:#0077b6;"></i>Contact Us</h5>
                    <p class="text-muted">Have a complaint, suggestion or feedback about the system? Send us a message.</p>
                    <form method="POST">
                        <div class="mb-3"><label class="form-label">Subject</label>
                            <input type="text" name="subject" class="form-control" placeholder="e.g. Delivery Issue, Feedback" required>
                        </div>
                        <div class="mb-3"><label class="form-label">Message</label>
                            <textarea name="message" class="form-control" rows="5" placeholder="Tell us what happened or what you would like improved..." required></textarea>
                        </div>
                        <button type="submit" name="send_message" value="1" class="btn btn-primary w-100"><i class="fas fa-paper-plane me-2"></i>Send Message</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-comments me-2" style="color:#0077b6;"></i>My Messages</h5>
                    <?php if (!$myMessages): ?>
                        <p class="text-muted mb-0">You have not contacted support yet.</p>
                    <?php endif; ?>
                    <?php foreach ($myMessages as $m): ?>
                        <div class="border rounded-3 p-3 mb-3 <?php echo $m['is_read'] ? '' : 'border-primary'; ?>">
                            <div class="d-flex justify-content-between">
                                <h6 class="fw-bold mb-1"><?php echo e($m['subject']); ?></h6>
                                <small class="text-muted"><?php echo time_ago($m['created_at']); ?></small>
                            </div>
                            <p class="mb-1"><?php echo e($m['message']); ?></p>
                            <small class="text-muted"><?php echo $m['is_read'] ? '<i class="fas fa-check-double text-success"></i> Reviewed by support' : '<i class="fas fa-clock"></i> Awaiting review'; ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
