<?php
/**
 * Live Pickup & Delivery Tracking — reached via the order QR code.
 * Public token-based view; also shows delivery estimate when available.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';

$pdo = $GLOBALS['pdo'];
$token = trim($_GET['token'] ?? '');
if ($token === '') {
    http_response_code(404);
    die('Missing tracking token.');
}

$stmt = $pdo->prepare(
    'SELECT o.*, p.business_name, p.business_location, p.business_phone FROM orders o
     JOIN providers p ON p.provider_id = o.provider_id WHERE o.unique_order_token = ? LIMIT 1'
);
$stmt->execute([$token]);
$order = $stmt->fetch();
if (!$order) {
    http_response_code(404);
    die('Order not found.');
}

$steps = ['Order Placed', 'Accepted', 'In Progress', 'Out for Delivery', 'Delivered'];
$current = status_step_index($order['status']);
$est = null;
if ($order['status'] === 'out_for_delivery' && $order['delivery_date']) {
    $est = date('g:i A', strtotime($order['delivery_time'] ?? $order['delivery_date']));
}

/* Live map only makes sense once the order exists (always) — it shows the
   station + pickup pins immediately and the courier as soon as they share. */
$page_title = 'Track Order';
$plain = true;
$extra_css = ['assets/vendor/leaflet/leaflet.css'];
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container py-5" style="max-width: 720px;">
    <div class="card border-0 shadow rounded-4 p-4">
        <div class="text-center mb-4">
            <i class="fas fa-truck-fast fa-3x mb-2" style="color:#0077b6;"></i>
            <h3 class="fw-bold mb-0"><?php echo order_code((int)$order['order_id']); ?></h3>
            <div class="text-muted"><?php echo e($order['business_name']); ?> · <?php echo e($order['business_location'] ?: 'Uganda'); ?></div>
        </div>

        <div class="d-flex justify-content-center mb-3">
            <?php echo status_badge($order['status']); ?>
        </div>

        <div class="tracking-progress d-flex align-items-center mb-4">
            <?php foreach ($steps as $i => $step): ?>
                <div class="step-item">
                    <div class="step-circle <?php echo $i <= $current ? 'completed' : ''; ?>">
                        <?php echo $i < $current ? '<i class="fas fa-check"></i>' : ($i + 1); ?>
                    </div>
                    <small class="d-block mt-1"><?php echo e($step); ?></small>
                </div>
                <?php if ($i < count($steps) - 1): ?><div class="step-line <?php echo $i < $current ? 'completed' : ''; ?>"></div><?php endif; ?>
            <?php endforeach; ?>
        </div>

        <hr>

        <!-- Live courier map -->
        <div class="mb-3">
            <div id="trackingMap" class="border" style="height: 320px; width: 100%; border-radius: 12px;"></div>
            <div id="trackStatus" class="small text-muted mt-2"><i class="fas fa-spinner fa-spin me-1"></i>Loading live tracking&hellip;</div>
        </div>

        <div class="row text-center g-2">
            <div class="col-4">
                <small class="text-muted d-block">Pickup</small>
                <strong><?php echo format_date($order['pickup_date']); ?></strong>
            </div>
            <div class="col-4">
                <small class="text-muted d-block">Delivery</small>
                <strong><?php echo format_date($order['delivery_date']); ?></strong>
            </div>
            <div class="col-4">
                <small class="text-muted d-block">Payment</small>
                <strong><?php echo status_badge($order['payment_status']); ?></strong>
            </div>
        </div>

        <?php if ($est): ?>
        <div class="alert alert-success text-center mt-3 mb-0"><i class="fas fa-clock me-2"></i>Estimated arrival today around <strong><?php echo e($est); ?></strong></div>
        <?php endif; ?>
    </div>
</div>
<script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
<script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
<script>
    window.TRACK_CONFIG = {
        apiUrl:  '<?php echo $BASE; ?>php/api/tracking.php',
        token:   <?php echo json_encode((string)$order['unique_order_token']); ?>,
        pollMs:  5000,
        statusEl: 'trackStatus'
    };
</script>
<script src="<?php echo $BASE; ?>assets/js/order_tracking.js"></script>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>