<?php
/**
 * Payment receipt — print-friendly, downloadable as PDF via the browser
 * (the "Download PDF" button opens the print dialog and lets you Save as PDF).
 * Receipts are generated automatically once an order's payment is
 * paid (wallet) or confirmed by the provider (cash / mobile money).
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$uid = (int)$user['user_id'];
$orderId = (int)($_GET['order_id'] ?? 0);

ensure_demo_upgrade_tables();

$stmt = $pdo->prepare(
    'SELECT r.*, o.*, o.unique_order_token,
            p.business_name AS provider_business, p.business_phone AS provider_phone, p.business_location AS provider_location,
            c.full_name AS customer_name, c.email AS customer_email, c.phone AS customer_phone
     FROM receipts r
     JOIN orders o ON o.order_id = r.order_id
     JOIN providers p ON p.provider_id = r.provider_id
     JOIN users c ON c.user_id = r.customer_id
     WHERE r.order_id = ? AND r.customer_id = ? LIMIT 1'
);
$stmt->execute([$orderId, $uid]);
$row = $stmt->fetch();

/* Auto-generate a receipt if the order qualifies (paid/confirmed) but none exists yet. */
if (!$row) {
    ensure_order_receipt($orderId);
    $stmt->execute([$orderId, $uid]);
    $row = $stmt->fetch();
}

if (!$row) {
    flash('warning', 'No receipt is available for this order yet. Receipts appear once the payment is paid or confirmed by the provider.');
    redirect('orders.php');
}

/* Itemized lines */
$stmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY item_id ASC');
$stmt->execute([$orderId]);
$items = $stmt->fetchAll();

$amountPaid = (float)$row['amount_paid'];
$payLabel = in_array($row['payment_status'], ['paid', 'confirmed'], true) ? 'Paid' : ucfirst((string)$row['payment_status']);
$payClass = in_array($row['payment_status'], ['paid', 'confirmed'], true) ? 'text-success' : 'text-warning';

$page_title = 'Payment Receipt ' . $row['receipt_no'];
$plain = true;
include BASE_PATH . '/php/partials/header.php';
?>
<style>
    #receipt-print { max-width: 780px; }
    @media print { #receipt-toolbar { display: none; } body { background: #fff; } }
</style>
<nav class="navbar navbar-expand-lg navbar-dark bg-gradient-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo $BASE; ?>index.php"><i class="fas fa-tshirt me-2"></i>LaundryExpress</a>
    </div>
</nav>
<div class="container my-4" style="max-width: 860px;">
    <div id="receipt-toolbar" class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <a href="order_details.php?id=<?php echo $orderId; ?>" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-2"></i>Back to Order</a>
        <button type="button" class="btn btn-primary" onclick="window.print()"><i class="fas fa-file-pdf me-2"></i>Download PDF</button>
    </div>

    <div class="card border-0 shadow-sm rounded-4 p-4" id="receipt-print">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <h3 class="fw-bold" style="color:#0077b6;"><i class="fas fa-tshirt me-2"></i>LaundryExpress</h3>
                <small class="text-muted d-block">Uganda &middot; Kampala<br><?php echo e(get_config('support_email', 'support@laundryexpress.ug')); ?> &middot; <?php echo e(get_config('support_phone', '+256 700 123456')); ?></small>
            </div>
            <div class="text-end">
                <h5 class="fw-bold mb-1">PAYMENT RECEIPT</h5>
                <small class="text-muted d-block">Receipt No: <strong><?php echo e($row['receipt_no']); ?></strong></small>
                <small class="text-muted d-block">Order: <strong><?php echo order_code((int)$row['order_id']); ?></strong></small>
                <small class="text-muted d-block">Issued: <?php echo date('d M Y, h:i A', strtotime($row['paid_at'] ?: $row['created_at'])); ?></small>
            </div>
        </div>
        <hr>
        <div class="row g-3">
            <div class="col-md-6">
                <h6 class="fw-bold small mb-1">BILLED TO</h6>
                <p class="mb-1"><strong><?php echo e($row['customer_name']); ?></strong></p>
                <p class="mb-1 small text-muted"><?php echo e($row['customer_phone'] ?: ''); ?><?php if ($row['customer_email']): ?><br><?php echo e($row['customer_email']); ?><?php endif; ?></p>
                <p class="mb-0 small text-muted"><?php echo e((string)($row['pickup_address'] ?? 'Kampala, Uganda')); ?></p>
            </div>
            <div class="col-md-6">
                <h6 class="fw-bold small mb-1">SERVICE PROVIDER</h6>
                <p class="mb-1"><strong><?php echo e($row['provider_business']); ?></strong></p>
                <p class="mb-1 small text-muted"><?php echo e((string)($row['provider_phone'] ?? '')); ?><?php if ($row['provider_location']): ?><br><?php echo e($row['provider_location']); ?><?php endif; ?></p>
                <p class="mb-0 small text-muted">Pickup: <?php echo format_date($row['pickup_date']); ?> &middot; Delivery: <?php echo format_date($row['delivery_date']); ?></p>
            </div>
        </div>

        <hr>

        <h6 class="fw-bold small mb-2">ORDER ITEMS</h6>
        <table class="table table-sm mb-2">
            <thead><tr><th>Service</th><th>Item</th><th class="text-end">Qty</th><th class="text-end">Price</th><th class="text-end">Subtotal</th></tr></thead>
            <tbody>
                <?php foreach ($items as $it): ?>
                <tr>
                    <td><?php echo e($it['service_name']); ?></td>
                    <td><?php echo e($it['clothing_type']); ?></td>
                    <td class="text-end"><?php echo (int)$it['quantity']; ?></td>
                    <td class="text-end"><?php echo format_ugx($it['price_per_item']); ?></td>
                    <td class="text-end fw-bold"><?php echo format_ugx($it['subtotal']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="row p-2 mt-2 rounded-3" style="background:#f0f6ff;">
            <div class="col-4"><small class="text-muted d-block">AMOUNT PAID</small><span class="fs-5 fw-bold" style="color:#0077b6;"><?php echo format_ugx($amountPaid); ?></span></div>
            <div class="col-4"><small class="text-muted d-block">PAYMENT METHOD</small>
                <strong><?php echo e(ucfirst(str_replace('_', ' ', $row['payment_method']))); ?></strong>
                <?php if ($row['payment_method'] === 'mobile_money' && $row['mobile_number']): ?><br><small class="text-muted"><?php echo e(strtoupper((string)($row['mobile_network'] ?? ''))); ?> &middot; <?php echo e($row['mobile_number']); ?></small><?php endif; ?>
            </div>
            <div class="col-4"><small class="text-muted d-block">PAYMENT STATUS</small><span class="fw-bold <?php echo $payClass; ?>"><?php echo e($payLabel); ?></span></div>
        </div>

        <p class="text-muted small mt-3 mb-1"><i class="fas fa-check-circle text-success me-1"></i>This receipt is evidence of payment for order <?php echo order_code((int)$row['order_id']); ?>. Keep it safe for your records.</p>
        <div class="text-center"><small class="text-muted d-block mb-0">Thank you for choosing LaundryExpress Uganda!</small></div>
    </div>
</div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>