<?php
/**
 * Laundry Protection / Dispute Center — customers report missing items,
 * damage, poor cleaning, late delivery or wrong items; each becomes an
 * admin case with a unique ID.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

if (!feature_enabled('disputes')) {
    flash('info', 'The Dispute Center is currently disabled.');
    redirect('orders.php');
}

$pdo = $GLOBALS['pdo'];
$user = current_user();
$uid = (int)$user['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['open_dispute'])) {
    $orderId = (int)($_POST['order_id'] ?? 0);
    $type = in_array($_POST['type'] ?? '', ['missing_item', 'damage', 'poor_cleaning', 'late_delivery', 'wrong_item', 'other'], true) ? $_POST['type'] : 'other';
    $desc = trim($_POST['description'] ?? '');
    $stmt = $pdo->prepare('SELECT order_id, provider_id FROM orders WHERE order_id = ? AND customer_id = ? LIMIT 1');
    $stmt->execute([$orderId, $uid]);
    $order = $stmt->fetch();
    if (!$order) {
        flash('danger', 'Order not found.');
    } elseif ($desc === '') {
        flash('danger', 'Please describe the issue.');
    } else {
        $code = 'DSP-' . strtoupper(bin2hex(random_bytes(3)));
        $pdo->prepare('INSERT INTO disputes (dispute_code, order_id, customer_id, provider_id, type, description) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$code, $orderId, $uid, (int)$order['provider_id'], $type, $desc]);
        add_dispute_message((int)$pdo->lastInsertId(), 'customer', $uid, 'Dispute opened: ' . $desc);
        add_notification($uid, 'Dispute Opened', 'Your case ' . $code . ' has been opened. Our team will review it.', 'php/customer/disputes.php');
        add_notification((int)$order['provider_id'], 'Dispute Opened', 'A customer opened dispute ' . $code . ' on one of your orders. Please give your side.', 'php/provider/disputes.php');
        flash('success', 'Dispute ' . $code . ' opened. You will be updated here.');
        audit_log('dispute_opened', 'Customer ' . $uid . ' opened ' . $code . ' for order ' . $orderId);
    }
    redirect('disputes.php');
}

/* ---- Reply inside a dispute conversation (customer <-> provider <-> admin) ---- */
if (isset($_POST['dispute_reply'])) {
    $did = (int)($_POST['reply_dispute_id'] ?? 0);
    $msg = trim($_POST['reply_message'] ?? '');
    if ($did > 0 && $msg !== '') {
        $v = $pdo->prepare('SELECT dispute_id, provider_id, dispute_code FROM disputes WHERE dispute_id = ? AND customer_id = ? LIMIT 1');
        $v->execute([$did, $uid]);
        $vd = $v->fetch();
        if ($vd) {
            add_dispute_message($did, 'customer', $uid, $msg);
            add_notification((int)$vd['provider_id'], 'New Dispute Message', 'The customer replied on dispute ' . $vd['dispute_code'] . '.', 'php/provider/disputes.php');
            flash('success', 'Message sent.');
        } else {
            flash('danger', 'Dispute not found.');
        }
    }
    redirect('disputes.php');
}

$stmt = $pdo->prepare(
    "SELECT o.order_id, o.total_price, o.created_at, p.business_name
     FROM orders o JOIN providers p ON p.provider_id = o.provider_id
     WHERE o.customer_id = ? AND o.status IN ('delivered','completed')
       AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       AND o.order_id NOT IN (SELECT order_id FROM disputes WHERE customer_id = ?)
     ORDER BY o.created_at DESC LIMIT 10"
);
$stmt->execute([$uid, $uid]);
$eligible = $stmt->fetchAll();
/* ---- My disputes ---- */
$stmt = $pdo->prepare(
    'SELECT d.*, o.status AS order_status, p.business_name
     FROM disputes d JOIN orders o ON o.order_id = d.order_id JOIN providers p ON p.provider_id = d.provider_id
     WHERE d.customer_id = ? ORDER BY d.created_at DESC'
);
$stmt->execute([$uid]);
$disputes = $stmt->fetchAll();
$types = ['missing_item' => 'Missing Item', 'damage' => 'Damage', 'poor_cleaning' => 'Poor Cleaning', 'late_delivery' => 'Late Delivery', 'wrong_item' => 'Wrong Item', 'other' => 'Other'];

$active = 'disputes';
$page_title = 'Laundry Protection';
include BASE_PATH . '/php/partials/header.php';
?>

<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-shield-halved me-2"></i>Laundry Protection / Dispute Center</h2>
        <p class="text-muted mb-4">Report an issue and track your case with its unique dispute ID.</p>

        <div class="row g-4">
            <div class="col-md-5">
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-flag me-2" style="color:#f5576c;"></i>Report a Problem</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Order</label>
                            <select name="order_id" class="form-select" required>
                                <option value="">— Select a delivered/completed order —</option>
                                <?php foreach ($eligible as $o): ?>
                                <option value="<?php echo (int)$o['order_id']; ?>"><?php echo order_code((int)$o['order_id']); ?> · <?php echo e($o['business_name']); ?> · <?php echo format_date($o['created_at']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Issue type</label>
                            <select name="type" class="form-select">
                                <?php foreach ($types as $k => $v): ?><option value="<?php echo $k; ?>"><?php echo $v; ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Describe what happened</label>
                            <textarea name="description" class="form-control" rows="3" required placeholder="e.g. One white shirt is missing from my order..."></textarea>
                        </div>
                        <button type="submit" name="open_dispute" value="1" class="btn btn-danger w-100"><i class="fas fa-shield-halved me-2"></i>Open Dispute</button>
                    </form>
                    <?php if (!$eligible): ?><p class="text-muted small mt-3 mb-0">No eligible orders right now (delivered/completed in the last 30 days without an open dispute).</p><?php endif; ?>
                </div>
            </div>

            <div class="col-md-7">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-folder-open me-2" style="color:#0077b6;"></i>My Cases</h5>
                    <?php if (!$disputes): ?>
                        <p class="text-muted text-center py-4 mb-0">You have no disputes.</p>
                    <?php endif; ?>
                    <?php foreach ($disputes as $d): ?>
                    <div class="border rounded-3 p-3 mb-3">
                        <div class="d-flex justify-content-between flex-wrap gap-2">
                            <div>
                                <strong><?php echo e($d['dispute_code']); ?></strong>
                                <br><small class="text-muted"><?php echo e($types[$d['type']] ?? $d['type']); ?> · <?php echo e($d['business_name']); ?> · <?php echo format_date($d['created_at']); ?></small>
                            </div>
                            <span class="badge <?php echo $d['status'] === 'resolved' ? 'bg-success' : ($d['status'] === 'open' ? 'bg-danger' : 'bg-warning text-dark'); ?>"><?php echo e(ucwords(str_replace('_', ' ', $d['status']))); ?></span>
                        </div>
                        <p class="mb-1 mt-2"><?php echo e($d['description']); ?></p>
                        <div class="bg-light border rounded-3 p-2 small mb-2">
                            <strong class="small"><i class="fas fa-comments me-1"></i>Conversation (you / provider / admin)</strong>
                            <?php echo dispute_thread_html(dispute_thread((int)$d['dispute_id'])); ?>
                        </div>
                        <?php if ($d['status'] !== 'resolved' && $d['status'] !== 'rejected'): ?>
                        <form method="POST" class="d-flex gap-2 align-items-center mt-2">
                            <input type="hidden" name="reply_dispute_id" value="<?php echo (int)$d['dispute_id']; ?>">
                            <input type="text" name="reply_message" class="form-control form-control-sm" placeholder="Reply to the provider / share more details...">
                            <button type="submit" name="dispute_reply" value="1" class="btn btn-sm btn-outline-primary text-nowrap"><i class="fas fa-paper-plane me-1"></i>Send</button>
                        </form>
                        <?php endif; ?>
                        <?php if ($d['admin_note']): ?><div class="alert alert-light border mt-2 mb-0 small"><i class="fas fa-comment me-1"></i><strong>Admin:</strong> <?php echo e($d['admin_note']); ?></div><?php endif; ?>
                        <?php if ($d['status'] === 'resolved' && (float)$d['refund_amount'] > 0): ?><div class="alert alert-success mt-2 mb-0 small"><i class="fas fa-wallet me-1"></i>Refund of <?php echo format_ugx($d['refund_amount']); ?> credited to your wallet.</div><?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>