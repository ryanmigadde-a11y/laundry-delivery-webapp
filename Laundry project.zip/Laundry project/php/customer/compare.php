<?php
/**
 * Smart Price Comparison — compare providers by price, rating, speed,
 * reliability and location with Best Value / Cheapest / Fastest / Highest
 * Rated / Closest labels.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

if (!feature_enabled('compare')) {
    flash('info', 'Price comparison is currently disabled.');
    redirect('dashboard.php');
}

$pdo = $GLOBALS['pdo'];
$user = current_user();
$location = trim((string)$user['location']);

$service  = trim($_GET['service'] ?? 'Wash & Fold');
$clothing = trim($_GET['clothing'] ?? 'Shirt');

$services = ['Wash & Fold', 'Dry Cleaning', 'Pressing Only', 'Stain Removal', 'Shoe Cleaning', 'Bedding & Curtains'];
$clothes  = clothing_type_list();
if (!in_array($service, $services, true)) $service = $services[0];
if (!in_array($clothing, $clothes, true)) $clothing = $clothes[0];

$rows = $pdo->prepare(
    "SELECT p.provider_id, p.business_name, p.business_location, p.verification_status, p.eco_score,
            pr.price,
            COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.provider_id = p.provider_id), 0) AS avg_rating,
            (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = p.provider_id) AS review_count,
            (SELECT COUNT(*) FROM orders o WHERE o.provider_id = p.provider_id AND o.status IN ('delivered','completed')) AS completed,
            (SELECT AVG(DATEDIFF(h.changed_at, o.created_at)) FROM orders o
                JOIN order_status_history h ON h.order_id = o.order_id AND h.status_to = 'delivered'
                WHERE o.provider_id = p.provider_id AND o.status IN ('delivered','completed')) AS avg_days
     FROM provider_pricing pr
     JOIN providers p ON p.provider_id = pr.provider_id
     JOIN users u ON u.user_id = p.provider_id
     WHERE pr.service_name = ? AND pr.clothing_type = ? AND p.is_approved = 1 AND u.status = 'active'
     ORDER BY pr.price ASC"
);
$rows->execute([$service, $clothing]);
$rows = $rows->fetchAll();

/* Annotate + find label winners */
foreach ($rows as &$r) {
    $r['reliability'] = provider_reliability((int)$r['provider_id']);
    $r['rel_score'] = $r['reliability'] ? $r['reliability']['score'] : 60;
    $r['avg_days'] = $r['avg_days'] !== null ? round((float)$r['avg_days'], 1) : null;
    $r['close'] = $location !== '' && stripos((string)$r['business_location'], $location) !== false;
    $r['value_score'] = ((float)$r['avg_rating'] * 20) + $r['rel_score'] * 0.4 - ((float)$r['price'] / 1000);
    $r['is_closest'] = false;
}
unset($r);
$closest = null;
foreach ($rows as $i => $r) { if ($r['close']) { $closest = $i; break; } }
if ($closest !== null) $rows[$closest]['is_closest'] = true;

$labels = [];
if ($rows) {
    $cheapest = null; $fastest = null; $rated = null; $value = null; $reliable = null;
    foreach ($rows as $i => $r) {
        if ($cheapest === null || $r['price'] < $rows[$cheapest]['price']) $cheapest = $i;
        if ($r['avg_days'] !== null && ($fastest === null || $rows[$fastest]['avg_days'] === null || $r['avg_days'] < $rows[$fastest]['avg_days'])) $fastest = $i;
        if ($rated === null || $r['avg_rating'] > $rows[$rated]['avg_rating']) $rated = $i;
        if ($value === null || $r['value_score'] > $rows[$value]['value_score']) $value = $i;
        if ($reliable === null || $r['rel_score'] > $rows[$reliable]['rel_score']) $reliable = $i;
    }
    foreach (['cheapest' => 'Cheapest', 'fastest' => 'Fastest', 'rated' => 'Highest Rated', 'value' => 'Best Value', 'reliable' => 'Most Reliable'] as $k => $lbl) {
        if ($$k !== null) $labels[$$k][] = $lbl;
    }
}

$active = 'compare';
$page_title = 'Price Comparison';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-scale-balanced me-2"></i>Smart Price Comparison</h2>
        <p class="text-muted mb-4">Compare providers for the same service before you order.</p>

        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-4">
                    <label class="form-label small mb-1">Service</label>
                    <select name="service" class="form-select">
                        <?php foreach ($services as $s): ?><option value="<?php echo e($s); ?>" <?php echo $s === $service ? 'selected' : ''; ?>><?php echo e($s); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small mb-1">Clothing Type</label>
                    <select name="clothing" class="form-select">
                        <?php foreach ($clothes as $c): ?><option value="<?php echo e($c); ?>" <?php echo $c === $clothing ? 'selected' : ''; ?>><?php echo e($c); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-primary w-100"><i class="fas fa-scale-balanced me-2"></i>Compare Providers</button>
                </div>
            </form>
        </div>

        <?php if (!$rows): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-store-slash fa-3x text-muted mb-3"></i>
                <p class="text-muted mb-0">No provider offers <strong><?php echo e($service); ?> — <?php echo e($clothing); ?></strong> yet.</p>
            </div>
        <?php else: ?>
        <div class="card border-0 shadow-sm rounded-4 p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead><tr><th>Provider</th><th>Price</th><th>Rating</th><th>Speed</th><th>Reliability</th><th>Badges</th><th></th></tr></thead>
                    <tbody>
                        <?php foreach ($rows as $i => $r): ?>
                        <tr>
                            <td>
                                <strong><?php echo e($r['business_name']); ?></strong><br>
                                <small class="text-muted"><?php echo e($r['business_location'] ?: 'Uganda'); ?></small>
                                <?php if ($r['is_closest']): ?><div><span class="badge bg-info mt-1"><i class="fas fa-location-dot me-1"></i>Closest to you</span></div><?php endif; ?>
                            </td>
                            <td class="fw-bold" style="color:#0077b6;"><?php echo format_ugx($r['price']); ?></td>
                            <td><?php echo star_icons($r['avg_rating'], true); ?> <small class="text-muted">(<?php echo (int)$r['review_count']; ?>)</small></td>
                            <td><?php echo $r['avg_days'] !== null ? $r['avg_days'] . ' days' : '<span class="text-muted">new</span>'; ?></td>
                            <td>
                                <span class="badge <?php echo $r['rel_score'] >= 80 ? 'bg-success' : ($r['rel_score'] >= 60 ? 'bg-warning text-dark' : 'bg-secondary'); ?>">
                                    <?php echo $r['rel_score']; ?>/100
                                </span>
                            </td>
                            <td>
                                <?php foreach ($labels[$i] ?? [] as $lbl): ?><span class="badge bg-dark mb-1"><?php echo e($lbl); ?></span><?php endforeach; ?>
                                <?php echo provider_badges($r); ?>
                            </td>
                            <td><a href="<?php echo $BASE; ?>php/customer/new_order/services.php?provider_id=<?php echo (int)$r['provider_id']; ?>" class="btn btn-sm btn-primary">Order</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>