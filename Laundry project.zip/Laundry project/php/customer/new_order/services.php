<?php
$BASE = '../../../';
require_once __DIR__ . '/../../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$providerId = (int)($_GET['provider_id'] ?? 0);

/* Smart Assistant token: if customer built an order in the Assistant, load it */
$assistantToken = $_GET['assistant_token'] ?? '';
$assistantDraft = null;
if ($assistantToken && isset($_SESSION['order_drafts'][$assistantToken])) {
    $assistantDraft = $_SESSION['order_drafts'][$assistantToken];
    /* Override provider_id with the one they picked */
    $_SESSION['order_drafts'][$assistantToken]['provider_id'] = $providerId;
}

$stmt = $pdo->prepare(
    'SELECT p.*, u.status AS account_status FROM providers p JOIN users u ON u.user_id = p.provider_id
     WHERE p.provider_id = ? AND p.is_approved = 1 LIMIT 1'
);
$stmt->execute([$providerId]);
$provider = $stmt->fetch();

if (!$provider || $provider['account_status'] !== 'active') {
    flash('danger', 'Provider not found or unavailable.');
    redirect('select_provider.php');
}

$grouped = provider_pricing_grouped($providerId);
$rating = provider_rating($providerId);

$active = 'new_order';
$page_title = 'Select Services';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h2 class="fw-bold mb-0"><i class="fas fa-list me-2"></i>Select Services</h2>
            <a href="select_provider.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-2"></i>Change Provider</a>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4" style="background: linear-gradient(135deg, #0077b6, #00b4d8); color: #fff;">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center">
                    <?php if ($provider['profile_pic']): ?>
                        <img src="<?php echo $BASE; ?>assets/images/uploads/<?php echo rawurlencode($provider['profile_pic']); ?>" class="rounded-circle me-3" width="64" height="64" style="object-fit: cover;" alt="logo">
                    <?php else: ?>
                        <i class="fas fa-store fa-3x me-3"></i>
                    <?php endif; ?>
                    <div>
                        <h4 class="fw-bold mb-1"><?php echo e($provider['business_name']); ?></h4>
                        <small><i class="fas fa-map-marker-alt me-1"></i><?php echo e($provider['business_location'] ?: 'Uganda'); ?> &nbsp; <?php echo star_icons($rating['avg']); ?> <span class="ms-1">(<?php echo $rating['count']; ?> reviews)</span></small>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($assistantDraft): ?>
        <div class="alert alert-info mb-4">
            <i class="fas fa-robot me-2"></i><strong>Smart Assistant order loaded:</strong>
            <?php echo count($assistantDraft['items']); ?> item<?php echo count($assistantDraft['items']) !== 1 ? 's' : ''; ?> pre-selected below.
            Adjust quantities if needed, then continue.
        </div>
        <?php endif; ?>

        <?php if (!$grouped): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-tags fa-3x text-muted mb-3"></i>
                <p class="text-muted">This provider has not set up their price menu yet. Please check back later or pick another provider.</p>
                <a href="select_provider.php" class="btn btn-primary mx-auto">Back to Providers</a>
            </div>
        <?php else: ?>
        <form method="POST" action="schedule.php" id="servicesForm">
            <input type="hidden" name="provider_id" value="<?php echo $providerId; ?>">
            <?php if ($assistantToken): ?><input type="hidden" name="assistant_token" value="<?php echo e($assistantToken); ?>"><?php endif; ?>
            <?php foreach ($grouped as $serviceName => $rows): ?>
            <div class="card border-0 shadow-sm rounded-4 mb-3">
                <div class="card-header bg-transparent border-bottom-0 pt-3 px-4">
                    <h5 class="fw-bold mb-0"><i class="fas <?php echo service_icon($serviceName); ?> me-2" style="color: #0077b6;"></i><?php echo e($serviceName); ?></h5>
                </div>
                <div class="card-body p-4">
                    <?php foreach ($rows as $row): ?>
                    <?php
                        $pricingId = (int)$row['pricing_id'];
                        /* Pre-fill qty from Smart Assistant draft */
                        $preQty = 0;
                        if ($assistantDraft) {
                            foreach ($assistantDraft['items'] as $aitem) {
                                if ((int)$aitem['pricing_id'] === $pricingId || ($aitem['service_name'] === $row['service_name'] && $aitem['clothing_type'] === $row['clothing_type'])) {
                                    $preQty = max($preQty, (int)$aitem['quantity']);
                                }
                            }
                        }
                    ?>
                    <div class="row align-items-center mb-3 item-row">
                        <div class="col-md-4"><h6 class="mb-0"><?php echo e($row['clothing_type']); ?></h6>
                            <small class="text-muted"><?php echo e($row['service_name']); ?></small>
                        </div>
                        <div class="col-md-3 text-center"><span class="fw-bold" style="color: #0077b6;"><?php echo format_ugx($row['price']); ?></span></div>
                        <div class="col-md-3">
                            <div class="input-group">
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="decrementQty(this)">-</button>
                                <input type="number" class="form-control text-center item-qty" name="qty[<?php echo $pricingId; ?>]" value="<?php echo $preQty; ?>" min="0" max="200" data-price="<?php echo (float)$row['price']; ?>">
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="incrementQty(this)">+</button>
                            </div>
                        </div>
                        <div class="col-md-2 text-end"><span class="item-subtotal">UGX 0</span></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="card border-0 shadow-sm rounded-4 sticky-bottom mt-3">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8"><h4 class="fw-bold mb-0">Total: <span id="grandTotal">UGX 0</span></h4></div>
                        <div class="col-md-4 text-end">
                            <button type="submit" class="btn btn-primary btn-lg w-100" id="scheduleBtn" disabled><i class="fas fa-calendar me-2"></i>Schedule Dates</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php endif; ?>
    </main>
</div></div>
<?php $extra_scripts = ['assets/js/customer.js']; $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
