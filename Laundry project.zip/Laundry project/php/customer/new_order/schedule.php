<?php
/**
 * Schedule step of the new-order flow.
 * Receives the item quantities POSTed from services.php, stores a draft in
 * the session under a unique order_token, then lets the customer pick
 * dates / address / instructions before proceeding to payment.
 */
$BASE = '../../../';
require_once __DIR__ . '/../../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();

/* ---- Build (or rebuild) the draft from the services form ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['draft_token'])) {
    $providerId = (int)($_POST['provider_id'] ?? 0);
    $qty = $_POST['qty'] ?? [];
    $assistantToken = $_POST['assistant_token'] ?? '';

    /* Smart Assistant flow: merge updated quantities into the existing draft */
    if ($assistantToken && isset($_SESSION['order_drafts'][$assistantToken])) {
        $existing = $_SESSION['order_drafts'][$assistantToken];
        $token = $assistantToken;
        /* Re-verify items against the chosen provider's pricing */
        $items = [];
        $total = 0;
        foreach ($existing['items'] as $it) {
            $stmt = $pdo->prepare('SELECT * FROM provider_pricing WHERE provider_id = ? AND service_name = ? AND clothing_type = ? LIMIT 1');
            $stmt->execute([$providerId, $it['service_name'], $it['clothing_type']]);
            $row = $stmt->fetch();
            if (!$row) continue;
            /* Use the (possibly updated) qty from the services form if present */
            $q = max(1, (int)($qty[(int)$row['pricing_id']] ?? (int)$it['quantity']));
            $subtotal = $q * (float)$row['price'];
            $items[] = [
                'pricing_id'    => (int)$row['pricing_id'],
                'service_name'  => $it['service_name'],
                'clothing_type' => $it['clothing_type'],
                'quantity'      => $q,
                'price'         => (float)$row['price'],
                'subtotal'      => $subtotal,
            ];
            $total += $subtotal;
        }
        if (!$items) {
            flash('warning', 'None of your items are offered by this provider. Please pick another.');
            redirect('select_provider.php?assistant_token=' . urlencode($assistantToken));
        }
        $_SESSION['order_drafts'][$token] = [
            'customer_id' => $user['user_id'],
            'provider_id' => $providerId,
            'items'       => $items,
            'total'       => $total,
        ];
        redirect('schedule.php?order_token=' . $token);
    }

    $stmt = $pdo->prepare(
        'SELECT p.*, u.status AS account_status FROM providers p JOIN users u ON u.user_id = p.provider_id
         WHERE p.provider_id = ? AND p.is_approved = 1 LIMIT 1'
    );
    $stmt->execute([$providerId]);
    $provider = $stmt->fetch();
    if (!$provider || $provider['account_status'] !== 'active') {
        flash('danger', 'Please select a valid provider first.');
        redirect('select_provider.php');
    }

    /* Fetch pricing rows for the selected quantities */
    $items = [];
    $total = 0;
    if ($qty) {
        $ids = array_map('intval', array_keys($qty));
        $in = implode(',', $ids);
        $rows = $pdo->query("SELECT * FROM provider_pricing WHERE provider_id = $providerId AND pricing_id IN ($in)")->fetchAll();
        foreach ($rows as $row) {
            $q = max(0, min(200, (int)($qty[$row['pricing_id']] ?? 0)));
            if ($q > 0) {
                $subtotal = $q * (float)$row['price'];
                $items[] = [
                    'pricing_id'    => (int)$row['pricing_id'],
                    'service_name'  => $row['service_name'],
                    'clothing_type' => $row['clothing_type'],
                    'quantity'      => $q,
                    'price'         => (float)$row['price'],
                    'subtotal'      => $subtotal,
                ];
                $total += $subtotal;
            }
        }
    }

    if (!$items) {
        flash('warning', 'Please select at least one laundry item before scheduling.');
        redirect('services.php?provider_id=' . $providerId . ($assistantToken ? '&assistant_token=' . urlencode($assistantToken) : ''));
    }

    $token = bin2hex(random_bytes(8));
    $_SESSION['order_drafts'][$token] = [
        'customer_id' => $user['user_id'],
        'provider_id' => $providerId,
        'items'       => $items,
        'total'       => $total,
    ];
    redirect('schedule.php?order_token=' . $token);
}

/* ---- Save the scheduling choices into the draft, then go to payment ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['draft_token'])) {
    $token = trim($_POST['draft_token']);
    $draft = $_SESSION['order_drafts'][$token] ?? null;
    if (!$draft || (int)$draft['customer_id'] !== (int)$user['user_id']) {
        flash('warning', 'Your order session expired. Please start again.');
        redirect('select_provider.php');
    }

    $pickupDate = trim($_POST['pickup_date'] ?? '');
    $pickupTime = trim($_POST['pickup_time'] ?? '');
    $deliveryDate = trim($_POST['delivery_date'] ?? '');
    $deliveryTime = trim($_POST['delivery_time'] ?? '');
    $address     = trim($_POST['pickup_address'] ?? '');
    $instructions = trim($_POST['special_instructions'] ?? '');

    if ($pickupDate === '' || $pickupTime === '' || $deliveryDate === '' || $deliveryTime === '' || $address === '') {
        flash('danger', 'Please fill in the pickup and delivery dates, times and your address.');
        redirect('schedule.php?order_token=' . urlencode($token));
    }
    if (strtotime($deliveryDate) < strtotime($pickupDate)) {
        flash('danger', 'The delivery date cannot be before the pickup date.');
        redirect('schedule.php?order_token=' . urlencode($token));
    }

    $_SESSION['order_drafts'][$token]['pickup_date']         = $pickupDate;
    $_SESSION['order_drafts'][$token]['pickup_time']         = $pickupTime;
    $_SESSION['order_drafts'][$token]['delivery_date']       = $deliveryDate;
    $_SESSION['order_drafts'][$token]['delivery_time']       = $deliveryTime;
    $_SESSION['order_drafts'][$token]['pickup_address']      = $address;
    $_SESSION['order_drafts'][$token]['special_instructions'] = $instructions;

    redirect('payment.php?order_token=' . urlencode($token));
}

/* ---- Display the scheduling form ---- */
$token = $_GET['order_token'] ?? $_POST['draft_token'] ?? '';
$draft = $_SESSION['order_drafts'][$token] ?? null;

if (!$draft || (int)$draft['customer_id'] !== (int)$user['user_id']) {
    flash('warning', 'Your order session expired. Please start again.');
    redirect('select_provider.php');
}

$stmt = $pdo->prepare('SELECT business_name FROM providers WHERE provider_id = ?');
$stmt->execute([$draft['provider_id']]);
$providerName = $stmt->fetchColumn() ?: 'Provider';

$stmt = $pdo->prepare('SELECT location FROM users WHERE user_id = ?');
$stmt->execute([$user['user_id']]);
$profileLocation = (string)$stmt->fetchColumn();

$active = 'new_order';
$page_title = 'Schedule Pickup & Delivery';
include BASE_PATH . '/php/partials/header.php';
$today = date('Y-m-d');
$times = ['08:00 AM','09:00 AM','10:00 AM','11:00 AM','12:00 PM','01:00 PM','02:00 PM','03:00 PM','04:00 PM','05:00 PM'];
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-calendar-check me-2"></i>Schedule Dates</h2>
        <p class="text-muted mb-4">Order for <strong><?php echo e($providerName); ?></strong> &bull; Total <strong><?php echo format_ugx($draft['total']); ?></strong></p>

        <form method="POST" action="schedule.php">
            <input type="hidden" name="draft_token" value="<?php echo e($token); ?>">

            <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                <h5 class="fw-bold mb-3"><i class="fas fa-truck-pickup me-2" style="color: #0077b6;"></i>Select Pickup Date &amp; Time</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Pickup Date</label>
                        <input type="date" name="pickup_date" class="form-control" min="<?php echo $today; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Pickup Time</label>
                        <select name="pickup_time" class="form-select" required>
                            <option value="">Select pickup time</option>
                            <?php foreach ($times as $t): ?><option value="<?php echo $t; ?>"><?php echo $t; ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                <h5 class="fw-bold mb-3"><i class="fas fa-calendar-check me-2" style="color: #0077b6;"></i>Select Delivery Date &amp; Time</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Delivery Date</label>
                        <input type="date" name="delivery_date" class="form-control" min="<?php echo $today; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Delivery Time</label>
                        <select name="delivery_time" class="form-select" required>
                            <option value="">Select delivery time</option>
                            <?php foreach ($times as $t): ?><option value="<?php echo $t; ?>"><?php echo $t; ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                <h5 class="fw-bold mb-3"><i class="fas fa-map-marker-alt me-2" style="color: #0077b6;"></i>Pickup Address</h5>
                <div class="mb-3">
                    <input type="text" name="pickup_address" class="form-control" value="<?php echo e($profileLocation); ?>" placeholder="House / Street / Area" required>
                </div>
                <div class="mb-0">
                    <label class="form-label fw-bold">Special Instructions (Optional)</label>
                    <textarea name="special_instructions" class="form-control" rows="3" placeholder="Any special instructions for the provider..."></textarea>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 p-4">
                <div class="row align-items-center">
                    <div class="col-md-8"><h4 class="fw-bold mb-0">Order Total: <span style="color: #0077b6;"><?php echo format_ugx($draft['total']); ?></span></h4></div>
                    <div class="col-md-4 text-end">
                        <button type="submit" class="btn btn-primary btn-lg w-100"><i class="fas fa-credit-card me-2"></i>Proceed to Payment</button>
                    </div>
                </div>
            </div>
        </form>

    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
