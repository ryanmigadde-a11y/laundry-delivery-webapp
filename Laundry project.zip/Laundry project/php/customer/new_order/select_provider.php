<?php
$BASE = '../../../';
require_once __DIR__ . '/../../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$location = trim((string)$user['location']);

/* Assistant token: if customer built an order in the Smart Assistant, pass it through */
$assistantToken = $_GET['assistant_token'] ?? '';

/* Providers in the customer's area first, then others (approved + active only) */
$sql = "SELECT p.provider_id, p.business_name, p.business_location, p.business_phone, p.profile_pic,
               COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.provider_id = p.provider_id), 0) AS avg_rating,
               (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = p.provider_id) AS review_count
        FROM providers p JOIN users u ON u.user_id = p.provider_id
        WHERE p.is_approved = 1 AND u.status = 'active'";
if ($location !== '') {
    $sql .= " ORDER BY (p.business_location LIKE " . $pdo->quote('%' . $location . '%') . ") DESC, avg_rating DESC";
} else {
    $sql .= " ORDER BY avg_rating DESC";
}
$providers = $pdo->query($sql)->fetchAll();

$active = 'new_order';
$page_title = 'Select Provider';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-plus-circle me-2"></i>New Order</h2>
        <p class="text-muted mb-4"><i class="fas fa-map-marker-alt me-1"></i>Showing laundry providers near <strong><?php echo e($location ?: 'you'); ?></strong></p>

        <?php if ($assistantToken && isset($_SESSION['order_drafts'][$assistantToken])): ?>
            <?php $draft = $_SESSION['order_drafts'][$assistantToken]; ?>
            <div class="alert alert-info mb-4">
                <i class="fas fa-robot me-2"></i><strong>Smart Assistant order ready:</strong>
                <?php echo count($draft['items']); ?> item<?php echo count($draft['items']) !== 1 ? 's' : ''; ?> ·
                estimated <?php echo format_ugx($draft['total']); ?> — pick a provider to continue.
            </div>
        <?php endif; ?>

        <?php if (!$providers): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-store fa-3x text-muted mb-3"></i>
                <p class="text-muted">No providers available yet. Please check back soon.</p>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <?php foreach ($providers as $p):
                /* Latest 2 reviews for the mini feed */
                $stmt = $pdo->prepare(
                    'SELECT r.rating, r.comment, u.full_name FROM reviews r JOIN users u ON u.user_id = r.customer_id
                     WHERE r.provider_id = ? ORDER BY r.created_at DESC LIMIT 2'
                );
                $stmt->execute([$p['provider_id']]);
                $recentReviews = $stmt->fetchAll();
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 provider-card">
                    <div class="card-body text-center p-4">
                        <div class="mb-3">
                            <?php if ($p['profile_pic']): ?>
                                <img src="<?php echo $BASE; ?>assets/images/uploads/<?php echo rawurlencode($p['profile_pic']); ?>" class="rounded-circle" width="80" height="80" style="object-fit: cover;" alt="logo">
                            <?php else: ?>
                                <i class="fas fa-store fa-4x" style="color: #0077b6;"></i>
                            <?php endif; ?>
                        </div>
                        <h5 class="fw-bold"><?php echo e($p['business_name']); ?></h5>
                        <div class="mb-2">
                            <?php echo star_icons($p['avg_rating']); ?>
                            <small class="text-muted">(<?php echo (int)$p['review_count']; ?> reviews)</small>
                        </div>
                        <p class="text-muted mb-1"><i class="fas fa-map-marker-alt me-1"></i><?php echo e($p['business_location'] ?: 'Uganda'); ?></p>
                        <p class="text-muted mb-3"><i class="fas fa-phone me-1"></i><?php echo e($p['business_phone'] ?: '&mdash;'); ?></p>
                        <?php if ($recentReviews): ?>
                        <div class="recent-reviews mb-3">
                            <hr>
                            <small class="fw-bold text-muted">Recent Reviews</small>
                            <?php foreach ($recentReviews as $r): ?>
                            <div class="review-item text-start mt-2">
                                <small><strong><?php echo e($r['full_name']); ?></strong> <?php echo star_icons($r['rating'], true); ?></small>
                                <p class="mb-0 small text-muted">"<?php echo e($r['comment']); ?>"</p>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        <a href="services.php?provider_id=<?php echo (int)$p['provider_id']; ?><?php echo $assistantToken ? '&assistant_token=' . urlencode($assistantToken) : ''; ?>" class="btn btn-primary w-100"><i class="fas fa-arrow-right me-2"></i>Select Provider</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
