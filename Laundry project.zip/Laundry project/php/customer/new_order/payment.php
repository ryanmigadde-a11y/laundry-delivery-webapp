<?php
/**
 * Payment step: order summary + payment method selection + simulated
 * Mobile Money USSD push. "Complete Order" creates the real order.
 */
$BASE = '../../../';
require_once __DIR__ . '/../../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();

$token = $_GET['order_token'] ?? $_POST['order_token'] ?? $_POST['draft_token'] ?? '';
$draft = $_SESSION['order_drafts'][$token] ?? null;

if (!$draft || (int)$draft['customer_id'] !== (int)$user['user_id']) {
    flash('warning', 'Your order session expired. Please start again.');
    redirect('select_provider.php');
}

/* If the browser submitted scheduling details with this request (legacy flow),
   persist them into the session draft so the order is created with the dates. */
foreach (['pickup_date', 'pickup_time', 'delivery_date', 'delivery_time', 'pickup_address', 'special_instructions'] as $f) {
    if (isset($_POST[$f]) && is_array($_SESSION['order_drafts'][$token])) {
        $_SESSION['order_drafts'][$token][$f] = trim((string)$_POST[$f]);
    }
}
$draft = $_SESSION['order_drafts'][$token];

/* ---- Complete Order: create the real order ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    /* The scheduling step must have been completed first. */
    if (empty($draft['pickup_date']) || empty($draft['pickup_address'])) {
        flash('danger', 'Please complete the pickup &amp; delivery scheduling step first.');
        redirect('schedule.php?order_token=' . urlencode($token));
    }
    $method = $_POST['payment_method'] ?? '';
    if (!in_array($method, ['cash_on_pickup', 'cash_on_delivery', 'mobile_money', 'wallet'], true)) {
        flash('danger', 'Please choose a valid payment method.');
        redirect('payment.php?order_token=' . urlencode($token));
    }

    /* Payment is recorded as 'pending' until the provider confirms they received it.
       This protects against customers claiming non-payment (cash or mobile money). */
    $paid = false;
    $network = null;
    $number = null;

    if ($method === 'mobile_money') {
        $mm = $_SESSION['mm_payments'][$token] ?? null;
        if (!$mm || ($mm['status'] ?? '') !== 'success') {
            flash('danger', 'Your mobile money payment has not been confirmed yet. Please complete the payment first.');
            redirect('payment.php?order_token=' . urlencode($token));
        }
        $network = $mm['network'];
        $number = $mm['phone'];
    }
    if ($method === 'wallet') {
        if (!feature_enabled('wallet')) {
            flash('danger', 'Wallet payments are currently disabled.');
            redirect('payment.php?order_token=' . urlencode($token));
        }
        $paid = true; // the wallet is debited immediately when the order is placed
    }
/* Re-verify prices server-side from provider_pricing */
    $verifiedTotal = 0;
    $itemRows = [];
    foreach ($draft['items'] as $it) {
        $stmt = $pdo->prepare('SELECT * FROM provider_pricing WHERE pricing_id = ? AND provider_id = ? LIMIT 1');
        $stmt->execute([(int)$it['pricing_id'], (int)$draft['provider_id']]);
        $row = $stmt->fetch();
        if (!$row) continue;
        $q = max(1, (int)$it['quantity']);
        $subtotal = $q * (float)$row['price'];
        $itemRows[] = [$row['service_name'], $row['clothing_type'], $q, (float)$row['price'], $subtotal, trim((string)($it['color'] ?? ''))];
        $verifiedTotal += $subtotal;
    }

    if (!$itemRows || $verifiedTotal <= 0) {
        flash('danger', 'Could not verify your items. Please start the order again.');
        redirect('select_provider.php');
    }

    $deduction = 0; // per-order platform fee removed - providers use a monthly subscription
    $orderToken = bin2hex(random_bytes(16));

    /* Promo code */
    $promoCode = strtoupper(trim($_POST['promo_code'] ?? ''));
    $discount = 0.0;
    $promoRow = null;
    if ($promoCode !== '' && feature_enabled('promotions')) {
        [$okP, $msgP, $discount, $promoRow] = validate_promo($promoCode, $verifiedTotal);
        if (!$okP) {
            flash('danger', $msgP);
            redirect('payment.php?order_token=' . urlencode($token));
        }
        $verifiedTotal = max(0, $verifiedTotal - $discount);
    }

    /* Loyalty points redemption (100 points = UGX 10,000 off) */
    $pointsUsed = 0;
    if (!empty($_POST['use_points']) && feature_enabled('loyalty') && (int)$user['loyalty_points'] >= 100) {
        $maxPoints = (int)floor($user['loyalty_points'] / 100) * 100;
        $pointsToUse = min($maxPoints, (int)floor($verifiedTotal / POINT_VALUE) * 100);
        if ($pointsToUse >= 100) {
            $pointValue = $pointsToUse / 100 * (POINT_VALUE / 100) * 100; // points * value
            $pointsCredit = $pointsToUse * (POINT_VALUE / 100); // UGX value per point
            $pointsCredit = min($pointsCredit, $verifiedTotal);
            $verifiedTotal -= $pointsCredit;
            $pointsUsed = (int)$pointsToUse;
        }
    }

    /* Wallet payment: "Use Wallet" pays the entire order from the Laundry
       Wallet (just like Mobile Money). Other methods can still top up with
       the optional partial-wallet field (legacy behaviour). */
    $useWallet = ($method === 'wallet')
        ? (float)($_POST['wallet_amount'] ?? 0)
        : (float)($_POST['wallet_amount_partial'] ?? 0);
    if (feature_enabled('wallet') && $method === 'wallet') {
        $bal = wallet_balance((int)$user['user_id']);
        if ($bal < $verifiedTotal - 0.001) {
            flash('danger', 'Insufficient wallet balance. Please top up your Laundry Wallet or choose another payment method.');
            redirect('payment.php?order_token=' . urlencode($token));
        }
        $useWallet = $verifiedTotal; // take the full order total out of the wallet
    } elseif ($useWallet > 0 && feature_enabled('wallet')) {
        $bal = wallet_balance((int)$user['user_id']);
        $useWallet = min($useWallet, $bal, $verifiedTotal);
        $verifiedTotal -= $useWallet;
    }
if ($verifiedTotal <= 0) $verifiedTotal = 0;

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare(
            'INSERT INTO orders (unique_order_token, customer_id, provider_id, status, pickup_date, pickup_time, delivery_date, delivery_time,

    
                pickup_address, special_instructions, payment_method, payment_status, mobile_network, mobile_number,
                promo_code, discount_amount, points_used, wallet_paid, subtotal, platform_deduction, total_price)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $orderToken, $user['user_id'], (int)$draft['provider_id'], 'pending',
            $draft['pickup_date'], $draft['pickup_time'], $draft['delivery_date'], $draft['delivery_time'],
            $draft['pickup_address'], $draft['special_instructions'], $method,
            $paid ? 'paid' : 'pending', $network, $number,
            $promoCode, $discount, $pointsUsed, $useWallet,
            $verifiedTotal, $deduction, $verifiedTotal,
        ]);
        $orderId = (int)$pdo->lastInsertId();

        $stmtItem = $pdo->prepare('INSERT INTO order_items (order_id, service_name, clothing_type, quantity, price_per_item, subtotal, color) VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach ($itemRows as $r) {
            $stmtItem->execute([$orderId, $r[0], $r[1], $r[2], $r[3], $r[4], $r[5]]);
        }

        record_history($orderId, null, 'pending', $user['user_id']);

        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', 'Could not place the order: ' . $e->getMessage());
        redirect('payment.php?order_token=' . urlencode($token));
    }

    if ($useWallet > 0) {
        wallet_tx((int)$user['user_id'], $useWallet, 'debit', 'Paid towards order ' . order_code($orderId), $orderId);
    }
    if ($pointsUsed > 0) {
        $pdo->prepare('UPDATE users SET loyalty_points = loyalty_points - ? WHERE user_id = ?')->execute([$pointsUsed, (int)$user['user_id']]);
    }
    if ($promoRow) {
        $pdo->prepare('UPDATE promotions SET used_count = used_count + 1 WHERE promo_id = ?')->execute([(int)$promoRow['promo_id']]);
    }

    unset($_SESSION['order_drafts'][$token], $_SESSION['mm_payments'][$token]);

    add_notification((int)$draft['provider_id'], 'New Order Received', 'New order ' . order_code($orderId) . ' from ' . $user['full_name'] . '. Accept it now.', 'php/provider/order_details.php?id=' . $orderId);
    add_notification($user['user_id'], 'Order Placed', 'Your order ' . order_code($orderId) . ' has been placed and is waiting for the provider to accept it.', 'php/customer/order_details.php?id=' . $orderId);
    if ($method === 'mobile_money') {
        add_notification($user['user_id'], 'Mobile Money Sent', 'Your mobile money payment of ' . format_ugx($verifiedTotal) . ' for order ' . order_code($orderId) . ' was sent. The provider will confirm receipt.', 'php/customer/order_details.php?id=' . $orderId);
    }

    flash('success', 'Order placed successfully!');
    redirect('../order_details.php?id=' . $orderId);
}

/* ---- Show the payment page ---- */
$stmt = $pdo->prepare('SELECT business_name FROM providers WHERE provider_id = ?');
$stmt->execute([$draft['provider_id']]);
$providerName = $stmt->fetchColumn() ?: 'Provider';

$active = 'new_order';
$page_title = 'Payment';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-credit-card me-2"></i>Payment</h2>
        <div class="row g-4">
            <div class="col-md-7">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-wallet me-2"></i>Choose Payment Method</h5>
                    <form method="POST" id="paymentForm">
                        <input type="hidden" name="order_token" value="<?php echo e($token); ?>">
                        <input type="hidden" name="payment_method" id="paymentMethod" value="">
                        <input type="hidden" name="order_token_sim" id="orderToken" value="<?php echo e($token); ?>">
                        <div class="payment-options">
                            <label class="payment-option">
                                <input type="radio" name="payment_radio" value="cash_on_pickup" onclick="selectPayment('cash_on_pickup')">
                                <div class="payment-card"><i class="fas fa-store fa-3x" style="color: #0077b6;"></i><h6 class="mt-2 fw-bold">Cash on Pickup</h6><small class="text-muted">Pay cash when we pick up your clothes</small></div>
                            </label>
                            <label class="payment-option">
                                <input type="radio" name="payment_radio" value="cash_on_delivery" onclick="selectPayment('cash_on_delivery')">
                                <div class="payment-card"><i class="fas fa-truck fa-3x" style="color: #0077b6;"></i><h6 class="mt-2 fw-bold">Cash on Delivery</h6><small class="text-muted">Pay when your clothes are delivered</small></div>
                            </label>
                            <label class="payment-option">
                                <input type="radio" name="payment_radio" value="mobile_money" onclick="selectPayment('mobile_money')">
                                <div class="payment-card"><i class="fas fa-mobile-alt fa-3x" style="color: #0077b6;"></i><h6 class="mt-2 fw-bold">Mobile Money</h6><small class="text-muted">MTN / Airtel Money</small></div>
                            </label>
                            <?php if (feature_enabled('wallet')): ?>
                            <label class="payment-option">
                                <input type="radio" name="payment_radio" value="wallet" onclick="selectPayment('wallet')">
                                <div class="payment-card"><i class="fas fa-wallet fa-3x" style="color: #0077b6;"></i><h6 class="mt-2 fw-bold">Use Wallet</h6><small class="text-muted">Pay instantly from your Laundry Wallet</small></div>
                            </label>
                            <?php endif; ?>
                        </div>

                        <div id="mobileMoneyFields" class="mt-4" style="display: none;">
                            <div class="mobile-money-card">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Select Network</label>
                                    <select class="form-select" id="mobileNetwork">
                                        <option value="mtn">MTN Mobile Money</option>
                                        <option value="airtel">Airtel Money</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Mobile Number</label>
                                    <input type="tel" class="form-control" id="mobileNumber" placeholder="+256 700 000000">
                                </div>
                                <button type="button" class="btn btn-success w-100 mb-3" onclick="simulatePayment()"><i class="fas fa-mobile-alt me-2"></i>Pay with Mobile Money</button>
                                <div id="paymentSimulation" style="display: none;"></div>
                            </div>
                        </div>

                        <div id="walletFields" class="mt-4" style="display: none;">
                            <div class="mobile-money-card">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Amount to pay from your Wallet</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-coins"></i></span>
                                        <input type="number" name="wallet_amount" id="walletAmount" class="form-control" min="0" step="500" placeholder="Enter amount" value="<?php echo e((float)$draft['total']); ?>">
                                        <span class="input-group-text">UGX</span>
                                    </div>
                                    <div class="form-text"><i class="fas fa-wallet me-1"></i>Available balance: <strong><?php echo format_ugx(wallet_balance((int)$user['user_id'])); ?></strong>. Your whole order is paid from the wallet.</div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 p-3 border rounded-4 bg-light">
                            <h6 class="fw-bold"><i class="fas fa-ticket me-2"></i>Promo code</h6>
                            <div class="input-group mb-2">
                                <input type="text" name="promo_code" class="form-control" placeholder="Enter promo code (optional)" value="<?php echo e($_POST['promo_code'] ?? ($_GET['promo'] ?? '')); ?>">
                                <button class="btn btn-outline-primary" type="button" onclick="this.form.submit()">Apply</button>
                            </div>
<!-- Wallet Pay section always visible below -->
                           
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-100 mt-4" id="completeOrderBtn" disabled><i class="fas fa-check-circle me-2"></i>Complete Order</button>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-receipt me-2"></i>Order Summary</h5>
                    <hr>
                    <p class="mb-1 text-muted"><i class="fas fa-store me-2"></i><?php echo e($providerName); ?></p>
                    <?php foreach ($draft['items'] as $it): ?>
                    <div class="d-flex justify-content-between mb-1 small">
                        <span><?php echo e($it['clothing_type']); ?> (<?php echo e($it['service_name']); ?>) x<?php echo (int)$it['quantity']; ?></span>
                        <span class="fw-bold"><?php echo format_ugx($it['subtotal']); ?></span>
                    </div>
                    <?php endforeach; ?>
                    <hr>
                    <div class="d-flex justify-content-between mb-2"><span>Pickup</span><span class="fw-bold"><?php echo format_date($draft['pickup_date'] ?? null); ?> <?php echo e($draft['pickup_time'] ?? ''); ?></span></div>
                    <div class="d-flex justify-content-between mb-2"><span>Delivery</span><span class="fw-bold"><?php echo format_date($draft['delivery_date'] ?? null); ?> <?php echo e($draft['delivery_time'] ?? ''); ?></span></div>
                    <div class="d-flex justify-content-between mb-2"><span>Address</span><span class="fw-bold text-end" style="max-width: 60%;"><?php echo e($draft['pickup_address'] ?? ''); ?></span></div>
                    <hr>
                    <div class="d-flex justify-content-between mb-3"><span class="fs-5 fw-bold">Total</span><span class="fs-5 fw-bold" style="color: #0077b6;"><?php echo format_ugx($draft['total']); ?></span></div>
                    <div class="alert alert-info mb-0 small"><i class="fas fa-shield-alt me-2"></i>Payments are simulated for this demo. A real deployment would integrate MTN MoMo / Airtel Money APIs.</div>
                </div>
            </div>
        </div>

    </main>
</div></div>
<script>
    window.BASE_PATH_AJAX = '<?php echo $BASE; ?>';
    window.PAYMENT_PURPOSE = 'order';
</script>
<input type="hidden" id="totalAmount" value="<?php echo (float)$draft['total']; ?>">
<?php $extra_scripts = ['assets/js/payment_simulator.js']; $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
