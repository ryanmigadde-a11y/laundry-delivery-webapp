<?php
/**
 * Provider Leaderboard — ranks providers using ratings, completed orders,
 * reliability, response time and delivery performance.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];

$rows = $pdo->query(
    "SELECT p.provider_id, p.business_name, p.business_location, p.verification_status, p.eco_score,
            COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.provider_id = p.provider_id), 0) AS avg_rating,
            (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = p.provider_id) AS review_count,
            (SELECT COUNT(*) FROM orders o WHERE o.provider_id = p.provider_id) AS total_orders,
            (SELECT COUNT(*) FROM orders o WHERE o.provider_id = p.provider_id AND o.status IN ('delivered','completed')) AS completed_orders
     FROM providers p JOIN users u ON u.user_id = p.provider_id
     WHERE p.is_approved = 1 AND u.status = 'active'"
)->fetchAll();

foreach ($rows as &$r) {
    $rel = provider_reliability((int)$r['provider_id']);
    $days = provider_avg_delivery_days((int)$r['provider_id']);
    $r['rel'] = $rel ? $rel['score'] : 60;
    $r['days'] = $days;
    $r['response'] = max(0, min(100, 100 - (int)$r['total_orders'])); // proxy
    $r['delivery_perf'] = $rel ? $rel['on_time'] : 100;
    // Composite 0-100: 30% rating, 25% reliability, 20% delivery, 15% response, 10% volume
    $r['leader_score'] = round(
        min(100, ((float)$r['avg_rating'] / 5) * 30 + $r['rel'] * 0.25 + $r['delivery_perf'] * 0.20 + $r['response'] * 0.15 + min(20, (int)$r['completed_orders'] * 2))
    );
}
unset($r);
usort($rows, fn($a, $b) => $b['leader_score'] <=> $a['leader_score']);

$active = 'leaderboard';
$page_title = 'Provider Leaderboard';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-ranking-star me-2"></i>Provider Leaderboard</h2>
        <p class="text-muted mb-4">Ranked by ratings, reliability, delivery performance, response and order volume.</p>

        <div class="card border-0 shadow-sm rounded-4 p-4">
            <?php if (!$rows): ?>
                <p class="text-muted text-center py-4 mb-0">No providers yet.</p>
            <?php endif; ?>
            <div class="row g-3">
                <?php foreach ($rows as $i => $r): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 h-100 provider-card">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="fs-3 fw-bold <?php echo $i === 0 ? 'text-warning' : 'text-muted'; ?>">#<?php echo $i + 1; ?></span>
                                <span class="badge bg-primary fs-6"><?php echo $r['leader_score']; ?>/100</span>
                            </div>
                            <h5 class="fw-bold mb-0"><?php echo e($r['business_name']); ?></h5>
                            <small class="text-muted d-block mb-2"><?php echo e($r['business_location'] ?: 'Uganda'); ?></small>
                            <?php echo provider_badges($r); ?>
                            <hr>
                            <div class="d-flex justify-content-between small mb-1">
                                <span class="text-muted">Rating</span><strong><?php echo number_format((float)$r['avg_rating'], 1); ?> ★ (<?php echo (int)$r['review_count']; ?>)</strong>
                            </div>
                            <div class="d-flex justify-content-between small mb-1">
                                <span class="text-muted">Reliability</span><strong><?php echo $r['rel']; ?>/100</strong>
                            </div>
                            <div class="d-flex justify-content-between small mb-1">
                                <span class="text-muted">Completed orders</span><strong><?php echo (int)$r['completed_orders']; ?></strong>
                            </div>
                            <div class="d-flex justify-content-between small mb-2">
                                <span class="text-muted">Avg delivery</span><strong><?php echo $r['days'] !== null ? $r['days'] . ' days' : '—'; ?></strong>
                            </div>
                            <a href="<?php echo $BASE; ?>php/customer/new_order/services.php?provider_id=<?php echo (int)$r['provider_id']; ?>" class="btn btn-sm btn-primary w-100"><i class="fas fa-arrow-right me-1"></i>Order from them</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>