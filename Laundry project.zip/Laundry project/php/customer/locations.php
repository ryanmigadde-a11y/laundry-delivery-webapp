<?php
/**
 * Live Laundry Stations — interactive map (OpenStreetMap via Leaflet, no API key).
 * Shows ONLY registered + active providers. Every provider pins their exact
 * station position (GPS "Locate Me" / pin drop) from their Business Settings;
 * providers without saved GPS coordinates fall back to a lightweight Uganda
 * location dictionary so they are never lost from the map.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);


$pdo = $GLOBALS['pdo'];
$user = current_user();
$uid  = (int)$user['user_id'];

/* Auto-migration: providers table must have latitude/longitude columns. */
ensure_provider_location_columns();

/* ---- Uganda location helpers (shared dictionary in includes/functions.php) ---- */
$myLoc = ug_geo_find($user['location']);
$myLat = $myLoc ? $myLoc['lat'] : 0.3136;
$myLng = $myLoc ? $myLoc['lng'] : 32.5811;

/* ---- All registered + active providers (only these appear on the map) ---- */
$providers = $pdo->query(
    "SELECT p.provider_id, p.business_name, p.business_location, p.business_phone, p.profile_pic,
            p.verification_status, p.eco_score, p.latitude, p.longitude, p.location_updated_at,
            COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.provider_id = p.provider_id),0) AS avg_rating,
            (SELECT COUNT(*) FROM orders o WHERE o.provider_id = p.provider_id AND o.status IN ('delivered','completed')) AS completed,
            (SELECT COUNT(*) FROM provider_pricing pr WHERE pr.provider_id = p.provider_id) AS menu_items
     FROM providers p JOIN users u ON u.user_id = p.provider_id
     WHERE p.is_approved = 1 AND u.status = 'active'
     ORDER BY p.business_name ASC"
)->fetchAll();

/* ---- Annotate coordinates: saved GPS first, then the dictionary, then Kampala so nothing disappears ---- */
foreach ($providers as &$pr) {
    $hasGps = is_numeric($pr['latitude']) && is_numeric($pr['longitude']);
    $g = ug_geo_find($pr['business_location']);
    $pr['lat']       = $hasGps ? (float)$pr['latitude']  : ($g ? (float)$g['lat'] : 0.3136);
    $pr['lng']       = $hasGps ? (float)$pr['longitude'] : ($g ? (float)$g['lng'] : 32.5811);
    $pr['gps_set']   = $hasGps;
    $pr['geo_name']  = $g ? $g['name'] : 'unknown';
    $pr['km']        = $myLoc ? ug_geo_km($myLat, $myLng, $pr['lat'], $pr['lng']) : null;
}
unset($pr);

/* ---- in-area = same dictionary entry; nearby = within 15km ---- */
$inArea = []; $nearby = []; $others = [];
foreach ($providers as $pr) {
    if ($myLoc && $pr['geo_name'] === $myLoc['name']) $inArea[] = $pr;
    elseif ($pr['km'] !== null && $pr['km'] <= 15) $nearby[] = $pr;
    else $others[] = $pr;
}
function _distsort($a, $b) { return ($a['km'] ?? 9999) <=> ($b['km'] ?? 9999); }
usort($inArea, '_distsort');
usort($nearby, '_distsort');

$mapCenter = ['lat' => $myLat, 'lng' => $myLng];

/* ---- small card helper for a provider ---- */
function _loc_card($pr, $BASE)
{
    $starsHtml = '';
    $starCount = (float)$pr['avg_rating'] > 0 ? max(1, min(5, round((float)$pr['avg_rating']))) : 0;
    for ($i = 1; $i <= 5; $i++) {
        $starsHtml .= $i <= $starCount
            ? '<i class="fas fa-star text-warning"></i>'
            : '<i class="far fa-star text-muted"></i>';
    }
    $badge = ($pr['verification_status'] ?? '') === 'verified'
        ? ' <i class="fas fa-check-circle text-success" title="Verified"></i>'
        : '';
    $gps = !empty($pr['gps_set'])
        ? ' <i class="fas fa-satellite me-1"></i>GPS ' . round((float)$pr['lat'], 4) . ', ' . round((float)$pr['lng'], 4)
        : '';
    $km = $pr['km'] !== null ? ' <i class="fas fa-map-pin me-1"></i>~' . round((float)$pr['km']) . ' km' : '';
    return '<div class="col-md-4"><div class="card border-0 shadow-sm rounded-4 h-100 p-3">'
        . '<h6 class="fw-bold mb-1">' . e((string)$pr['business_name']) . $badge . '</h6>'
        . '<small class="text-muted d-block mb-1"><i class="fas fa-location-dot me-1"></i>' . e((string)$pr['business_location']) . $km . '</small>'
        . '<small class="d-block mb-2">' . $starsHtml . ' <span class="text-muted">(' . (int)$pr['completed'] . ' orders)</span></small>'
        . ($gps !== '' ? '<small class="d-block small text-muted mb-1">' . $gps . '</small>' : '')
        . '<a href="' . $BASE . 'php/customer/new_order/services.php?provider_id=' . (int)$pr['provider_id'] . '" class="btn btn-sm btn-outline-primary mt-auto">View Menu</a>'
        . '</div></div>';
}

$active = 'locations';
$page_title = 'Laundry Stations Near You';

/* ---- Search filter ---- */
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $allProviders = array_merge($inArea, $nearby, $others);
    $filtered = array_filter($allProviders, function($p) use ($search) {
        return stripos($p['business_name'], $search) !== false || stripos($p['business_location'], $search) !== false;
    });
    $inArea = []; $nearby = []; $others = [];
    foreach ($filtered as $pr) {
        if ($myLoc && $pr['geo_name'] === $myLoc['name']) $inArea[] = $pr;
        elseif ($pr['km'] !== null && $pr['km'] <= 15) $nearby[] = $pr;
        else $others[] = $pr;
    }
}

include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-map-marked-alt me-2"></i>Laundry Stations Near You</h2>
        <p class="text-muted mb-3">
            Live map of every <strong>approved, active provider station</strong>. Purple truck markers mean a provider is currently sharing live GPS; other markers show the saved station location.
            <?php echo $myLoc ? 'You are registered in <strong>' . e((string)$user['location']) . '</strong>.' : 'Update your Location in <a href="settings.php">Settings</a> to see distances.'; ?>
        </p>

        <!-- Search bar -->
        <div class="row mb-4">
            <div class="col-md-6">
                <form method="GET" class="d-flex gap-2">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-start-0" placeholder="Search by station name or area..." value="<?php echo e($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Search</button>
                    <?php if ($search): ?><a href="locations.php" class="btn btn-outline-secondary">Clear</a><?php endif; ?>
                </form>
            </div>
            <div class="col-md-6 d-flex align-items-center justify-content-md-end">
                <small class="text-muted">
                    <i class="fas fa-map-pin me-1"></i>
                    <?php $totalStations = count($inArea) + count($nearby) + count($others); ?>
                    <?php echo $totalStations; ?> station<?php echo $totalStations !== 1 ? 's' : ''; ?> found <button type="button" class="btn btn-sm btn-link p-0 ms-1" onclick="useGps()"><i class="fas fa-location-arrow me-1"></i>Locate Me (GPS)</button><span class="small text-muted ms-2" id="gpsStatus"></span>
                    <?php if ($search) echo ' for "' . e($search) . '"'; ?>
                </small>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 p-0 overflow-hidden">
                    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet.css">
                    <div id="liveMap" style="height: 480px; width: 100%;"></div>
                            <div id="providerMapStatus" class="small px-3 py-2 bg-light border-top" role="status">Loading approved laundry providers...</div>
                            <div class="d-flex align-items-center justify-content-between bg-white border-top px-3 py-2 flex-wrap gap-2">
                                <button type="button" class="btn btn-sm btn-primary" onclick="useGps()"><i class="fas fa-location-arrow me-1"></i>Locate Me (GPS)</button>
                                <small class="text-muted"><i class="fas fa-satellite me-1"></i>Tap <strong>Locate Me</strong> to see stations around your real GPS position</small>
                                <small class="text-muted" id="liveStationsStamp"><i class="fas fa-sync-alt fa-spin me-1"></i>Station map is live — refreshes every 45s</small>
                            </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-list me-2" style="color:#0077b6;"></i>Legend</h5>
                    <div class="d-flex align-items-center mb-2"><span class="me-2" style="width:14px;height:14px;border-radius:50%;background:#0077b6;display:inline-block;"></span> In your area</div>
                    <div class="d-flex align-items-center mb-2"><span class="me-2" style="width:14px;height:14px;border-radius:50%;background:#28a745;display:inline-block;"></span> Nearby (&le;15 km)</div>
                    <div class="d-flex align-items-center mb-2"><span class="me-2" style="width:14px;height:14px;border-radius:50%;background:#f5a623;display:inline-block;"></span> Other stations</div>
                    <div class="d-flex align-items-center mb-2"><span class="me-2" style="width:14px;height:14px;border-radius:50%;background:#d9534f;display:inline-block;border:2px solid #fff;"></span> You</div>
                    <hr>
                    <h6 class="fw-bold small mb-2">Quick counts</h6>
                    <div class="small">In your area: <strong><?php echo count($inArea); ?></strong></div>
                    <div class="small">Nearby: <strong><?php echo count($nearby); ?></strong></div>
                    <div class="small">Other: <strong><?php echo count($others); ?></strong></div>
                    <?php if ($myLoc): ?>
                    <hr>
                    <p class="small text-muted mb-1"><i class="fas fa-info-circle me-1"></i>Distances come from our Uganda location lookup (Kampala divisions + major towns).</p>
                    <?php endif; ?>
                    <hr>
                    <h6 class="fw-bold small mb-2"><i class="fas fa-compress-arrows-alt me-1"></i>Closest to you <span class="text-muted" id="gpsNearestCount"></span></h6>
                    <div id="gpsNearestList" class="small text-muted mb-0">Activate <strong>Locate Me</strong> to see the nearest stations sorted by real GPS distance.</div>
                    <hr>
                    <p class="small text-muted mb-0"><i class="fas fa-satellite me-1"></i>Providers pin their station with live GPS from their <strong>Business Settings</strong> — pins tagged with our satellite mark are exact station positions.</p>
                </div>
            </div>
        </div>

        <?php if ($inArea): ?>
        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-home me-2" style="color:#0077b6;"></i>In Your Area (<?php echo count($inArea); ?>)</h5>
            <div class="row g-3">
                <?php foreach ($inArea as $pr): ?><?php echo _loc_card($pr, $BASE); ?><?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($nearby): ?>
        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-map-pin me-2" style="color:#28a745;"></i>Nearby Stations (<?php echo count($nearby); ?>)</h5>
            <div class="row g-3">
                <?php foreach ($nearby as $pr): ?><?php echo _loc_card($pr, $BASE); ?><?php endforeach; ?>
            </div>
        </div>

        <?php endif; ?>

        <?php if ($others): ?>
        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-store me-2" style="color:#f5a623;"></i>All Other Stations (<?php echo count($others); ?>)</h5>
            <div class="row g-3">
                <?php foreach ($others as $pr): ?><?php echo _loc_card($pr, $BASE); ?><?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div></div>
<style>
    .station-dot { width: 18px; height: 18px; border-radius: 50%; border: 2px solid #fff; box-shadow: 0 0 4px rgba(0,0,0,.3); background: #f5a623; }
</style>
<script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
<script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
<script>
    const map = L.map('liveMap').setView([<?php echo $mapCenter['lat']; ?>, <?php echo $mapCenter['lng']; ?>], 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map);

    /* You (blue pin) */
    L.marker([<?php echo $mapCenter['lat']; ?>, <?php echo $mapCenter['lng']; ?>], {
        icon: L.divIcon({
            className: 'you-pin',
            html: '<div style="background:#d9534f;border:3px solid #fff;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3);"><i class="fas fa-user" style="color:#fff;font-size:10px;"></i></div>',
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        })
    }).addTo(map).bindPopup('<strong>You</strong><br><?php echo e((string)($user['location'] ?? 'Your saved location')); ?>');
    let stations = <?php echo json_encode($providers); ?>;
    const mine = <?php echo json_encode(array_values($inArea)); ?>;
    const close = <?php echo json_encode(array_values($nearby)); ?>;
    const colorFor = (p) => mine.some(x => x.provider_id === p.provider_id) ? '#0077b6' : (close.some(x => x.provider_id === p.provider_id) ? '#28a745' : '#f5a623');
    const iconFor = (p) => mine.some(x => x.provider_id === p.provider_id) ? 'fa-store' : (close.some(x => x.provider_id === p.provider_id) ? 'fa-soap' : 'fa-tshirt');

    /* All station markers live in this group so live refreshes can redraw them cleanly. */
    const stationLayer = L.layerGroup().addTo(map);

    /* ---- Registered providers only — pin exactly where they saved their GPS position ---- */
    const searchTerm = <?php echo json_encode(mb_strtolower($search, 'UTF-8')); ?>;
    const providerMapStatus = document.getElementById('providerMapStatus');
    function renderStationMarkers(list) {
        stationLayer.clearLayers();
        const term = (searchTerm || '').trim();
        const visible = list.filter(p => {
            if (!p.lat || !p.lng) return false;
            if (!term) return true;
            return String(p.business_name || '').toLowerCase().includes(term)
                || String(p.business_location || '').toLowerCase().includes(term);
        });
        visible.forEach(p => {
            const live = p.live === true || p.live === 1 || p.live === '1';
            const color = live ? '#7b2cbf' : colorFor(p);
            const iconClass = live ? 'fa-truck-fast' : iconFor(p);
            const icon = L.divIcon({
                className: 'station-pin',
                html: '<div style="background:' + color + ';border:3px solid #fff;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3);"><i class="fas ' + iconClass + '" style="color:#fff;font-size:13px;"></i></div>',
                iconSize: [32, 32],
                iconAnchor: [16, 16]
            });
            const gpsTag = live
                ? ' <span style="color:#7b2cbf;font-weight:700">● LIVE GPS</span>'
                : (p.gps_set ? ' <i class="fas fa-satellite small" style="color:#0077b6;" title="Saved GPS station position"></i>' : ' <small class="text-muted">(approximate area)</small>');
            const pop = '<strong>' + p.business_name + '</strong>' + gpsTag
                + '<br><i class="fas fa-location-dot me-1"></i>' + (p.business_location || 'Address not set')
                + '<br><small class="text-muted">' + Number(p.lat).toFixed(5) + ', ' + Number(p.lng).toFixed(5) + '</small>'
                + (p.km ? '<br><i class="fas fa-map-pin me-1"></i>~' + Math.round(p.km) + ' km away' : '')
                + (live && p.live_updated_at ? '<br><small>GPS updated: ' + new Date(p.live_updated_at.replace(' ', 'T')).toLocaleTimeString() + '</small>' : '')
                + '<br>' + (p.avg_rating > 0 ? '&#11088; ' + Number(p.avg_rating).toFixed(1) + ' (' + p.completed + ' orders)' : 'New station')
                + '<br><a href="<?php echo $BASE; ?>php/customer/new_order/services.php?provider_id=' + p.provider_id + '" class="btn btn-sm btn-primary mt-1">Order Here</a>';
            L.marker([Number(p.lat), Number(p.lng)], { icon: icon }).addTo(stationLayer).bindPopup(pop);
        });
        if (providerMapStatus) {
            if (visible.length) {
                const liveCount = visible.filter(p => p.live === true || p.live === 1 || p.live === '1').length;
                providerMapStatus.textContent = visible.length + ' provider station(s) shown' + (liveCount ? ' · ' + liveCount + ' sharing live GPS' : ' · live GPS is not currently being shared by any provider') + (term ? ' · filtered by search' : '');
                providerMapStatus.className = 'small px-3 py-2 bg-light border-top text-success';
            } else {
                providerMapStatus.textContent = term
                    ? 'No approved, active provider matches “' + term + '”. Try a different station name or area.'
                    : 'No approved, active providers were returned. Check provider approval/status and the database connection.';
                providerMapStatus.className = 'small px-3 py-2 bg-light border-top text-danger';
            }
        }
    }
    renderStationMarkers(stations);

    /* Fit map to show all markers if there are stations */
    try {
        const valid = stations.filter(p => p.lat && p.lng);
        if (valid.length > 0) {
            const group = L.featureGroup(valid.map(p => L.marker([p.lat, p.lng])));
            map.fitBounds(group.getBounds().pad(0.1));
        }
    } catch (err) { /* keep the current centered view */ }

    /* ---- Live refresh: pull fresh station coordinates every 45 seconds ---- */
    const liveStampEl = document.getElementById('liveStationsStamp');
    function refreshStations() {
        fetch('<?php echo $BASE; ?>php/api/stations.php', { credentials: 'same-origin', cache: 'no-store' })
            .then(r => r.json())
            .then(data => {
                if (!data || !data.ok || !Array.isArray(data.stations)) { if (providerMapStatus) { providerMapStatus.textContent = (data && data.message) ? data.message : 'Could not refresh providers. Check the browser Console and PHP error log.'; providerMapStatus.className = 'small px-3 py-2 bg-light border-top text-danger'; } return; }
                stations = data.stations;
                renderStationMarkers(stations);
                if (liveStampEl) {
                    liveStampEl.innerHTML = '<i class="fas fa-circle text-success me-1" style="font-size:.55rem;vertical-align:middle;"></i>Live — updated ' +
                        new Date().toLocaleTimeString();
                }
            })
            .catch(() => { /* transient network error — keep current markers */ });
    }
    refreshStations();
    setInterval(refreshStations, 10000);

    /* ================= Live GPS — "Locate Me" ================= */
    let gpsPos = null;
    const gpsStatusEl = document.getElementById('gpsStatus');
    const gpsListEl = document.getElementById('gpsNearestList');
    const gpsCountEl = document.getElementById('gpsNearestCount');

    function haversineKm(aLat, aLng, bLat, bLng) {
        const R = 6371.0, rad = Math.PI / 180;
        const dLat = (bLat - aLat) * rad, dLng = (bLng - aLng) * rad;
        const h = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * rad) * Math.cos(bLat * rad) * Math.sin(dLng / 2) ** 2;
        return 2 * R * Math.asin(Math.sqrt(h));
    }

    function rangeRing(lat, lng, radiusKm, steps = 48) {
        const pts = [], rad = Math.PI / 180;
        const dLat = radiusKm / 111.0;
        const dLng = radiusKm / (111.0 * Math.cos(lat * rad));
        for (let i = 0; i < steps; i++) {
            const t = (i / steps) * 2 * Math.PI;
            pts.push([lat + dLat * Math.sin(t), lng + dLng * Math.cos(t)]);
        }
        return pts;
    }

    function setGpsStatus(html) {
        if (gpsStatusEl) gpsStatusEl.innerHTML = html;
    }

    function useGps() {
        if (!navigator.geolocation || typeof navigator.geolocation.getCurrentPosition !== 'function') {
            setGpsStatus('<i class="fas fa-exclamation-triangle text-danger me-1"></i>GPS not supported in this browser — try the latest Chrome or Firefox.');
            return;
        }
        setGpsStatus('<i class="fas fa-spinner fa-spin me-1"></i>Locating you…');
        navigator.geolocation.getCurrentPosition(
            (pos) => renderGps(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy || null),
            (err) => {
                const msgs = { 1: 'Location permission denied — please allow access and retry.', 2: 'Position unavailable. Check GPS and network.', 3: 'Location request timed out. Try again.' };
                setGpsStatus('<i class="fas fa-exclamation-triangle text-warning me-1"></i>' + (msgs[err.code] || 'Could not get your location.'));
            },
            { timeout: 12000 }
        );
    }
    window.useGps = useGps;

    function renderGps(lat, lng, acc) {
        gpsPos = [lat, lng];

        map.setView([lat, lng], 13); /* recentre + zoom for a live feel */

        /* live "you" pin (blue, pulsing ring) */
        L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'gps-you',
                html: '<div style="background:#0d6efd;border:3px solid #fff;border-radius:50%;width:26px;height:26px;box-shadow:0 0 0 6px rgba(13,110,253,.25);display:flex;align-items:center;justify-content:center;"><i class="fas fa-crosshairs" style="color:#fff;font-size:11px;"></i></div>',
                iconSize: [26, 26],
                iconAnchor: [13, 13]
            })
        }).addTo(map).bindPopup('<strong>You (live GPS)</strong><br>' + lat.toFixed(5) + ', ' + lng.toFixed(5) + (acc ? '<br>Accuracy ±' + Math.round(acc) + ' m' : ''));

        /* range rings: 15 km service area + 5 km near-you */
        L.polygon(rangeRing(lat, lng, 15), { color: '#0077b6', weight: 2, dashArray: '6 6', fillColor: '#0077b6', fillOpacity: 0.04 }).addTo(map);
        L.polygon(rangeRing(lat, lng, 5),  { color: '#28a745', weight: 2, dashArray: '4 4', fillColor: '#28a745', fillOpacity: 0.06 }).addTo(map);

        /* real distances straight from the GPS fix — registered stations only */
        const withDist = stations
            .filter(p => p.lat && p.lng)
            .map(p => Object.assign({}, p, { dist: haversineKm(lat, lng, p.lat, p.lng) }))
            .sort((a, b) => a.dist - b.dist);

        if (gpsCountEl) gpsCountEl.textContent = '(' + withDist.length + ')';
        if (gpsListEl) {
            gpsListEl.innerHTML = withDist.length === 0
                ? '<span class="text-muted">No registered stations within range yet.</span>'
                : withDist.slice(0, 6).map(p =>
                    '<div class="d-flex align-items-center mb-1">' +
                        '<span class="me-1" style="width:10px;height:10px;border-radius:50%;background:' + (p.dist <= 5 ? '#28a745' : (p.dist <= 15 ? '#0077b6' : '#f5a623')) + ';display:inline-block;"></span>' +
                        '<a class="text-truncate" style="max-width:150px;" href="<?php echo $BASE; ?>php/customer/new_order/services.php?provider_id=' + p.provider_id + '">' + p.business_name + '</a>' +
                        '<span class="ms-auto small text-muted">' + (p.dist < 1 ? Math.round(p.dist * 1000) + ' m' : p.dist.toFixed(1) + ' km') + '</span>' +
                    '</div>'
                ).join('');
        }

        setGpsStatus('<i class="fas fa-map-pin text-primary me-1"></i>GPS locked: ' + lat.toFixed(4) + ', ' + lng.toFixed(4) + (acc ? ' (±' + Math.round(acc) + ' m)' : '') + ' — ' + withDist.length + ' stations found');
    }
</script>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
        