<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$user = current_user();
$pdo = $GLOBALS['pdo'];
$uid = (int)$user['user_id'];

/* Live stat counters */
$stats = [
    'total'     => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE customer_id = $uid")->fetchColumn(),
    'pending'   => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE customer_id = $uid AND status = 'pending'")->fetchColumn(),
    'active'    => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE customer_id = $uid AND status IN ('active','in_progress','out_for_delivery')")->fetchColumn(),
    'completed' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE customer_id = $uid AND status IN ('delivered','completed')")->fetchColumn(),
];

/* Recent 5 orders */
$stmt = $pdo->prepare(
    'SELECT o.*, p.business_name FROM orders o
     JOIN providers p ON p.provider_id = o.provider_id
     WHERE o.customer_id = ? ORDER BY o.created_at DESC LIMIT 5'
);
$stmt->execute([$uid]);
$recent = $stmt->fetchAll();

/* Wallet / loyalty / streak / referral widgets */
$walletBal = feature_enabled('wallet') ? wallet_balance($uid) : 0;
$loyaltyPts = (int)$user['loyalty_points'];
$streak = (int)min(30, $pdo->query("SELECT COUNT(*) FROM orders WHERE customer_id = $uid AND status IN ('delivered','completed') AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn());
$refCode = feature_enabled('referrals') ? lex_referral_code($uid) : null;

$active = 'dashboard';
$page_title = 'Customer Dashboard';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h2 class="fw-bold mb-0"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h2>
            <a href="<?php echo $BASE; ?>php/customer/new_order/select_provider.php" class="btn btn-primary"><i class="fas fa-plus-circle me-2"></i>Quick New Order</a>
        </div>

        <!-- Stat Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-6">
                <a href="orders.php?status=all" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['total']; ?></h3><small class="text-white-50">Total Orders</small></div>
                            <i class="fas fa-shopping-bag fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="orders.php?status=active" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['active']; ?></h3><small class="text-white-50">Active Orders</small></div>
                            <i class="fas fa-spinner fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="orders.php?status=completed" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #43e97b, #38f9d7);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['completed']; ?></h3><small class="text-white-50">Completed</small></div>
                            <i class="fas fa-check-circle fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="orders.php?status=pending" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #fad0c4, #fbc2a4);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-dark fw-bold mb-0"><?php echo $stats['pending']; ?></h3><small class="text-muted">Pending</small></div>
                            <i class="fas fa-clock fa-3x text-muted"></i>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Loyalty + Welcome widgets -->
        <div class="row g-4 mb-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-fire me-2" style="color:#f5576c;"></i>Welcome back, <?php echo e($user['full_name']); ?>!</h5>
                        <p class="text-muted mb-1">Your laundry journey at a glance. Place a new order and we will connect you with the best providers in <strong><?php echo e($user['location'] ?: 'your area'); ?></strong>.</p>
                        <div class="row g-3 mt-2">
                            <div class="col-4"><div class="quick-stat"><div class="number"><?php echo $stats['completed']; ?></div><div class="label">Orders Done</div></div></div>
                            <div class="col-4"><div class="quick-stat"><div class="number"><?php echo $loyaltyPts; ?></div><div class="label">Loyalty Points</div></div></div>
                            <div class="col-4"><div class="quick-stat"><div class="number"><?php echo $stats['active']; ?></div><div class="label">In Progress</div></div></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 p-4 text-white d-flex" style="background: linear-gradient(135deg, #0077b6, #00b4d8);">
                    <h5 class="fw-bold"><i class="fas fa-gift me-2"></i>Rewards &amp; Perks</h5>
                    <div class="row g-2 my-2">
                        <?php if (feature_enabled('wallet')): ?>
                        <div class="col-6"><div class="rounded-3 p-2" style="background: rgba(255,255,255,.15);">
                            <small>Wallet Balance</small>
                            <div class="fw-bold fs-6"><?php echo format_ugx($walletBal); ?></div>
                        </div></div>
                        <?php endif; ?>
                        <?php if (feature_enabled('streaks')): ?>
                        <div class="col-6"><div class="rounded-3 p-2" style="background: rgba(255,255,255,.15);">
                            <small>Laundry Streak</small>
                            <div class="fw-bold fs-6"><?php echo $streak; ?> / 30 days</div>
                        </div></div>
                        <?php endif; ?>
                        <div class="col-6"><div class="rounded-3 p-2" style="background: rgba(255,255,255,.15);">
                            <small>Loyalty Points</small>
                            <div class="fw-bold fs-6"><?php echo $loyaltyPts; ?></div>
                        </div></div>
                        <?php if ($refCode): ?>
                        <div class="col-6"><div class="rounded-3 p-2" style="background: rgba(255,255,255,.15);">
                            <small>Referral Code</small>
                            <div class="fw-bold fs-6"><?php echo e($refCode); ?></div>
                        </div></div>
                        <?php endif; ?>
                    </div>
                    <p class="mb-3 small">Earn <?php echo defined('POINTS_PER_ORDER') ? POINTS_PER_ORDER : 10; ?> loyalty points per completed order. Share your referral code to earn UGX 500 wallet credit when a friend joins!</p>
                    <div class="d-grid gap-2 mt-auto">
                        <?php if (feature_enabled('wallet')): ?><a href="wallet.php" class="btn btn-light btn-sm"><i class="fas fa-wallet me-1"></i>My Wallet</a><?php endif; ?>
                        <a href="<?php echo $BASE; ?>php/customer/new_order/select_provider.php" class="btn btn-outline-light btn-sm"><i class="fas fa-rocket me-1"></i>Start an Order</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-transparent border-bottom-0 pt-4 px-4">
                <h5 class="fw-bold mb-0"><i class="fas fa-history me-2"></i>Recent Orders</h5>
            </div>
            <div class="card-body p-4">
                <?php if (!$recent): ?>
                    <p class="text-muted text-center py-4">No orders yet. <a href="<?php echo $BASE; ?>php/customer/new_order/select_provider.php">Place your first order</a>!</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr><th>Order ID</th><th>Provider</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent as $o): ?>
                            <tr>
                                <td><span class="fw-bold"><?php echo order_code($o['order_id']); ?></span></td>
                                <td><?php echo e($o['business_name']); ?></td>
                                <td><?php echo format_ugx($o['total_price']); ?></td>
                                <td><?php echo status_badge($o['status']); ?></td>
                                <td><?php echo format_date($o['created_at']); ?></td>
                                <td><a href="order_details.php?id=<?php echo (int)$o['order_id']; ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <a href="orders.php" class="btn btn-link">View All Orders <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
        </div>

    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
