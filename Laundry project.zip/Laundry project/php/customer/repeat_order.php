<?php
/**
 * Repeat My Last Order — rebuilds a previous order as a fresh draft so the
 * customer only has to confirm dates, address and payment.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

if (!feature_enabled('repeat')) {
    flash('info', 'This feature is currently disabled.');
    redirect('orders.php');
}

$pdo = $GLOBALS['pdo'];
$user = current_user();
$orderId = (int)($_GET['order_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM orders WHERE order_id = ? AND customer_id = ? LIMIT 1');
$stmt->execute([$orderId, (int)$user['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    flash('danger', 'Order not found.');
    redirect('orders.php');
}

/* Re-price the previous items against the provider's CURRENT menu */
$stmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY item_id ASC');
$stmt->execute([$orderId]);
$previous = $stmt->fetchAll();

$items = [];
$total = 0;
$missing = [];
foreach ($previous as $row) {
    $stmt = $pdo->prepare(
        'SELECT * FROM provider_pricing WHERE provider_id = ? AND service_name = ? AND clothing_type = ? LIMIT 1'
    );
    $stmt->execute([(int)$order['provider_id'], $row['service_name'], $row['clothing_type']]);
    $price = $stmt->fetch();
    if (!$price) {
        $missing[] = $row['clothing_type'] . ' (' . $row['service_name'] . ')';
        continue;
    }
    $q = max(1, (int)$row['quantity']);
    $subtotal = $q * (float)$price['price'];
    $items[] = [
        'pricing_id'    => (int)$price['pricing_id'],
        'service_name'  => $row['service_name'],
        'clothing_type' => $row['clothing_type'],
        'quantity'      => $q,
        'price'         => (float)$price['price'],
        'subtotal'      => $subtotal,
    ];
    $total += $subtotal;
}

if (!$items) {
    flash('warning', 'The provider no longer offers those items. Please build a new order.');
    redirect('new_order/services.php?provider_id=' . (int)$order['provider_id']);
}

$token = bin2hex(random_bytes(8));
$_SESSION['order_drafts'][$token] = [
    'customer_id' => (int)$user['user_id'],
    'provider_id' => (int)$order['provider_id'],
    'items'       => $items,
    'total'       => $total,
];

if ($missing) {
    flash('warning', 'Some items from the old order are no longer offered and were skipped: ' . e(implode(', ', $missing)) . '.');
} else {
    flash('success', 'Your previous order was loaded. Confirm the dates and payment to place it again.');
}
redirect($BASE . 'php/customer/new_order/schedule.php?order_token=' . $token);