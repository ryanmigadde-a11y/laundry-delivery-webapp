<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$user = current_user();
$pdo = $GLOBALS['pdo'];
$uid = $user['user_id'];

/* Status filter tabs */
$filter = $_GET['status'] ?? 'all';
$where = "o.customer_id = $uid";
switch ($filter) {
    case 'pending':    $where .= " AND o.status = 'pending'"; break;
    case 'active':     $where .= " AND o.status IN ('active','in_progress','out_for_delivery')"; break;
    case 'completed':  $where .= " AND o.status IN ('delivered','completed')"; break;
    case 'cancelled':  $where .= " AND o.status = 'cancelled'"; break;
}

$stmt = $pdo->prepare(
    "SELECT o.*, p.business_name,
        (SELECT COUNT(*) FROM reviews r WHERE r.order_id = o.order_id) AS has_review
     FROM orders o JOIN providers p ON p.provider_id = o.provider_id
     WHERE $where ORDER BY o.created_at DESC"
);
$stmt->execute();
$orders = $stmt->fetchAll();

$tabs = [
    'all'       => 'All',
    'pending'   => 'Pending',
    'active'    => 'Active',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
];

$active = 'orders';
$page_title = 'My Orders';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-shopping-bag me-2"></i>My Orders</h2>
        <ul class="nav nav-tabs mb-4">
            <?php foreach ($tabs as $key => $label): ?>
            <li class="nav-item"><a class="nav-link <?php echo $filter === $key ? 'active' : ''; ?>" href="?status=<?php echo $key; ?>"><?php echo $label; ?></a></li>
            <?php endforeach; ?>
        </ul>

        <?php if (!$orders): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <p class="text-muted mb-3">No orders in this category yet.</p>
                <a href="<?php echo $BASE; ?>php/customer/new_order/select_provider.php" class="btn btn-primary mx-auto"><i class="fas fa-plus-circle me-2"></i>Place a New Order</a>
            </div>
        <?php endif; ?>

        <div class="row g-3">
            <?php foreach ($orders as $o): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 order-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="fw-bold"><?php echo order_code($o['order_id']); ?></span>
                            <?php echo status_badge($o['status']); ?>
                        </div>
                        <p class="mb-1"><i class="fas fa-store me-1 text-muted"></i><?php echo e($o['business_name']); ?></p>
                        <p class="mb-1"><i class="fas fa-calendar me-1 text-muted"></i><?php echo format_date($o['created_at']); ?></p>
                        <p class="mb-1"><i class="fas fa-credit-card me-1 text-muted"></i>Payment: <?php echo status_badge($o['payment_status']); ?></p>
                        <h5 class="fw-bold mt-2"><?php echo format_ugx($o['total_price']); ?></h5>
                        <div class="d-flex gap-2 mt-2 flex-wrap">
                            <a href="order_details.php?id=<?php echo (int)$o['order_id']; ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                            <?php if (in_array($o['status'], ['delivered', 'completed']) && feature_enabled('repeat')): ?>
                                <a href="repeat_order.php?order_id=<?php echo (int)$o['order_id']; ?>" class="btn btn-sm btn-outline-success"><i class="fas fa-repeat me-1"></i>Repeat</a>
                            <?php endif; ?>
                            <?php if (in_array($o['status'], ['delivered', 'completed']) && $o['payment_status'] === 'confirmed' && !$o['has_review']): ?>
                                <a href="order_details.php?id=<?php echo (int)$o['order_id']; ?>#review" class="btn btn-sm btn-outline-warning"><i class="fas fa-star me-1"></i>Review</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
