<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();

/* ---- Update profile ---- */
if (isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $location = trim($_POST['location'] ?? '');

    if ($full_name === '' || $email === '') {
        flash('danger', 'Name and email are required.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('danger', 'Please enter a valid email address.');
    } else {
        $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ? AND user_id != ?');
        $stmt->execute([$email, $user['user_id']]);
        if ($stmt->fetch()) {
            flash('danger', 'That email is already used by another account.');
        } else {
            $pic = handle_upload($_FILES['profile_pic'] ?? null, 'profile');
            if ($pic) {
                $pdo->prepare('UPDATE users SET profile_pic = ? WHERE user_id = ?')->execute([$pic, $user['user_id']]);
            } elseif (!empty($_FILES['profile_pic']['name']) && !empty($GLOBALS['upload_error'])) {
                flash('warning', 'Profile picture was not saved: ' . $GLOBALS['upload_error']);
            }
            $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, phone = ?, location = ? WHERE user_id = ?');
            $stmt->execute([$full_name, $email, $phone, $location, $user['user_id']]);
            $_SESSION['full_name'] = $full_name;
            flash('success', 'Profile updated successfully.');
        }
    }
    redirect('settings.php');
}

/* ---- Change password ---- */
if (isset($_POST['change_password'])) {
    $old = $_POST['old_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($old, $user['password_hash'])) {
        flash('danger', 'Your current password is incorrect.');
    } elseif (strlen($new) < 6) {
        flash('danger', 'New password must be at least 6 characters.');
    } elseif ($new !== $confirm) {
        flash('danger', 'New passwords do not match.');
    } else {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE user_id = ?')
            ->execute([password_hash($new, PASSWORD_DEFAULT), $user['user_id']]);
        flash('success', 'Password updated successfully.');
    }
    redirect('settings.php');
}

/* Refresh user after updates */
$stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ?');
$stmt->execute([$user['user_id']]);
$user = $stmt->fetch();

$active = 'settings';
$page_title = 'Settings';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-cog me-2"></i>Settings</h2>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-user me-2" style="color: #0077b6;"></i>Profile Information</h5>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="text-center mb-4">
                            <div class="position-relative d-inline-block">
                                <img id="picPreview" src="<?php echo avatar_src($user['profile_pic'], $user['full_name']); ?>"
                                     class="rounded-circle" width="100" height="100" style="object-fit: cover;" alt="avatar">
                                <label class="position-absolute bottom-0 end-0 btn btn-sm btn-primary rounded-circle" style="cursor: pointer;">
                                    <i class="fas fa-camera"></i><input type="file" name="profile_pic" class="d-none" accept="image/*" onchange="document.getElementById('picPreview').src = window.URL.createObjectURL(this.files[0])">
                                </label>
                            </div>
                        </div>
                        <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="full_name" class="form-control" value="<?php echo e($user['full_name']); ?>" required></div>
                        <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo e($user['email']); ?>" required></div>
                        <div class="mb-3"><label class="form-label">Phone</label><input type="tel" name="phone" class="form-control" value="<?php echo e($user['phone']); ?>"></div>
                        <div class="mb-3"><label class="form-label">Location</label><input type="text" name="location" class="form-control" value="<?php echo e($user['location']); ?>" placeholder="Kampala, Uganda"></div>
                        <button type="submit" name="update_profile" value="1" class="btn btn-primary w-100"><i class="fas fa-save me-2"></i>Save Changes</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-lock me-2" style="color: #0077b6;"></i>Change Password</h5>
                    <form method="POST">
                        <div class="mb-3"><label class="form-label">Current Password</label><input type="password" name="old_password" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">New Password</label><input type="password" name="new_password" class="form-control" required minlength="6"></div>
                        <div class="mb-3"><label class="form-label">Confirm New Password</label><input type="password" name="confirm_password" class="form-control" required></div>
                        <button type="submit" name="change_password" value="1" class="btn btn-primary w-100"><i class="fas fa-key me-2"></i>Update Password</button>
                    </form>
                </div>
            </div>

        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
