<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$user = current_user();
$pdo = $GLOBALS['pdo'];
$uid = (int)$user['user_id'];
$orderId = (int)($_GET['id'] ?? $_POST['order_id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT o.*, p.business_name, p.business_phone, p.business_location
     FROM orders o JOIN providers p ON p.provider_id = o.provider_id
     WHERE o.order_id = ? AND o.customer_id = ? LIMIT 1'
);
$stmt->execute([$orderId, $uid]);
$order = $stmt->fetch();

if (!$order) {
    flash('danger', 'Order not found.');
    redirect('orders.php');
}

/* ---- POST actions: cancel / delete / review / upload evidence ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'cancel' && $order['status'] === 'pending') {
        $pdo->prepare("UPDATE orders SET status = 'cancelled' WHERE order_id = ?")->execute([$orderId]);
        record_history($orderId, 'pending', 'cancelled', $uid);
        add_notification($order['provider_id'], 'Order Cancelled', 'A customer cancelled order ' . order_code($orderId) . '.', 'php/provider/orders.php');
        add_notification($uid, 'Order Cancelled', 'Your order ' . order_code($orderId) . ' has been cancelled.', 'php/customer/orders.php');
        flash('success', 'Order cancelled successfully.');
        redirect('orders.php?status=cancelled');
    }

    if ($action === 'delete' && $order['status'] === 'cancelled') {
        $pdo->prepare('DELETE FROM orders WHERE order_id = ? AND customer_id = ?')->execute([$orderId, $uid]);
        flash('success', 'Order deleted permanently.');
        redirect('orders.php');
    }

    if ($action === 'review') {
        $rating = max(1, min(5, (int)($_POST['rating'] ?? 5)));
        $comment = trim($_POST['comment'] ?? '');
        $already = $pdo->prepare('SELECT review_id FROM reviews WHERE order_id = ?');
        $already->execute([$orderId]);
        if (in_array($order['status'], ['delivered', 'completed'], true) && $order['payment_status'] === 'confirmed' && !$already->fetch()) {
            $pdo->prepare('INSERT INTO reviews (order_id, customer_id, provider_id, rating, comment) VALUES (?, ?, ?, ?, ?)')
                ->execute([$orderId, $uid, $order['provider_id'], $rating, $comment]);
            add_notification($order['provider_id'], 'New Review', 'A customer left a ' . $rating . '-star review on order ' . order_code($orderId) . '.', 'php/provider/reviews.php');
            flash('success', 'Thank you! Your review has been submitted.');
        }
        redirect('order_details.php?id=' . $orderId);
    }

    /* Customer uploads their own evidence photos (before pickup / after delivery) */
    if ($action === 'upload_evidence') {
        $stage = in_array($_POST['stage'] ?? '', ['picked_up', 'before_delivery', 'delivered'], true) ? $_POST['stage'] : 'picked_up';
        if (!in_array($order['status'], ['in_progress', 'out_for_delivery', 'delivered', 'completed'], true)) {
            flash('danger', 'Photos can only be attached once the order is in progress or later.');
        } else {
            $note = trim($_POST['evidence_note'] ?? '');
            $pic = handle_upload($_FILES['evidence_img'] ?? null, 'evidence');
            if ($pic) {
                $pdo->prepare('INSERT INTO order_evidence (order_id, stage, image, note) VALUES (?, ?, ?, ?)')
                    ->execute([$orderId, $stage, $pic, $note]);
                add_notification((int)$order['provider_id'], 'Customer Evidence', 'The customer attached photo evidence for order ' . order_code($orderId) . '.', 'php/provider/order_details.php?id=' . $orderId);
                flash('success', 'Evidence photo uploaded.');
            } else {
                flash('warning', 'Evidence not saved: ' . ($GLOBALS['upload_error'] ?? 'Select an image.'));
            }
        }
        redirect('order_details.php?id=' . $orderId);
    }
    redirect('order_details.php?id=' . $orderId);
}

/* Order items */
$stmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY item_id ASC');
$stmt->execute([$orderId]);
$items = $stmt->fetchAll();

/* Status history (activity feed) */
$stmt = $pdo->prepare(
    'SELECT h.*, u.full_name FROM order_status_history h
     LEFT JOIN users u ON u.user_id = h.changed_by
     WHERE h.order_id = ? ORDER BY h.changed_at ASC'
);
$stmt->execute([$orderId]);
$history = $stmt->fetchAll();

/* Existing review */
$stmt = $pdo->prepare('SELECT * FROM reviews WHERE order_id = ? LIMIT 1');
$stmt->execute([$orderId]);
$review = $stmt->fetch();

/* Evidence photos (provider + customer) */
ensure_demo_upgrade_tables();
$stmt = $pdo->prepare('SELECT * FROM order_evidence WHERE order_id = ? ORDER BY evidence_id DESC');
$stmt->execute([$orderId]);
$evidenceRows = $stmt->fetchAll();

/* Payment receipt (auto-generated once the payment is paid/confirmed) */
$receipt = null;
if (in_array($order['payment_status'], ['paid', 'confirmed'], true)) {
    $receipt = ensure_order_receipt($orderId);
}

/* Absolute URL for QR code / tracking link (works when scanned on a phone). */
$trackUrl = absolute_url('php/customer/track.php?token=' . rawurlencode((string)$order['unique_order_token']));

$steps = ['Order Placed', 'Accepted', 'In Progress', 'Out for Delivery', 'Delivered'];
$currentStep = status_step_index($order['status']);
$active = 'orders';
$page_title = 'Order Details';
$extra_css = ['assets/vendor/leaflet/leaflet.css'];
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1" id="review"><?php echo order_code($order['order_id']); ?> <?php echo status_badge($order['status']); ?></h2>
                <p class="text-muted mb-0">Provider: <strong><?php echo e($order['business_name']); ?></strong> | Placed <?php echo format_date($order['created_at']); ?></p>
            </div>
            <a href="orders.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-2"></i>Back to Orders</a>
        </div>

        <!-- Tracking Progress -->
        <?php if ($order['status'] !== 'cancelled'): ?>
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4"><i class="fas fa-route me-2"></i>Order Tracking</h5>
                <div class="tracking-progress">
                    <div class="d-flex align-items-center">
                        <?php foreach ($steps as $i => $step): ?>
                            <?php if ($i > 0): ?>
                                <div class="step-line <?php echo $i <= $currentStep ? 'completed' : ''; ?>"></div>
                            <?php endif; ?>
                            <div class="step-item text-center">
                                <span class="step-circle <?php echo $i <= $currentStep ? 'completed' : ''; ?>">
                                    <?php if ($i < $currentStep): ?><i class="fas fa-check"></i><?php else: echo $i + 1; endif; ?>
                                </span>
                                <small class="d-block mt-2 <?php echo $i <= $currentStep ? 'fw-bold' : 'text-muted'; ?>"><?php echo $step; ?></small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Live courier map -->
                <?php if ($order['status'] !== 'cancelled'): ?>
                <div class="mt-4">
                    <h6 class="fw-bold mb-2"><i class="fas fa-satellite-dish me-2" style="color:#dc3545;"></i>Live Tracking Map</h6>
                    <div id="trackingMap" class="border" style="height: 340px; width: 100%; border-radius: 12px;"></div>
                    <div id="trackStatus" class="small text-muted mt-2"><i class="fas fa-spinner fa-spin me-1"></i>Loading live tracking&hellip;</div>
                </div>
                <?php endif; ?>

                <?php if ($order['status'] === 'in_progress'): ?>
                <div class="alert alert-info mb-0 small"><i class="fas fa-spinner fa-spin me-1"></i><strong>Cleaning in progress!</strong> Your clothes were picked up and the provider is working on your order right now.</div>
                <?php elseif ($order['status'] === 'active'): ?>
                <div class="alert alert-primary mb-0 small"><i class="fas fa-check-circle me-1"></i>The provider has accepted your order and is preparing to pick up your clothes.</div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-danger rounded-4"><i class="fas fa-ban me-2"></i>This order was cancelled.</div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-md-8">
                <!-- Order Items -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-list me-2"></i>Order Items</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead><tr><th>Service</th><th>Item</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td><?php echo e($item['service_name']); ?></td>
                                        <td><?php echo e($item['clothing_type']); ?></td>
                                        <td><?php echo (int)$item['quantity']; ?></td>
                                        <td><?php echo format_ugx($item['price_per_item']); ?></td>
                                        <td class="fw-bold"><?php echo format_ugx($item['subtotal']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr><td colspan="4" class="text-end fw-bold">Total:</td><td class="fw-bold fs-5" style="color: #0077b6;"><?php echo format_ugx($order['total_price']); ?></td></tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Activity / Status Timeline -->
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-stream me-2"></i>Activity</h5>
                        <div class="timeline">
                            <?php foreach ($history as $h): ?>
                            <div class="timeline-item completed">
                                <h6 class="mb-1">Status changed to <strong><?php echo e(ucfirst(str_replace('_', ' ', $h['status_to']))); ?></strong></h6>
                                <small class="text-muted"><?php echo e($h['full_name'] ?: 'System'); ?> &bull; <?php echo date('d M Y, h:i A', strtotime($h['changed_at'])); ?></small>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <!-- Order Info -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-info-circle me-2"></i>Order Info</h5>
                        <p class="mb-2"><strong>Payment Method:</strong><br><?php echo e(ucfirst(str_replace('_', ' ', $order['payment_method']))); ?><?php if ($order['payment_method'] === 'mobile_money'): ?> (<?php echo e(strtoupper($order['mobile_network'] ?? '')); ?> - <?php echo e($order['mobile_number']); ?>)<?php endif; ?></p>
                        <p class="mb-2"><strong>Payment Status:</strong><br><?php echo status_badge($order['payment_status']); ?>
                            <?php if ($order['payment_status'] === 'confirmed'): ?><span class="badge bg-success ms-1"><i class="fas fa-check-circle me-1"></i>Confirmed by provider</span><?php endif; ?></p>
                        <?php if ($receipt): ?>
                        <a href="receipt.php?order_id=<?php echo $orderId; ?>" class="btn btn-sm btn-success w-100 mt-2"><i class="fas fa-receipt me-2"></i>View / Download Payment Receipt</a>
                        <?php endif; ?>
                        <p class="mb-2"><strong>Pickup:</strong><br><?php echo format_date($order['pickup_date']); ?> <?php echo e($order['pickup_time'] ?? ''); ?></p>
                        <p class="mb-2"><strong>Delivery:</strong><br><?php echo format_date($order['delivery_date']); ?> <?php echo e($order['delivery_time'] ?? ''); ?></p>
                        <p class="mb-2"><strong>Pickup Address:</strong><br><?php echo e($order['pickup_address']); ?></p>
                        <?php if ($order['special_instructions']): ?>
                        <p class="mb-0"><strong>Special Instructions:</strong><br><?php echo e($order['special_instructions']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Actions -->
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-bolt me-2"></i>Actions</h5>
                        <div class="d-grid gap-2">
                            <a href="chat.php?order_id=<?php echo $orderId; ?>" class="btn btn-outline-primary"><i class="fas fa-comment me-2"></i>Chat with Provider</a>
                            <?php if (in_array($order['status'], ['delivered', 'completed']) && !$review): ?>
                                <button class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#reviewModal" <?php echo $order['payment_status'] !== 'confirmed' ? 'disabled' : ''; ?>><i class="fas fa-star me-2"></i>Leave a Review<?php if ($order['status'] === 'delivered' && $order['payment_status'] !== 'confirmed'): ?> <small class="d-block fw-normal">(wait for provider payment confirmation)</small><?php endif; ?></button>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'pending'): ?>
                            <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this order?');">
                                <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                                <button name="action" value="cancel" class="btn btn-outline-danger w-100"><i class="fas fa-ban me-2"></i>Cancel Order</button>
                            </form>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'cancelled'): ?>
                            <form method="POST" onsubmit="return confirm('Permanently delete this order? This cannot be undone.');">
                                <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                                <button name="action" value="delete" class="btn btn-danger w-100"><i class="fas fa-trash me-2"></i>Delete Order</button>
                            </form>
                             <?php endif; ?>
                             <!-- QR Code for Tracking -->
                             <div class="border rounded-3 p-3 text-center bg-white">
                                 <h6 class="fw-bold mb-2"><i class="fas fa-qrcode me-1" style="color:#0077b6;"></i>Track This Order</h6>
                                 <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo urlencode($trackUrl); ?>" alt="QR code" class="img-fluid rounded-3 border" style="max-width:150px;">
                                 <small class="text-muted d-block mt-2">Scan on any device to track live.</small>
                                 <a href="<?php echo e($trackUrl); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2"><i class="fas fa-external-link-alt me-1"></i>Open Tracking</a>

                             </div>
                            <?php if ($review): ?>
                            <div class="border rounded-3 p-3 bg-light">
                                <small class="fw-bold">Your Review</small>
                                <div class="mb-1"><?php echo star_icons($review['rating']); ?></div>
                                <p class="mb-0 small"><?php echo e($review['comment']); ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if (feature_enabled('disputes') && in_array($order['status'], ['delivered', 'completed'], true)): ?>
                            <a href="disputes.php" class="btn btn-sm btn-outline-danger w-100 mt-2"><i class="fas fa-shield-halved me-1"></i>Report an Issue / Open Dispute</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>


    <!-- Photo Evidence (provider + customer) -->
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3"><i class="fas fa-camera me-2"></i>Photo Evidence — Before &amp; After</h5>
                <p class="small text-muted mb-2">Upload your own photos (e.g. before pickup or after delivery) to back your record. The provider can also attach "at pickup / before delivery / at delivery" photos here.</p>
                <?php if (in_array($order['status'], ['in_progress', 'out_for_delivery', 'delivered', 'completed'], true)): ?>
                <form method="POST" enctype="multipart/form-data" class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <select name="stage" class="form-select">
                            <option value="picked_up">Before pickup</option>
                            <option value="delivered">After delivery</option>
                        </select>
                    </div>
                    <div class="col-md-4"><input type="file" name="evidence_img" class="form-control" accept="image/*" required></div>
                    <div class="col-md-3"><input type="text" name="evidence_note" class="form-control" placeholder="Note (optional)"></div>
                    <div class="col-md-2"><button type="submit" name="action" value="upload_evidence" class="btn btn-outline-success w-100"><i class="fas fa-cloud-arrow-up me-1"></i>Upload</button></div>
                </form>
                <?php endif; ?>
                <?php if ($evidenceRows): ?>
                <hr>
                <div class="row g-2">
                    <?php foreach ($evidenceRows as $ev): ?>
                    <div class="col-6 col-md-4">
                        <img src="<?php echo $BASE . 'assets/images/uploads/' . rawurlencode((string)$ev['image']); ?>" class="img-fluid rounded-3 border" alt="Evidence">
                        <small class="text-muted d-block"><?php echo e(ucwords(str_replace('_', ' ', $ev['stage']))); ?> &middot; <?php echo format_date($ev['created_at']); ?><?php if ($ev['note']): ?> &middot; <?php echo e($ev['note']); ?><?php endif; ?></small>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <p class="text-muted small mb-0">No photos yet. Once your order is in progress, you can attach before-pickup and after-delivery photos here.</p>
                <?php endif; ?>
            </div>
        </div>

    </main>
</div></div>
<?php if (in_array($order['status'], ['delivered', 'completed']) && $order['payment_status'] === 'confirmed' && !$review): ?>
<div class="modal fade" id="reviewModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Leave a Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                <div class="modal-body">
                    <div class="mb-3 text-center">
                        <label class="form-label fw-bold">Rating</label>
                        <div class="star-rating">
                            <input type="radio" name="rating" value="5" id="star5" checked><label for="star5"><i class="fas fa-star"></i></label>
                            <input type="radio" name="rating" value="4" id="star4"><label for="star4"><i class="fas fa-star"></i></label>
                            <input type="radio" name="rating" value="3" id="star3"><label for="star3"><i class="fas fa-star"></i></label>
                            <input type="radio" name="rating" value="2" id="star2"><label for="star2"><i class="fas fa-star"></i></label>
                            <input type="radio" name="rating" value="1" id="star1"><label for="star1"><i class="fas fa-star"></i></label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Comment</label>
                        <textarea name="comment" class="form-control" rows="3" placeholder="Share your experience..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="action" value="review" class="btn btn-primary"><i class="fas fa-paper-plane me-2"></i>Submit Review</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($order['status'] !== 'cancelled'): ?>
<script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
<script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
<script>
    window.TRACK_CONFIG = {
        apiUrl:  '<?php echo $BASE; ?>php/api/tracking.php',
        orderId: <?php echo (int)$order['order_id']; ?>,
        pollMs:  5000,
        statusEl: 'trackStatus'
    };
</script>
<script src="<?php echo $BASE; ?>assets/js/order_tracking.js"></script>
<?php endif; ?>

<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
