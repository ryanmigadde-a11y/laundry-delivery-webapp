<?php
/**
 * My Receipts — archive of every payment receipt for the signed-in customer.
 * Each receipt shows order details, provider information, amount paid and the
 * date/time, and can be downloaded as PDF from its page.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$uid = (int)$user['user_id'];

ensure_demo_upgrade_tables();

/* Make sure every paid/confirmed order already has a receipt row. */
$uncovered = $pdo->query(
    "SELECT order_id FROM orders WHERE customer_id = $uid AND payment_status IN ('paid','confirmed')"
)->fetchAll();
foreach ($uncovered as $u) ensure_order_receipt((int)$u['order_id']);

$stmt = $pdo->prepare(
    "SELECT r.*, o.total_price AS order_total, p.business_name, o.pickup_date, o.delivery_date
     FROM receipts r
     JOIN orders o ON o.order_id = r.order_id
     JOIN providers p ON p.provider_id = r.provider_id
     WHERE r.customer_id = ?
     ORDER BY r.created_at DESC"
);
$stmt->execute([$uid]);
$receipts = $stmt->fetchAll();

$active = 'receipts';
$page_title = 'My Payment Receipts';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h2 class="fw-bold mb-0"><i class="fas fa-receipt me-2"></i>My Payment Receipts</h2>
        </div>

        <?php if (!$receipts): ?>
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <p class="text-muted mb-2 text-center"><i class="fas fa-receipt fa-3x d-block mb-3" style="color:#0077b6;"></i>No receipts yet.</p>
                <p class="text-muted small text-center">Once an order's payment is paid or confirmed by the provider, its receipt appears here automatically — with the order details, provider info, amount paid and the date &amp; time.</p>
                <div class="text-center"><a href="orders.php" class="btn btn-primary"><i class="fas fa-shopping-bag me-2"></i>View My Orders</a></div>
            </div>
        </div>
        <?php else: ?>
        <div class="card border-0 shadow-sm rounded-4 p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead><tr><th>Receipt No</th><th>Order</th><th>Provider</th><th class="text-end">Amount Paid</th><th>Method</th><th>Date / Time</th><th class="text-end">Action</th></tr></thead>
                    <tbody>
                        <?php foreach ($receipts as $r): ?>
                        <tr>
                            <td><span class="fw-bold"><?php echo e($r['receipt_no']); ?></span></td>
                            <td><?php echo order_code((int)$r['order_id']); ?></td>
                            <td><?php echo e($r['business_name']); ?></td>
                            <td class="text-end fw-bold"><?php echo format_ugx($r['amount_paid']); ?></td>
                            <td><?php echo e(ucfirst(str_replace('_', ' ', $r['payment_method']))); ?><?php if ($r['payment_method'] === 'mobile_money' && $r['mobile_number']): ?><br><small class="text-muted"><?php echo e(strtoupper($r['mobile_network'] ?? '')); ?> · <?php echo e($r['mobile_number']); ?></small><?php endif; ?></td>
                            <td><?php echo date('d M Y, h:i A', strtotime($r['paid_at'] ?: $r['created_at'])); ?></td>
                            <td class="text-end">
                                <a href="receipt.php?order_id=<?php echo (int)$r['order_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye me-1"></i>View</a>
                                <a href="receipt.php?order_id=<?php echo (int)$r['order_id']; ?>#pdf" class="btn btn-sm btn-outline-success" title="Download as PDF (opens print dialog → Save as PDF)"><i class="fas fa-file-pdf me-1"></i>PDF</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div></div>
<script>
    // If the user tapped "PDF", open the print dialog for that receipt page.
    if (window.location.hash === '#pdf') { setTimeout(function(){ window.print(); }, 400); }
</script>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>