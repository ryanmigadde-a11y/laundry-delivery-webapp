<?php
/**
 * Laundry Wallet — balance, top-up (simulated MTN/Airtel) and transactions.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

if (!feature_enabled('wallet')) {
    flash('info', 'The Laundry Wallet is currently disabled.');
    redirect('dashboard.php');
}

$pdo = $GLOBALS['pdo'];
$user = current_user();
$uid = (int)$user['user_id'];

/* Top up — real MTN Collection when live, otherwise simulated. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['topup'])) {
    $amount = (float)($_POST['amount'] ?? 0);
    $number = trim($_POST['mobile_number'] ?? '');
    $network = ($_POST['network'] ?? 'mtn') === 'airtel' ? 'airtel' : 'mtn';
    if ($amount < 1000) {
        flash('danger', 'Minimum top-up is UGX 1,000.');
    } elseif ($number === '') {
        flash('danger', 'Enter your ' . strtoupper($network) . ' mobile money number.');
    } else {
        /* Real MTN RequestToPay for the wallet stream (externalId WALLET-...) */
        if (momo_live() && momo_collection_configured() && $network !== 'airtel') {
            $extId = 'WALLET-' . $uid . '-' . time();
            $res = momo_collect($amount, $extId, $number, 'Laundry Wallet topup payment', 'Payment for wallet-topup received');
            if ($res[0]) {
                wallet_tx($uid, $amount, 'credit', 'Wallet top-up via MTN (ref ' . $res[1] . ')');
                add_notification($uid, 'Wallet Top-up', format_ugx($amount) . ' was added to your Laundry Wallet (MTN ref ' . $res[1] . ').', 'php/customer/wallet.php');
                flash('success', 'Top-up successful! ' . format_ugx($amount) . ' added to your wallet. MTN ref: ' . $res[1]);
            } else {
                flash('danger', 'MTN payment failed: ' . e($res[1]) . ' Please try again.');
            }
        } else {
            /* Simulation / Airtel (no Airtel keys provided yet) */
            wallet_tx($uid, $amount, 'credit', 'Wallet top-up via ' . strtoupper($network) . ' (' . $number . ')');
            add_notification($uid, 'Wallet Top-up', format_ugx($amount) . ' was added to your Laundry Wallet.', 'php/customer/wallet.php');
            flash('success', 'Top-up successful! ' . format_ugx($amount) . ' added to your wallet.');
        }
    }
    redirect('wallet.php');
}

$balance = wallet_balance($uid);
$stmt = $pdo->prepare('SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY tx_id DESC LIMIT 30');
$stmt->execute([$uid]);
$transactions = $stmt->fetchAll();

$active = 'wallet';
$page_title = 'Laundry Wallet';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-wallet me-2"></i>Laundry Wallet</h2>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 p-4 text-white h-100" style="background: linear-gradient(135deg, #0077b6, #00b4d8);">
                    <small class="text-white-50">Available Balance</small>
                    <h2 class="fw-bold mb-0"><?php echo format_ugx($balance); ?></h2>
                    <small class="text-white-50">Use it at checkout — refunds, referral and promo credits land here.</small>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 p-4 h-100">
                    <h5 class="fw-bold mb-3"><i class="fas fa-plus-circle me-2" style="color:#28a745;"></i>Top Up Wallet</h5>
                    <form method="POST" class="row g-2 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label small mb-1">Amount (UGX)</label>
                            <input type="number" name="amount" class="form-control" min="1000" step="1000" value="10000" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small mb-1">Network</label>
                            <select name="network" class="form-select">
                                <option value="mtn">MTN Mobile Money</option>
                                <option value="airtel">Airtel Money</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small mb-1">Mobile Number</label>
                            <input type="tel" name="mobile_number" class="form-control" placeholder="+256 700 000000" required>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" name="topup" value="1" class="btn btn-success w-100"><i class="fas fa-bolt me-1"></i>Top Up</button>
                        </div>
                        <div class="col-12"><small class="text-muted"><i class="fas fa-shield-alt me-1"></i>Payments are simulated in this demo. Add MTN/Airtel API keys (see README) to go live.</small></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-receipt me-2" style="color:#0077b6;"></i>Wallet Transactions</h5>
            <?php if (!$transactions): ?>
                <p class="text-muted text-center py-4 mb-0">No wallet transactions yet.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Date</th><th>Reason</th><th>Type</th><th>Amount</th></tr></thead>
                    <tbody>
                        <?php foreach ($transactions as $t): ?>
                        <tr>
                            <td><?php echo format_date($t['created_at']); ?></td>
                            <td><?php echo e($t['reason']); ?></td>
                            <td>
                                <?php if ($t['type'] === 'credit'): ?>
                                    <span class="badge bg-success">Credit</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Debit</span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold <?php echo $t['type'] === 'credit' ? 'text-success' : 'text-danger'; ?>">
                                <?php echo ($t['type'] === 'credit' ? '+' : '-') . format_ugx($t['amount']); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>