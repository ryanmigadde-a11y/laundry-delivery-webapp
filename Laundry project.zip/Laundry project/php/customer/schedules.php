<?php
/**
 * Automatic Laundry Schedule — weekly, biweekly or monthly recurring laundry
 * with reminders before pickup. Due schedules are auto-converted into orders.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

if (!feature_enabled('recurring')) {
    flash('info', 'Recurring schedules are currently disabled.');
    redirect('dashboard.php');
}

$pdo = $GLOBALS['pdo'];
$user = current_user();
$uid = (int)$user['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_schedule'])) {
    $frequency = in_array($_POST['frequency'] ?? '', ['weekly', 'biweekly', 'monthly'], true) ? $_POST['frequency'] : 'weekly';
    $nextPickup = trim($_POST['next_pickup'] ?? '');
    $orderId = (int)($_POST['order_id'] ?? 0);
    $stmt = $pdo->prepare(
        'SELECT o.provider_id, i.service_name, i.clothing_type, i.quantity, pr.price
         FROM orders o
         JOIN order_items i ON i.order_id = o.order_id
         JOIN provider_pricing pr ON pr.provider_id = o.provider_id AND pr.service_name = i.service_name AND pr.clothing_type = i.clothing_type
         WHERE o.order_id = ? AND o.customer_id = ? AND o.status IN ("delivered","completed")
         LIMIT 1'
    );
    $stmt->execute([$orderId, $uid]);
    $row = $stmt->fetch();
    if ($row && $nextPickup) {
        $pdo->prepare(
            'INSERT INTO laundry_schedules (customer_id, provider_id, frequency, service_name, clothing_type, quantity, price, next_pickup)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$uid, (int)$row['provider_id'], $frequency, $row['service_name'], $row['clothing_type'], (int)$row['quantity'], (float)$row['price'], $nextPickup]);
        add_notification($uid, 'Automatic Schedule Active', 'Your ' . $frequency . ' laundry schedule starts ' . format_date($nextPickup) . '.', 'php/customer/schedules.php');
        flash('success', 'Your automatic laundry schedule has been created.');
    } else {
        flash('danger', 'Could not create that schedule. Pick a completed order with a valid date.');
    }
    redirect('schedules.php');
}

if (isset($_POST['cancel_schedule'])) {
    $pdo->prepare('UPDATE laundry_schedules SET active = 0 WHERE schedule_id = ? AND customer_id = ?')
        ->execute([(int)$_POST['cancel_schedule'], $uid]);
    flash('success', 'Schedule cancelled.');
    redirect('schedules.php');
}

$lastOrders = $pdo->prepare(
    "SELECT DISTINCT o.order_id, o.total_price, o.created_at, p.business_name
     FROM orders o JOIN providers p ON p.provider_id = o.provider_id
     WHERE o.customer_id = ? AND o.status IN ('delivered','completed')
     ORDER BY o.created_at DESC LIMIT 10"
);
$lastOrders->execute([$uid]);
$lastOrders = $lastOrders->fetchAll();

$schedules = $pdo->prepare(
    'SELECT s.*, p.business_name FROM laundry_schedules s JOIN providers p ON p.provider_id = s.provider_id
     WHERE s.customer_id = ? ORDER BY s.created_at DESC'
);
$schedules->execute([$uid]);
$schedules = $schedules->fetchAll();

$active = 'recurring';
$page_title = 'Automatic Laundry Schedule';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-calendar-week me-2"></i>Automatic Laundry Schedule</h2>
        <p class="text-muted mb-4">Set it once — we create a new order automatically on your chosen pickup day.</p>

        <div class="row g-4">
            <div class="col-md-5">
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-plus-circle me-2" style="color:#0077b6;"></i>Create a Schedule</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Base it on a previous order</label>
                            <select name="order_id" class="form-select" required>
                                <option value="">— Select a completed order —</option>
                                <?php foreach ($lastOrders as $o): ?>
                                <option value="<?php echo (int)$o['order_id']; ?>"><?php echo order_code((int)$o['order_id']); ?> · <?php echo e($o['business_name']); ?> · <?php echo format_ugx($o['total_price']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Frequency</label>
                            <select name="frequency" class="form-select">
                                <option value="weekly">Every week</option>
                                <option value="biweekly">Every 2 weeks</option>
                                <option value="monthly">Every month</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Next pickup date</label>
                            <input type="date" name="next_pickup" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <button type="submit" name="create_schedule" value="1" class="btn btn-primary w-100"><i class="fas fa-calendar-check me-2"></i>Create Schedule</button>
                    </form>
                </div>
                <div class="alert alert-info rounded-4 mb-0"><i class="fas fa-info-circle me-2"></i>On each pickup day the system creates a pending order automatically. You can pay after it is generated, and a reminder notification is sent before pickup.</div>
            </div>

            <div class="col-md-7">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-list-check me-2" style="color:#0077b6;"></i>Your Active Schedules</h5>
                    <?php if (!$schedules): ?>
                        <p class="text-muted text-center py-4 mb-0">You have no schedules yet. Create one on the left.</p>
                    <?php endif; ?>
                    <?php foreach ($schedules as $s): ?>
                    <div class="border rounded-3 p-3 mb-3 <?php echo $s['active'] ? '' : 'opacity-50'; ?>">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <strong><?php echo e($s['business_name']); ?></strong>
                                <div class="small text-muted">
                                    <?php echo e($s['clothing_type']); ?> × <?php echo (int)$s['quantity']; ?> (<?php echo e($s['service_name']); ?>) · <?php echo format_ugx($s['quantity'] * $s['price']); ?>
                                </div>
                                <div class="small">
                                    <span class="badge bg-info text-dark text-capitalize"><?php echo e($s['frequency']); ?></span>
                                    <span class="badge bg-light text-dark border">Next: <?php echo format_date($s['next_pickup']); ?></span>
                                    <?php if (!$s['active']): ?><span class="badge bg-secondary">Cancelled</span><?php endif; ?>
                                </div>
                            </div>
                            <?php if ($s['active']): ?>
                            <form method="POST" onsubmit="return confirm('Pause this recurring schedule?');">
                                <input type="hidden" name="cancel_schedule" value="<?php echo (int)$s['schedule_id']; ?>">
                                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-pause me-1"></i>Pause</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>