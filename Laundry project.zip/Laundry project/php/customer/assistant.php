<?php
/**
 * Smart Laundry Assistant — customers describe what they need in normal
 * language (or snap a photo) and get suggested items, estimated prices,
 * provider recommendations and a ready-to-confirm order.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['customer'], $BASE);

if (!feature_enabled('assistant')) {
    flash('info', 'The Smart Assistant is currently disabled.');
    redirect('dashboard.php');
}

$pdo = $GLOBALS['pdo'];
$user = current_user();

$suggestions = [];
$photo = null;
$asked = false;
$quick_add = $_GET['add'] ?? null;

/* Quick-add from popular services chips */
if ($quick_add) {
    $asked = true;
    $parts = explode('|', $quick_add);
    if (count($parts) === 2) {
        $parsed = parse_laundry_text($parts[1] . ' ' . $parts[0]);
        foreach ($parsed as $one) {
            $avg = estimate_price($one['service'], $one['clothing']);
            $one['est_price'] = $avg;
            $one['est_total'] = $avg !== null ? $avg * $one['qty'] : null;
            $suggestions[] = $one;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['describe'])) {
    $asked = true;
    $parsed = parse_laundry_text(trim($_POST['laundry_text'] ?? ''));
    foreach ($parsed as $one) {
        $avg = estimate_price($one['service'], $one['clothing']);
        $one['est_price'] = $avg;
        $one['est_total'] = $avg !== null ? $avg * $one['qty'] : null;
        $suggestions[] = $one;
    }
    if (!$suggestions) {
        flash('info', 'I could not detect laundry items. Try mentioning things like "5 shirts", "2 suits dry cleaning" or "blankets".');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['laundry_photo'])) {
    $pic = handle_upload($_FILES['laundry_photo'], 'snap');
    if ($pic) {
        $photo = $BASE . 'assets/images/uploads/' . rawurlencode($pic);
        flash('info', 'Photo attached. Pick the items you see below to build your order.');
    } else {
        flash('warning', 'Photo not saved: ' . ($GLOBALS['upload_error'] ?? 'unknown error'));
    }
    $asked = true;
}

/* Build order from assistant suggestions */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['build_order'])) {
    $sel = $_POST['sel'] ?? [];
    $items = [];
    $total = 0;
    foreach ($sel as $key) {
        $parts = explode('|', $key);
        if (count($parts) !== 2) continue;
        $service = $parts[0];
        $clothing = $parts[1];
        $qty = max(1, (int)($_POST['qty'][$key] ?? 1));
        $price = estimate_price($service, $clothing);
        if ($price === null) continue;
        $subtotal = $price * $qty;
        $items[] = [
            'service_name'  => $service,
            'clothing_type' => $clothing,
            'quantity'      => $qty,
            'price'         => $price,
            'subtotal'      => $subtotal,
        ];
        $total += $subtotal;
    }
    if ($items) {
        $token = bin2hex(random_bytes(8));
        $_SESSION['order_drafts'][$token] = [
            'customer_id' => (int)$user['user_id'],
            'provider_id' => 0,
            'items'       => $items,
            'total'       => $total,
            'from_assistant' => true,
        ];
        flash('success', 'Order built! Now pick a provider to continue.');
        redirect($BASE . 'php/customer/new_order/select_provider.php?assistant_token=' . $token);
    } else {
        flash('warning', 'Please select at least one item to build your order.');
    }
}

$recommended = recommend_providers((int)$user['user_id'], 3);
$services = ['Wash & Fold', 'Dry Cleaning', 'Pressing Only', 'Stain Removal', 'Shoe Cleaning', 'Bedding & Curtains'];

/* Quick-add popular combos */
$quickCombos = [
    ['svc' => 'Wash & Fold', 'item' => 'Shirts', 'icon' => 'fa-tshirt'],
    ['svc' => 'Wash & Fold', 'item' => 'Trousers', 'icon' => 'fa-user'],
    ['svc' => 'Dry Cleaning', 'item' => 'Suits', 'icon' => 'fa-user-tie'],
    ['svc' => 'Wash & Fold', 'item' => 'Blankets', 'icon' => 'fa-bed'],
    ['svc' => 'Pressing Only', 'item' => 'Dresses', 'icon' => 'fa-person-dress'],
    ['svc' => 'Stain Removal', 'item' => 'Shirts', 'icon' => 'fa-magic'],
];

/* Past order suggestions */
$pastItems = $pdo->query(
    "SELECT oi.service_name, oi.clothing_type, COUNT(*) AS freq
     FROM order_items oi JOIN orders o ON o.order_id = oi.order_id
     WHERE o.customer_id = " . (int)$user['user_id'] . "
     GROUP BY oi.service_name, oi.clothing_type ORDER BY freq DESC LIMIT 6"
)->fetchAll();

$active = 'assistant';
$page_title = 'Smart Laundry Assistant';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/customer_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-robot me-2"></i>Smart Laundry Assistant</h2>
        <p class="text-muted mb-4">Tell us what you need in plain language — we suggest services, prices and providers.</p>

        <div class="row g-4">
            <div class="col-md-7">
                <!-- Quick-add combos -->
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-bolt me-2" style="color:#f5a623;"></i>Quick Add — tap to estimate</h5>
                    <div class="d-flex flex-wrap gap-2">
                        <?php foreach ($quickCombos as $qc): ?>
                        <a href="?add=<?php echo urlencode($qc['svc'] . '|' . $qc['item']); ?>" class="btn btn-outline-primary btn-sm rounded-pill">
                            <i class="fas <?php echo $qc['icon']; ?> me-1"></i><?php echo e($qc['item']); ?> (<?php echo e($qc['svc']); ?>)
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Describe your laundry -->
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-keyboard me-2" style="color:#0077b6;"></i>Describe your laundry</h5>
                    <form method="POST">
                        <textarea name="laundry_text" class="form-control mb-3" rows="3"
                            placeholder="e.g. I have 5 shirts and 2 suits that need dry cleaning, plus a blanket to wash"><?php echo e($_POST['laundry_text'] ?? ''); ?></textarea>
                        <button type="submit" name="describe" value="1" class="btn btn-primary"><i class="fas fa-wand-magic-sparkles me-2"></i>Get Suggestions</button>
                    </form>
                </div>

                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-camera me-2" style="color:#0077b6;"></i>Snap-to-Order (photo)</h5>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="file" name="laundry_photo" class="form-control mb-3" accept="image/*" required>
                        <button type="submit" class="btn btn-outline-primary"><i class="fas fa-cloud-arrow-up me-2"></i>Attach Photo</button>
                    </form>
                    <?php if ($photo): ?>
                        <div class="text-center mt-3">
                            <img src="<?php echo e($photo); ?>" class="img-fluid rounded-4" style="max-height: 260px;" alt="Laundry photo">
                        </div>
                    <?php endif; ?>
                </div>
                <?php if ($asked && $suggestions): ?>
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-lightbulb me-2" style="color:#f5a623;"></i>Suggested Order</h5>
                    <form method="POST">
                    <table class="table mb-3">
                        <thead><tr><th></th><th>Service</th><th>Item</th><th>Qty</th><th>Est. Price</th><th>Subtotal</th></tr></thead>
                        <tbody>
                        <?php $grand = 0; foreach ($suggestions as $s): $key = $s['service'] . '|' . $s['clothing']; ?>
                            <tr>
                                <td><input type="checkbox" name="sel[]" value="<?php echo e($key); ?>" class="form-check-input" checked></td>
                                <td><?php echo e($s['service']); ?></td>
                                <td><?php echo e($s['clothing']); ?></td>
                                <td style="width:80px;"><input type="number" name="qty[<?php echo e($key); ?>]" value="<?php echo (int)$s['qty']; ?>" min="1" max="200" class="form-control form-control-sm qty-input"></td>
                                <td><?php echo $s['est_price'] !== null ? format_ugx($s['est_price']) : '<span class="text-muted">varies</span>'; ?></td>
                                <td class="fw-bold subtotal-cell"><?php echo $s['est_total'] !== null ? format_ugx($s['est_total']) : '—'; ?></td>
                            </tr>
                        <?php if ($s['est_total'] !== null) $grand += $s['est_total']; endforeach; ?>
                        </tbody>
                        <tfoot><tr><th colspan="5" class="text-end">Estimated Total</th><th id="grandTotal"><?php echo format_ugx($grand); ?></th></tr></tfoot>
                    </table>
                    <button type="submit" name="build_order" value="1" class="btn btn-success btn-lg w-100 mt-2"><i class="fas fa-cart-plus me-2"></i>Build This Order</button>
                    </form>
                    <hr>
                    <h6 class="fw-bold mb-2"><i class="fas fa-arrow-right me-2"></i>Or start with a recommended provider:</h6>
                    <div class="d-grid gap-2">
                        <?php foreach ($recommended as $r): ?>
                        <a href="<?php echo $BASE; ?>php/customer/new_order/services.php?provider_id=<?php echo (int)$r['provider_id']; ?>" class="btn btn-outline-primary">
                            <i class="fas fa-store me-2"></i><?php echo e($r['business_name']); ?> <span class="badge bg-primary ms-1"><?php echo $r['rec_score']; ?>% match</span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-5">
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-star me-2" style="color:#f5a623;"></i>Recommended for you</h5>
                    <?php foreach ($recommended as $r): ?>
                        <div class="border rounded-3 p-3 mb-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <strong><?php echo e($r['business_name']); ?></strong>
                                <span class="badge bg-primary"><?php echo $r['rec_score']; ?>% match</span>
                            </div>
                            <small class="text-muted d-block mb-1"><?php echo e($r['business_location'] ?: 'Uganda'); ?> · <?php echo star_icons($r['avg_rating'], true); ?></small>
                            <?php if ($r['rec_reasons']): ?>
                                <div class="mb-2"><?php foreach ($r['rec_reasons'] as $why): ?><span class="badge bg-light text-dark border me-1"><?php echo e($why); ?></span><?php endforeach; ?></div>
                            <?php endif; ?>
                            <a href="<?php echo $BASE; ?>php/customer/new_order/services.php?provider_id=<?php echo (int)$r['provider_id']; ?>" class="btn btn-sm btn-outline-primary">View Menu</a>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($pastItems): ?>
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-history me-2" style="color:#0077b6;"></i>Order Again</h5>
                    <p class="small text-muted mb-2">Based on your past orders:</p>
                    <div class="d-flex flex-wrap gap-2">
                        <?php foreach ($pastItems as $pi): ?>
                        <a href="?add=<?php echo urlencode($pi['service_name'] . '|' . $pi['clothing_type']); ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
                            <i class="fas fa-redo me-1"></i><?php echo e($pi['clothing_type']); ?> (<?php echo e($pi['service_name']); ?>) ×<?php echo (int)$pi['freq']; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-tags me-2" style="color:#0077b6;"></i>Popular services</h5>
                    <?php foreach ($services as $s): ?>
                        <span class="badge bg-light text-dark border me-1 mb-2 p-2"><i class="fas <?php echo service_icon($s); ?> me-1"></i><?php echo e($s); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>
</div></div>
<script>
    /* Live price re-calculation when qty changes */
    document.querySelectorAll('.qty-input').forEach(function(input) {
        input.addEventListener('input', function() {
            const row = this.closest('tr');
            const priceText = row.cells[4].textContent.replace(/[^0-9]/g, '');
            const price = parseFloat(priceText) || 0;
            const qty = parseInt(this.value) || 0;
            const subtotal = price * qty;
            row.querySelector('.subtotal-cell').textContent = 'UGX ' + subtotal.toLocaleString();
            /* Recalculate grand total */
            let grand = 0;
            document.querySelectorAll('.qty-input').forEach(function(el) {
                const r = el.closest('tr');
                const pt = r.cells[4].textContent.replace(/[^0-9]/g, '');
                const p = parseFloat(pt) || 0;
                const q = parseInt(el.value) || 0;
                grand += p * q;
            });
            document.getElementById('grandTotal').textContent = 'UGX ' + grand.toLocaleString();
        });
    });
</script>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>