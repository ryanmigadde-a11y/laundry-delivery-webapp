<?php
/**
 * LaundryExpress Uganda - Core Configuration
 * XAMPP / MySQL (phpMyAdmin) setup.
 *
 * 1. Start Apache + MySQL in XAMPP control panel
 * 2. Import database/laundry_db.sql via phpMyAdmin (creates the `laundry_db` database)
 * 3. Open http://localhost/laundry%20proj%20in%20html/
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Africa/Kampala');

/* ---------- Paths ---------- */
define('BASE_PATH', dirname(__DIR__, 2));                      // project root folder
define('UPLOAD_DIR', BASE_PATH . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'uploads');

/* Make sure the uploads folder exists and is reachable at bootstrap (fixes profile pics disappearing). */
if (!is_dir(UPLOAD_DIR)) {
    @mkdir(UPLOAD_DIR, 0777, true);
}
define('UPLOAD_URL', 'assets/images/uploads/');

/* ---------- Database credentials (XAMPP defaults) ---------- */
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'laundry_db');
define('DB_USER', 'root');
define('DB_PASS', '');

/* ---------- Admin (hardcoded as requested) ---------- */
define('ADMIN_EMAIL', 'ryanhitmus@gmail.com');
define('ADMIN_PASSWORD', '2224.Ryan');

/* ---------- Google Sign-In (OAuth 2.0) ----------
 * Create credentials at https://console.cloud.google.com/apis/credentials
 * (OAuth Client ID -> Web application). Paste the Client ID below and the
 * "Continue with Google" buttons on the login/register pages come alive.
 * Leave empty and the buttons simply alert that Google login is not configured. */
define('GOOGLE_CLIENT_ID', '407280724679-2nas3f7aepjnihm2cijlg6tun063ulu9.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', '');   // optional: only needed for the server-side OAuth code flow

/* ---------- Email / SMS / Payment API keys (two-factor + Mobile Money) ----------
 * Easiest providers for Uganda:
 *   EMAIL OTP : SendGrid  -> https://dashboard.sendgrid.com (free tier, 100/day)
 *             : or Gmail app password + SMTP below (set SMTP_ENABLED=true)
 *   SMS  OTP : Africa's Talking  -> https://account.africastalking.com (free sandbox)
 *   Payments  : MTN MoMo  -> Open API portal:
 *                 - Collection  (orders + wallet top-up, "RequestToPay")
 *                 - Distribution (provider payouts + provider subscriptions)
 *   Airtel    : see vendor portal / aggregator (Yo!, Dusupay, Flutterwave) — leave blank to keep Airtel simulated.
 */
/* --- SendGrid HTTP API (easiest reliable email for OTP + notifications) --- */
define('SENDGRID_API_KEY', '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');
define('SENDGRID_FROM_EMAIL', 'laundryexpressuganda@gmail.com');

/* --- Gmail SMTP (alternative email channel; app password without spaces) --- */
define('SMTP_ENABLED', false);              // true once your SMTP creds below are set
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'laundryexpressuganda@gmail.com');
define('SMTP_PASS', 'qynsydoepknugwlq');    // Gmail "App Password" (spaces removed)
define('SMTP_FROM', 'laundryexpressuganda@gmail.com'); // sender shown on emails

/* --- Africa's Talking SMS OTP --- */
define('SMS_ENABLED', false);              // true to send OTP via SMS instead of email
define('AFRICAS_TALKING_API_KEY', 'atsk_0e8b0a6ea937b03c0b71cddc939145719616c1c05cb63a1dace9fcd09164af1cb0ffca51');
define('AFRICAS_TALKING_USERNAME', 'sandbox');
define('SMS_SENDER_ID', 'LaundryExpressUg');

/* --- MTN MoMo Open API (Uganda) ---
 * Collection  : http://momodeveloper.mtn.com/basic-details  (orders + wallet top-up)
 * Distribution: provider payouts (order money to provider) + provider subscriptions.
 * If MTN_MOMO_SIMULATE is true (or a call fails), the app falls back to the
 * built-in USSD simulation so the demo never breaks. Set to false when live.  */
define('MTN_MOMO_SIMULATE', true);          // false when you are in a live/sandbox-approved environment
define('MTN_MOMO_ENV', 'sandbox');          // 'sandbox' or 'mtnuganda' (live)
define('MTN_MOMO_BASE_URL', 'https://sandbox.momodeveloper.mtn.com');
define('MTN_MOMO_PRIMARY_KEY', '');         // optional: account "Primary Key" if provided

/* Collection (RequestToPay) — customers pay for ORDERS + WALLET TOP-UP */
define('MTN_MOMO_COLLECTION_KEY', '7670a6e4-7523-4677-9d83-b69395982129');          // API User UUID / subscription key
define('MTN_MOMO_COLLECTION_API_KEY', 'd7eaf794e55b40e79175a02a90d2b1c2');         // API Key

/* Distribution (Disbursement) — send ORDER money to providers + lets providers pay SUBSCRIPTIONS */
define('MTN_MOMO_DISTRIBUTION_KEY', '58a0ad9c-72e9-4ac6-af56-0617a965ee6b');       // API User UUID / subscription key
define('MTN_MOMO_DISTRIBUTION_API_KEY', '0551b64aa0b945a09bc4ab19228424e8');       // API Key

/* Automatically disburse the full order total to the provider's MTN number as
   soon as the customer's mobile-money collection succeeds. Set false to pay
   providers only after an order is marked completed. */
define('MTN_PAYOUT_ON_COLLECT', true);

/* Route provider SUBSCRIPTION charges through the Distribution product instead
   of the Collection product (default false — subscriptions are normally a
   Collection/RequestToPay that debits the provider). Set true ONLY if your
   sandbox/live uses Distribution for subscriptions. */
define('MTN_MOMO_SUBSCRIPTION_USE_DISTRIBUTION', false);

/* Optional webhook for MTN async callbacks (you must expose this over HTTPS). */
define('MTN_MOMO_CALLBACK_URL', '');

/* --- Airtel Money (NOT provided yet — keep blank to stay on simulation) --- */
define('AIRTEL_MONEY_API_KEY', '');
define('AIRTEL_MONEY_USERNAME', '');

/* ---------- Database connection (PDO) ---------- */
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    $msg = htmlspecialchars($e->getMessage());
    /* Detect a missing PDO MySQL driver — the classic "could not find driver"
       you get when php -S is run with a PHP build that lacks pdo_mysql. */
    $driverHint = '';
    if (!in_array('mysql', PDO::getAvailableDrivers(), true)) {
        $driverHint =
            '<div class="alert alert-warning mt-4">' .
            '<h6 class="fw-bold"><i class="fas fa-plug me-2"></i>This PHP does not have the <code>pdo_mysql</code> driver enabled.</h6>' .
            '<p class="mb-2">MySQL is probably fine — the <code>php</code> command used to start the server is missing the MySQL driver.<br>' .
            'Start the server with <strong>XAMPP&rsquo;s PHP</strong> instead (the same one Apache uses):</p>' .
            '<pre class="bg-dark text-white rounded-3 p-3 mb-2 overflow-auto"><code>cd /d "C:\Users\RYAN M\Desktop\laundry project"
"C:\xampp\php\php.exe" -S localhost:8000</code></pre>' .
            '<p class="mb-0 small text-muted">Or simply double-click <code>start-localhost-8000.bat</code> in the project folder.</p>' .
            '</div>';
    }
    die(
        '<!DOCTYPE html><html><head><title>Database setup required</title>' .
        '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>' .
        '<body class="bg-light"><div class="container py-5"><div class="card shadow rounded-4 p-4 mx-auto" style="max-width:720px">' .
        '<h3 class="fw-bold text-danger mb-3"><i class="fas fa-database me-2"></i>Database connection failed</h3>' .
        '<p class="mb-2">Make sure <strong>MySQL is running</strong> in the XAMPP control panel, then import the schema:</p>' .
        '<ol class="mb-3"><li>Open <a href="http://localhost/phpmyadmin" target="_blank">phpMyAdmin</a></li>' .
        '<li>Create a database named <code>laundry_db</code></li>' .
        '<li>Import the file <code>database/laundry_db.sql</code> from this project</li></ol>' .
        $driverHint .
        '<p class="text-muted small mb-0">Technical details: ' . $msg . '</p>' .
        '</div></div></body></html>'
    );
}

/**
 * Read a value from the system_config table (admin editable).
 */
function get_config($key, $default = null)
{
    global $pdo;
    static $cache = [];
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }
    try {
        $stmt = $pdo->prepare('SELECT config_value FROM system_config WHERE config_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        $cache[$key] = $row ? $row['config_value'] : $default;
    } catch (PDOException $e) {
        $cache[$key] = $default;
    }
    return $cache[$key];
}

/**
 * Insert or update a system_config key.
 */
function set_config($key, $value)
{
    global $pdo;
    $stmt = $pdo->prepare(
        'INSERT INTO system_config (config_key, config_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE config_value = VALUES(config_value), updated_at = NOW()'
    );
    return $stmt->execute([$key, $value]);
}

