<?php
/**
 * Dynamic top navbar - links change based on the logged-in user role.
 * Expects in scope: $BASE (relative path to project root).
 */
$user = current_user();
$unread = $user ? unread_count($user['user_id']) : 0;
$isProvider = ($user['user_type'] ?? '') === 'provider';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-gradient-primary shadow-sm">
    <div class="container">
        <button class="btn btn-outline-light me-2 d-lg-none sidebar-toggle-btn" type="button" aria-label="Open menu"><i class="fas fa-bars"></i></button>
        <a class="navbar-brand fw-bold" href="<?php echo $BASE; ?>index.php"><i class="fas fa-tshirt me-2"></i>LaundryExpress</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if ($user && ($_SESSION['user_type'] ?? $user['user_type'] ?? '') === 'customer'): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/customer/dashboard.php"><i class="fas fa-tachometer-alt me-1"></i>Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/customer/orders.php"><i class="fas fa-shopping-bag me-1"></i>Orders</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/customer/new_order/select_provider.php"><i class="fas fa-plus-circle me-1"></i>New Order</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/customer/settings.php"><i class="fas fa-cog me-1"></i>Settings</a></li>
                <?php elseif ($user && ($_SESSION['user_type'] ?? $user['user_type'] ?? '') === 'provider'): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/provider/dashboard.php"><i class="fas fa-tachometer-alt me-1"></i>Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/provider/orders.php"><i class="fas fa-shopping-bag me-1"></i>Orders</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/provider/business_settings.php"><i class="fas fa-store me-1"></i>Business</a></li>
                <?php endif; ?>
                <?php if ($user): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo e($user['full_name'] ?? $_SESSION['full_name'] ?? 'Account'); ?>
                            <?php if ($unread > 0): ?><span class="badge bg-danger"><?php echo $unread; ?></span><?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?php echo $BASE; ?>php/notifications.php"><i class="fas fa-bell me-2"></i>Notifications<?php if ($unread > 0): ?> <span class="badge bg-danger ms-1"><?php echo $unread; ?></span><?php endif; ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo $BASE; ?>php/<?php echo $isProvider ? 'provider' : 'customer'; ?>/settings.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?php echo $BASE; ?>php/auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/auth/login.php"><i class="fas fa-sign-in-alt me-1"></i>Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo $BASE; ?>php/auth/register.php"><i class="fas fa-user-plus me-1"></i>Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
