<?php
/**
 * LaundryExpress Uganda - Session bootstrap & auth guards.
 * Every page includes this file first.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/momo.php';
