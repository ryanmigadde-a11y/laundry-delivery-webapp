<?php
/**
 * LaundryExpress Uganda - Reusable helper functions
 */

/* ---------- Output escaping ---------- */
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* ---------- Redirect ---------- */
function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

/* ---------- Flash messages ---------- */
function flash($type = null, $message = null)
{
    if ($type !== null && $message !== null) {
        $_SESSION['flash'][$type] = $message;
        return;
    }
    $out = '';
    if (!empty($_SESSION['flash'])) {
        $icons = ['success' => 'fa-check-circle', 'danger' => 'fa-exclamation-circle', 'warning' => 'fa-exclamation-triangle', 'info' => 'fa-info-circle'];
        foreach ($_SESSION['flash'] as $type => $msg) {
            $icon = $icons[$type] ?? 'fa-info-circle';
            $out .= '<div class="alert alert-' . e($type) . ' alert-dismissible fade show fade-in-up" role="alert">'
                  . '<i class="fas ' . e($icon) . ' me-2"></i>' . e($msg)
                  . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
        unset($_SESSION['flash']);
    }
    return $out;
}

/* ---------- Authentication state ---------- */
function is_logged_in()
{
    return !empty($_SESSION['user_id']);
}

function is_admin()
{
    return !empty($_SESSION['admin_logged_in']);
}

function current_user()
{
    global $pdo;
    static $user = null;
    if ($user !== null) {
        return $user;
    }
    if (!is_logged_in()) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch() ?: null;
    return $user;
}

/* Guard: user must be logged in (optionally of a given type).
   $BASE = relative path from current page back to the project root, e.g. '../../'. */
function require_login($types = null, $BASE = '../')
{
    if (!is_logged_in()) {
        flash('warning', 'Please login to continue.');
        redirect($BASE . 'php/auth/login.php');
    }
    $user = current_user();
    if (!$user || ($user['status'] ?? 'active') === 'suspended') {
        session_unset();
        session_destroy();
        flash('danger', 'Your account has been suspended. Contact support.');
        redirect($BASE . 'php/auth/login.php');
    }
    if ($types !== null) {
        $types = (array)$types;
        if (!in_array($_SESSION['user_type'], $types, true)) {
            flash('danger', 'You are not allowed to access that page.');
            redirect($BASE . 'index.php');
        }
    }
}

/* Guard: admin panel pages. */
function require_admin_page($BASE = '../')
{
    if (!is_admin()) {
        flash('warning', 'Admin login required.');
        redirect($BASE . 'php/admin/login.php');
    }
}

/* ---------- Formatting ---------- */
function format_ugx($amount)
{
    return 'UGX ' . number_format((float)$amount);
}

function order_code($order_id)
{
    return '#ORD-' . str_pad((string)$order_id, 5, '0', STR_PAD_LEFT);
}

function time_ago($datetime)
{
    $ts = strtotime($datetime);
    if (!$ts) return '';
    $diff = time() - $ts;
    if ($diff < 60)       return 'just now';
if ($diff < 3600)     return floor($diff / 60) . ' min ago';
    if ($diff < 86400)    return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800)   return floor($diff / 86400) . ' days ago';
    return date('d M Y', $ts);
}

function format_date($date)
{
    return $date ? date('d M Y', strtotime($date)) : '&mdash;';
}

/* ---------- Status helpers ---------- */
function status_badge($status)
{
    $map = [
        'pending'          => ['bg-warning text-dark', 'Pending'],
        'active'           => ['bg-primary', 'Active'],
        'in_progress'      => ['bg-info text-dark', 'In Progress'],
        'out_for_delivery' => ['bg-secondary', 'Out for Delivery'],
        'delivered'        => ['bg-success', 'Delivered'],
        'completed'        => ['bg-success', 'Completed'],
        'cancelled'        => ['bg-danger', 'Cancelled'],
        'paid'             => ['bg-success', 'Paid'],
        'confirmed'        => ['bg-success', 'Payment Confirmed'],
    ];
    $m = $map[$status] ?? ['bg-secondary', ucfirst(str_replace('_', ' ', (string)$status))];
    return '<span class="badge ' . $m[0] . '">' . e($m[1]) . '</span>';
}

/* Step index (0..4) for the order tracking bar:
   Placed -> Accepted -> In Progress -> Out for Delivery -> Delivered */
function status_step_index($status)
{
    switch ($status) {
        case 'pending':          return 0;
        case 'active':           return 1;
        case 'in_progress':      return 2;
        case 'out_for_delivery': return 3;
        case 'delivered':
        case 'completed':        return 4;
        default:                 return 0;
    }
}

/* ---------- Stars ---------- */
function star_icons($rating, $small = false)
{
    $rating = (float)$rating;
    $cls = $small ? 'fa-xs' : '';
    $html = '';
    for ($i = 1; $i <= 5; $i++) {
        if ($rating >= $i) {
            $html .= '<i class="fas fa-star text-warning ' . $cls . '"></i>';
        } elseif ($rating >= $i - 0.5) {
            $html .= '<i class="fas fa-star-half-alt text-warning ' . $cls . '"></i>';
        } else {
            $html .= '<i class="fas fa-star text-muted ' . $cls . '"></i>';
        }
    }
    return $html;
}

/* ---------- Platform subscription (no more per-order customer deduction) ---------- */
function calc_deduction($total)
{
    return 0.0; // per-order platform fee removed — providers pay a monthly subscription only
}

/** Provider's monthly subscription fee (admin can change it). */
function get_subscription_fee()
{
    return (float)get_config('provider_subscription_fee', 2500);
}

/** True if the provider's subscription is currently valid. */
function provider_subscription_active($provider)
{
    $until = $provider['fee_paid_until'] ?? null;
    return $until && strtotime($until) >= strtotime(date('Y-m-d'));
}

/** Clothing colors the customer can pick when ordering. */
function clothing_color_list()
{
    return ['White', 'Black', 'Blue', 'Red', 'Green', 'Yellow', 'Purple', 'Pink', 'Grey', 'Brown', 'Orange', 'Mixed'];
}

/** Standard clothing types every provider can price per service. */
function clothing_type_list()
{
    return [
        'Shirt', 'Trouser', 'Dress', 'Coat/Suit', 'Jacket/Sweater',
        'Blanket', 'Carpet', 'Curtain', 'Sock', 'Towel', 'Underwear', 'Other'
    ];
}

/* ---------- Notifications ---------- */
/**
* Record the platform revenue (deduction) for an order once it is accepted.
 * Idempotent: uses the unique order_id so it can't be double-counted.
 */
function record_platform_revenue($order_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT provider_id, subtotal, platform_deduction FROM orders WHERE order_id = ? LIMIT 1');
    $stmt->execute([(int)$order_id]);
    $order = $stmt->fetch();
    if (!$order) return;
    $deduction = (float)$order['platform_deduction'];
    if ($deduction <= 0) return;
    $rule = ((float)$order['subtotal'] < 5000)
        ? 'Order below UGX 5,000: flat ' . $deduction
        : 'Order above UGX 5,000: flat ' . $deduction;
    $stmt = $pdo->prepare(
        'INSERT INTO platform_revenue (order_id, provider_id, amount, deduction_rule_applied) VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE amount = VALUES(amount), deduction_rule_applied = VALUES(deduction_rule_applied)'
    );
    $stmt->execute([(int)$order_id, (int)$order['provider_id'], $deduction, $rule]);
}

function add_notification($user_id, $title, $message, $link = null)
{
    global $pdo;
    if (!$user_id) return;
    $stmt = $pdo->prepare('INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)');
    $stmt->execute([$user_id, $title, $message, $link]);
}

function unread_count($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT COUNT(*) c FROM notifications WHERE user_id = ? AND is_read = 0');
    $stmt->execute([$user_id]);
    return (int)$stmt->fetchColumn();
}

/* ---------- Order status history ---------- */
function record_history($order_id, $status_from, $status_to, $changed_by)
{
    global $pdo;
    $stmt = $pdo->prepare('INSERT INTO order_status_history (order_id, status_from, status_to, changed_by) VALUES (?, ?, ?, ?)');
    $stmt->execute([$order_id, $status_from, $status_to, $changed_by]);
}

/* ---------- Providers ---------- */
function get_provider_for_user($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM providers WHERE provider_id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    return $stmt->fetch() ?: null;
}

function provider_rating($provider_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT AVG(rating) avg_r, COUNT(*) cnt FROM reviews WHERE provider_id = ?');
    $stmt->execute([$provider_id]);
    $row = $stmt->fetch();
    return ['avg' => $row['avg_r'] ? round((float)$row['avg_r'], 1) : 0.0, 'count' => (int)$row['cnt']];
}

/* ---------- Avatars & uploads ---------- */
function initials_avatar_src($name, $color = '0077b6')
{
    $name = trim((string)$name);
    $letter = strtoupper($name !== '' ? mb_substr($name, 0, 1) : 'U');
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="%23' . $color . '"/><text x="50" y="65" text-anchor="middle" fill="%23fff" font-size="40" font-weight="bold" font-family="Arial">' . $letter . '</text></svg>';
    return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
}

/** Profile/business picture URL — falls back to the initials avatar when the file is missing. */
function avatar_src($pic, $name)
{
    global $BASE;
    $base = isset($BASE) ? $BASE : '../';
    if ($pic) {
        $file = UPLOAD_DIR . DIRECTORY_SEPARATOR . basename($pic);
        if (is_file($file)) {
            return $base . 'assets/images/uploads/' . rawurlencode(basename($pic));
        }
    }
    return initials_avatar_src($name);
}
/**
 * Build an absolute (full) URL for the current host + project root from a
 * project-relative path like 'php/customer/track.php?token=abc'.
 * This is needed for QR codes / share links, because a phone scanning a QR
 * has no context for relative paths like ../../php/... (they would 404).
 */
function absolute_url($rel)
{
    global $BASE;
    $up = count(explode('../', (string)$BASE)) - 1;
    $scheme = (($_SERVER['HTTPS'] ?? 'off') !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'] ?? '/' . trim((string)$rel, '/');
    $scriptDir = dirname($script);
    $parts = array_filter(explode('/', trim($scriptDir, '/')), fn($s) => $s !== '');
    if ($up > 0) {
        $keep = max(0, count($parts) - $up);
        $parts = $keep > 0 ? array_slice($parts, 0, $keep) : [];
    }
    $root = '/' . implode('/', $parts);
    $root = str_replace(' ', '%20', $root);
    $root = ($root === '/') ? '' : $root;
    return $scheme . '://' . $host . $root . '/' . trim((string)$rel, '/');
}

/* Safe relative asset base for uploaded files (pages define $BASE). */
function asset_base()
{
    global $BASE;
    return isset($BASE) ? $BASE : '../';
}

function avatar_img($pic, $name, $size = 100)
{
    $src = avatar_src($pic, $name);
    return '<img src="' . $src . '" class="rounded-circle" width="' . (int)$size . '" height="' . (int)$size . '" style="object-fit: cover;" alt="' . e($name) . '">';
}

function handle_upload($file, $prefix = 'img')
{
    $GLOBALS['upload_error'] = null;
    if (!$file || empty($file['tmp_name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        $GLOBALS['upload_error'] = 'Only JPG, PNG, GIF or WEBP images are allowed.';
        return null;
    }
    if ($file['size'] > 4 * 1024 * 1024) {
        $GLOBALS['upload_error'] = 'Image is too large (max 4 MB).';
        return null;
    }
    if (!is_dir(UPLOAD_DIR)) {
        @mkdir(UPLOAD_DIR, 0777, true);
    }
    $name = $prefix . '_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target = UPLOAD_DIR . DIRECTORY_SEPARATOR . $name;
    if (move_uploaded_file($file['tmp_name'], $target)) {
        clearstatcache(true, $target);
        if (is_file($target)) {
            return $name;
        }
        $GLOBALS['upload_error'] = 'Uploaded file could not be verified on disk.';
        return null;
    }
    $GLOBALS['upload_error'] = 'Could not save the uploaded image. Check the assets/images/uploads folder is writable.';
    return null;
}

/* ---------- Provider pricing ---------- */
function provider_pricing_grouped($provider_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM provider_pricing WHERE provider_id = ? ORDER BY pricing_id ASC');
    $stmt->execute([$provider_id]);
    $grouped = [];
    foreach ($stmt->fetchAll() as $row) {
        $grouped[$row['service_name']][] = $row;
    }
    return $grouped;
}

/* ---------- Admin helper: unread support messages ---------- */
function get_admin_unread_support()
{
    global $pdo;
    try {
        return (int)$pdo->query('SELECT COUNT(*) FROM support_messages WHERE is_read = 0')->fetchColumn();
    } catch (PDOException $e) {

 


        return 0;
    }
}

/* ---------- Service icons ---------- */
function service_icon($service_name)
{
    $map = [
        'wash'    => 'fa-soap',
        'dry'     => 'fa-user-tie',
        'press'   => 'fa-iron',
        'iron'    => 'fa-iron',
        'stain'   => 'fa-magic',
        'shoe'    => 'fa-shoe-prints',
        'bedding' => 'fa-bed',
    ];
    $key = strtolower((string)$service_name);
    foreach ($map as $needle => $icon) {
        if (strpos($key, $needle) !== false) {
            return $icon;
        }
    }
    return 'fa-tshirt';
}

/* ============================================================
 *  FEATURE ENGINE HELPERS (loyalty, wallet, referrals, streaks,
 *  QR tracking, disputes, promotions, verification, eco, audit)
 * ============================================================ */

/** Is an optional feature switched on in the admin Feature Flags? */
function feature_enabled($key)
{
    global $pdo;
    static $cache = [];
    if (!array_key_exists($key, $cache)) {
        try {
            $stmt = $pdo->prepare('SELECT enabled FROM feature_flags WHERE flag_key = ? LIMIT 1');
            $stmt->execute([$key]);
            $row = $stmt->fetch();
            $cache[$key] = $row ? (bool)$row['enabled'] : true;
        } catch (PDOException $e) {
            $cache[$key] = true;
        }
    }
    return $cache[$key];
}

/** Give every user a unique referral code on first use. */
function ensure_referral_code($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT referral_code FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    $code = $stmt->fetchColumn();
    if ($code) return $code;
    $code = 'LX' . strtoupper(bin2hex(random_bytes(3)));
    $pdo->prepare('UPDATE users SET referral_code = ? WHERE user_id = ? AND (referral_code IS NULL OR referral_code = "")')
        ->execute([$code, $user_id]);
    return $code;
}

/* ---------- Laundry wallet ---------- */
function wallet_balance($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT wallet_balance FROM users WHERE user_id = ?');
    $stmt->execute([$user_id]);
    return (float)$stmt->fetchColumn();
}

function wallet_tx($user_id, $amount, $type, $reason, $order_id = null)
{
    global $pdo;
    $amount = (float)$amount;
    if ($amount <= 0) return;
    $pdo->prepare('INSERT INTO wallet_transactions (user_id, amount, type, reason, order_id) VALUES (?, ?, ?, ?, ?)')
        ->execute([$user_id, $amount, $type, $reason, $order_id]);
    if ($type === 'credit') {
        $pdo->prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE user_id = ?')->execute([$amount, $user_id]);
    } else {
        $pdo->prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE user_id = ?')->execute([$amount, $user_id]);
    }
}

/* ---------- Loyalty points ---------- */
define('LOYALTY_PER_ORDER', 50);
define('LOYALTY_PER_REVIEW', 20);
define('POINT_VALUE', 100); // 1 point = UGX 100 discount

function award_loyalty($user_id, $points)
{
    global $pdo;
    $pdo->prepare('UPDATE users SET loyalty_points = loyalty_points + ? WHERE user_id = ?')
        ->execute([(int)$points, $user_id]);
}

/* ---------- Laundry streaks ---------- */
function update_streak($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT streak_count, streak_last_date FROM users WHERE user_id = ?');
    $stmt->execute([$user_id]);
    $row = $stmt->fetch();
    $last = $row['streak_last_date'] ?? null;
    $count = (int)($row['streak_count'] ?? 0);
    if ($last && strtotime($last) >= strtotime('-14 days')) {
        $count++;
    } else {
        $count = 1;
    }
    $pdo->prepare('UPDATE users SET streak_count = ?, streak_last_date = CURDATE() WHERE user_id = ?')
        ->execute([$count, $user_id]);
    return $count;
}

/* ---------- Dynamic commission (admin configurable) ---------- */
function calc_commission($amount)
{
    $type  = get_config('commission_type', 'none');
    $value = (float)get_config('commission_value', 0);
    if ($type === 'none' || $value <= 0) return [0.0, 'No commission'];
    $fee = $type === 'percent' ? round($amount * $value / 100, 2) : $value;
    $min = (float)get_config('commission_min', 0);
    $max = (float)get_config('commission_max', 0);
    if ($min > 0) $fee = max($fee, $min);
    if ($max > 0) $fee = min($fee, $max);
    $fee = min($fee, $amount);
    $label = $type === 'percent' ? 'Commission ' . $value . '% of ' . format_ugx($amount) : 'Flat commission';
    return [$fee, $label];
}

/**
 * Run once when an order is marked completed:
 * dynamic commission, loyalty points, laundry streak, referral rewards.
 */
function award_completion_rewards($order_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM orders WHERE order_id = ? AND status = "completed" LIMIT 1');
    $stmt->execute([(int)$order_id]);
    $order = $stmt->fetch();
    if (!$order) return;

    $total = (float)$order['total_price'];

    [$fee, $label] = calc_commission($total);
    $pdo->prepare('UPDATE orders SET platform_deduction = ? WHERE order_id = ?')->execute([$fee, $order_id]);
    if ($fee > 0) {
        $pdo->prepare('INSERT INTO platform_revenue (order_id, provider_id, amount, deduction_rule_applied) VALUES (?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE amount = VALUES(amount), deduction_rule_applied = VALUES(deduction_rule_applied)')
            ->execute([$order_id, (int)$order['provider_id'], $fee, $label]);
    }

    if (feature_enabled('loyalty')) award_loyalty((int)$order['customer_id'], LOYALTY_PER_ORDER);
    if (feature_enabled('streaks')) update_streak((int)$order['customer_id']);

    $stmt = $pdo->prepare('SELECT referred_by, referral_rewarded, full_name FROM users WHERE user_id = ?');
    $stmt->execute([(int)$order['customer_id']]);
    $u = $stmt->fetch();
    if ($u && $u['referred_by'] && !$u['referral_rewarded'] && feature_enabled('referrals')) {
        wallet_tx((int)$u['referred_by'], 10000, 'credit', 'Referral bonus - ' . $u['full_name'] . ' completed a first order');
        wallet_tx((int)$order['customer_id'], 5000, 'credit', 'Welcome referral bonus');
        add_notification((int)$u['referred_by'], 'Referral Reward', 'You earned UGX 10,000 wallet credit because ' . $u['full_name'] . ' completed their first order.', 'php/customer/wallet.php');
        add_notification((int)$order['customer_id'], 'Referral Bonus', 'You received UGX 5,000 wallet credit for joining through a referral.', 'php/customer/wallet.php');
        $pdo->prepare('UPDATE users SET referral_rewarded = 1 WHERE user_id = ?')->execute([(int)$order['customer_id']]);
    }
}

/* ---------- Provider reliability score ---------- */
function provider_reliability($provider_id)
{
    global $pdo;
    $pid = (int)$provider_id;
    $total     = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid")->fetchColumn();
    $completed = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status IN ('delivered','completed')")->fetchColumn();
    $cancelled = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status = 'cancelled'")->fetchColumn();
    $delivered = $completed;
    $complaints = (int)$pdo->query("SELECT COUNT(*) FROM disputes WHERE provider_id = $pid AND status IN ('open','in_review')")->fetchColumn();

    if ($total === 0 && $complaints === 0) return null;

    $completion = $total > 0 ? $completed / $total : 0;
    $onTimeRate = $delivered > 0 ? 1 : 1;
    $complaintRate = $total > 0 ? min(1, $complaints / $total) : 0;
    $cancelRate = $total > 0 ? $cancelled / $total : 0;

    $score = round(($completion * 40) + ($onTimeRate * 30) + ((1 - $complaintRate) * 20) + ((1 - $cancelRate) * 10));
    return [
        'score' => max(0, min(100, $score)),
        'completion' => round($completion * 100),
        'on_time' => 100,
        'cancelled' => $cancelled,
        'complaints' => $complaints,
        'total' => $total,
    ];
}

/** Average delivery days for a provider (created -> delivered). */
function provider_avg_delivery_days($provider_id)
{
    global $pdo;
    $stmt = $pdo->prepare(
        "SELECT AVG(DATEDIFF(h.changed_at, o.created_at))
         FROM orders o JOIN order_status_history h ON h.order_id = o.order_id AND h.status_to = 'delivered'
         WHERE o.provider_id = ? AND o.status IN ('delivered','completed')"
    );
    $stmt->execute([$provider_id]);
    $d = $stmt->fetchColumn();
    return $d === null ? null : round((float)$d, 1);
}

/* ---------- Eco / verification badges ---------- */
function provider_badges($p)
{
    $html = '';
    if (($p['verification_status'] ?? '') === 'verified') {
        $html .= '<span class="badge bg-success me-1"><i class="fas fa-check-circle me-1"></i>Verified</span>';
    }
    if ((int)($p['eco_score'] ?? 0) >= 50) {
        $html .= '<span class="badge bg-success bg-opacity-75 me-1"><i class="fas fa-leaf me-1"></i>Eco ' . (int)$p['eco_score'] . '</span>';
    }
    return $html;
}

/* ---------- Smart provider recommendations ---------- */
function recommend_providers($customer_id, $limit = 3)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT location FROM users WHERE user_id = ?');
    $stmt->execute([$customer_id]);
    $loc = (string)$stmt->fetchColumn();

    $past = $pdo->prepare('SELECT DISTINCT provider_id FROM orders WHERE customer_id = ?');
    $past->execute([$customer_id]);
    $pastIds = array_map('intval', $past->fetchAll(PDO::FETCH_COLUMN));

    $rows = $pdo->query(
        "SELECT p.*, u.status AS account_status,
                COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.provider_id = p.provider_id), 0) AS avg_rating,
                (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = p.provider_id) AS review_count
         FROM providers p JOIN users u ON u.user_id = p.provider_id
         WHERE p.is_approved = 1 AND u.status = 'active'"
    )->fetchAll();

    $out = [];
    foreach ($rows as $p) {
        $rel = provider_reliability((int)$p['provider_id']);
        $relScore = $rel ? $rel['score'] : 60;
        $score = ((float)$p['avg_rating'] * 15) + ($relScore * 0.3) + ((int)$p['eco_score'] * 0.1);
        $reasons = [];
        if ($loc !== '' && stripos((string)$p['business_location'], $loc) !== false) {
            $score += 15;
            $reasons[] = 'Close to your area';
        }
        if (in_array((int)$p['provider_id'], $pastIds, true)) {
            $score += 10;
            $reasons[] = 'You have ordered here before';
        }
        if ((float)$p['avg_rating'] >= 4.5) $reasons[] = 'Highly rated';
        if ((int)$p['eco_score'] >= 50) $reasons[] = 'Eco-friendly practices';
        if (($p['verification_status'] ?? '') === 'verified') $reasons[] = 'Verified business';
        $p['rec_score'] = round(min(100, $score), 1);
        $p['rec_reasons'] = $reasons;
        $out[] = $p;
    }
    usort($out, fn($a, $b) => $b['rec_score'] <=> $a['rec_score']);
    return array_slice($out, 0, $limit);
}

/* ---------- Recurring schedules ---------- */
function generate_due_recurring_orders($customer_id = null)
{
    global $pdo;
    if (!feature_enabled('recurring')) return 0;
    $sql = "SELECT s.* FROM laundry_schedules s WHERE s.active = 1 AND s.next_pickup <= CURDATE()";
    $params = [];
    if ($customer_id) { $sql .= ' AND s.customer_id = ?'; $params[] = $customer_id; }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $due = $stmt->fetchAll();
    $made = 0;
    foreach ($due as $s) {
        $token = bin2hex(random_bytes(16));
        $delivery = date('Y-m-d', strtotime((string)$s['next_pickup'] . ' +2 days'));
        $stmt2 = $pdo->prepare(
            'INSERT INTO orders (unique_order_token, customer_id, provider_id, status, pickup_date, delivery_date,
                pickup_address, special_instructions, payment_method, payment_status, subtotal, platform_deduction, total_price)
             SELECT ?, s.customer_id, s.provider_id, "pending", s.next_pickup, ?, COALESCE(NULLIF(u.location, ""), "Kampala"),
                CONCAT("Recurring laundry schedule (", s.frequency, ")"), "cash_on_pickup", "pending", s.quantity * s.price, 0, s.quantity * s.price
             FROM laundry_schedules s JOIN users u ON u.user_id = s.customer_id WHERE s.schedule_id = ?'
        );
        $stmt2->execute([$token, $delivery, (int)$s['schedule_id']]);
        $orderId = (int)$pdo->lastInsertId();
        $pdo->prepare('INSERT INTO order_items (order_id, service_name, clothing_type, quantity, price_per_item, subtotal) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$orderId, $s['service_name'], $s['clothing_type'], (int)$s['quantity'], (float)$s['price'], (int)$s['quantity'] * (float)$s['price']]);
        record_history($orderId, null, 'pending', (int)$s['customer_id']);
        add_notification((int)$s['customer_id'], 'Recurring Order Created', 'Your ' . $s['frequency'] . ' laundry order ' . order_code($orderId) . ' was created automatically.', 'php/customer/order_details.php?id=' . $orderId);
        add_notification((int)$s['provider_id'], 'New Order Received', 'A recurring laundry order ' . order_code($orderId) . ' was generated.', 'php/provider/order_details.php?id=' . $orderId);

        $interval = $s['frequency'] === 'weekly' ? '7 DAY' : ($s['frequency'] === 'biweekly' ? '14 DAY' : '1 MONTH');
        $pdo->prepare('UPDATE laundry_schedules SET next_pickup = DATE_ADD(next_pickup, INTERVAL ' . $interval . '), last_generated = CURDATE() WHERE schedule_id = ?')
            ->execute([(int)$s['schedule_id']]);
        $made++;
    }
    return $made;
}

/* ---------- Admin audit log ---------- */
function audit_log($action, $details = '')
{
    global $pdo;
    $id = isset($_SESSION['admin_user_id']) ? (int)$_SESSION['admin_user_id'] : null;
    $pdo->prepare('INSERT INTO audit_log (admin_id, action, details) VALUES (?, ?, ?)')
        ->execute([$id, $action, mb_substr((string)$details, 0, 490)]);
}

/* ---------- Promotions ---------- */
function validate_promo($code, $subtotal)
{
    global $pdo;
    $code = strtoupper(trim($code));
    if ($code === '') return [false, 'Enter a promo code.', 0, null];
    $stmt = $pdo->prepare('SELECT * FROM promotions WHERE UPPER(code) = ? LIMIT 1');
    $stmt->execute([$code]);
    $promo = $stmt->fetch();
    if (!$promo) return [false, 'Promo code not found.', 0, null];
    if (!$promo['active']) return [false, 'This promo code is no longer active.', 0, null];
    if ($promo['expires_at'] && strtotime($promo['expires_at']) < strtotime(date('Y-m-d'))) return [false, 'This promo code has expired.', 0, null];
    if ($promo['used_count'] >= $promo['max_uses']) return [false, 'This promo code has reached its usage limit.', 0, null];
    if ($subtotal < (float)$promo['min_order']) return [false, 'Minimum order for this code is ' . format_ugx($promo['min_order']) . '.', 0, null];
    $discount = $promo['type'] === 'percent' ? round($subtotal * (float)$promo['value'] / 100, 2) : (float)$promo['value'];
    $discount = min($discount, $subtotal);
    return [true, 'Promo applied: ' . $promo['code'], $discount, $promo];
}

/* ---------- Smart Laundry Assistant parser ---------- */
function parse_laundry_text($text)
{
    $text = strtolower($text);
    $clothes = [
        'shirts' => 'Shirt', 'shirt' => 'Shirt',
        'trousers' => 'Trouser', 'trouser' => 'Trouser', 'pants' => 'Trouser',
        'dresses' => 'Dress', 'dress' => 'Dress',
        'suits' => 'Coat/Suit', 'suit' => 'Coat/Suit', 'coats' => 'Coat/Suit', 'coat' => 'Coat/Suit',
        'jackets' => 'Jacket/Sweater', 'jacket' => 'Jacket/Sweater', 'sweaters' => 'Jacket/Sweater', 'sweater' => 'Jacket/Sweater',
        'blankets' => 'Blanket', 'blanket' => 'Blanket',
        'carpets' => 'Carpet', 'carpet' => 'Carpet', 'rugs' => 'Carpet', 'rug' => 'Carpet',
        'curtains' => 'Curtain', 'curtain' => 'Curtain',
        'socks' => 'Sock', 'sock' => 'Sock',
        'towels' => 'Towel', 'towel' => 'Towel',
    ];
    $services = [
        'dry clean' => 'Dry Cleaning', 'dry cleaning' => 'Dry Cleaning', 'dryclean' => 'Dry Cleaning',
        'press' => 'Pressing Only', 'iron' => 'Pressing Only', 'ironing' => 'Pressing Only',
        'stain' => 'Stain Removal',
        'shoe' => 'Shoe Cleaning', 'shoes' => 'Shoe Cleaning', 'sneakers' => 'Shoe Cleaning',
        'bedding' => 'Bedding & Curtains', 'beddings' => 'Bedding & Curtains',
        'wash' => 'Wash & Fold', 'laundry' => 'Wash & Fold', 'fold' => 'Wash & Fold',
    ];
    $items = [];
    foreach ($clothes as $word => $cloth) {
        if (preg_match('/\b' . preg_quote($word, '/') . 's?\b/', $text)) {
            $qty = 1;
            if (preg_match('/(\d+)\s+' . preg_quote($word, '/') . 's?\b/', $text, $m)) $qty = (int)$m[1];
            $service = 'Wash & Fold';
            foreach ($services as $kw => $svc) {
                if (strpos($text, $kw) !== false) { $service = $svc; break; }
            }
            if ($cloth === 'Blanket' || $cloth === 'Carpet' || $cloth === 'Curtain') $service = 'Bedding & Curtains';
            if ($cloth === 'Sock') $service = 'Wash & Fold';
            $items[$service . '|' . $cloth] = ['service' => $service, 'clothing' => $cloth, 'qty' => max(1, $qty)];
        }
    }
    return $items;
}

/** Average market price for a service + clothing type across all providers. */
function estimate_price($service, $clothing)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT AVG(price) FROM provider_pricing WHERE service_name = ? AND clothing_type = ?');
    $stmt->execute([$service, $clothing]);
    $avg = $stmt->fetchColumn();
    return $avg === null ? null : (float)$avg;
}

/* ---------- Provider verification gate ---------- */
/** Returns true when a provider has an approved/verified business profile. */
function lex_provider_is_verified($provider_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT verification_status FROM providers WHERE provider_id = ? LIMIT 1');
    $stmt->execute([$provider_id]);
    $row = $stmt->fetch();
    return $row ? ((string)$row['verification_status'] === 'verified') : false;
}

/* ---------- Audit log ---------- */
/** Records an admin action into audit_log (matches the audit_log table schema). */
function lex_log_audit($action, $details = '')
{
    global $pdo;
    $adminId = isset($_SESSION['admin_user_id']) ? (int)$_SESSION['admin_user_id'] : null;
    if (!$adminId && isset($_SESSION['user_id']) && is_admin()) $adminId = (int)$_SESSION['user_id'];
    $stmt = $pdo->prepare('INSERT INTO audit_log (admin_id, action, details) VALUES (?, ?, ?)');
    $stmt->execute([$adminId, trim($action), trim($details)]);
}

/* ---------- Feature flags ---------- */
function lex_feature_enabled($key, $default = false)
{
    $v = get_config('feature_' . $key, null);
    if ($v === null) return $default;
    return in_array(strtolower($v), ['1', 'true', 'on', 'enabled'], true);
}

/* ---------- Referral helpers ---------- */
function lex_referral_code($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT referral_code FROM users WHERE user_id = ?');
    $stmt->execute([$user_id]);
    $code = $stmt->fetchColumn();
    if ($code) return $code;
    $code = strtoupper(substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZ23456789'), 0, 8));
    $pdo->prepare('UPDATE users SET referral_code = ? WHERE user_id = ?')->execute([$code, $user_id]);
    return $code;
}

function lex_credit_referral($referred_user_id)
{
    global $pdo;
    $refCode = $_SESSION['referral_code_used'] ?? null;
    if (!$refCode) return false;
    $stmt = $pdo->prepare('SELECT user_id, referral_code FROM users WHERE referral_code = ? AND user_id != ? LIMIT 1');
    $stmt->execute([$refCode, (int)$referred_user_id]);
    $ref = $stmt->fetch();
    if (!$ref) return false;
    $wallet = lex_wallet_balance($ref['user_id']);
    $wallet += 500; // referral bonus UGX 500
    lex_set_wallet_balance($ref['user_id'], $wallet);
    lex_add_wallet_tx($ref['user_id'], 500, 'referral_bonus', "Referral reward — user {$referred_user_id} registered.");
    return true;
}

/* ---------- Wallet helpers ---------- */
function lex_wallet_balance($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT wallet_balance FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    $row = $stmt->fetch();
    return $row ? (float)$row['wallet_balance'] : 0.0;
}

function lex_set_wallet_balance($user_id, $amount)
{
    global $pdo;
    $pdo->prepare('UPDATE users SET wallet_balance = ? WHERE user_id = ?')->execute([(float)$amount, $user_id]);
}

function lex_add_wallet_tx($user_id, $amount, $type, $note = '')
{
    global $pdo;
    /* wallet_transactions.type is ENUM('credit','debit') — keep the semantic
       label (order_payment, wallet_topup, referral_bonus, ...) in `reason`. */
    $amount = (float)$amount;
    $type   = (string)$type;
    $dir    = ($type === 'debit' || $amount < 0) ? 'debit' : 'credit';
    $reason = trim($note !== '' ? "[$type] " . trim($note) : $type);
    if ($reason === '') $reason = ucfirst($dir);
    if (mb_strlen($reason) > 150) $reason = mb_substr($reason, 0, 150);
    $pdo->prepare('INSERT INTO wallet_transactions (user_id, amount, type, reason) VALUES (?, ?, ?, ?)')
        ->execute([(int)$user_id, abs($amount), $dir, $reason]);
}

/* ---------- Streak / loyalty helpers ---------- */
function lex_award_loyalty($user_id, $points, $reason)
{
    global $pdo;
    $pdo->prepare('UPDATE users SET loyalty_points = loyalty_points + ? WHERE user_id = ?')
        ->execute([(int)$points, $user_id]);
    $stmt = $pdo->prepare('SELECT loyalty_points FROM users WHERE user_id = ?');
    $stmt->execute([$user_id]);
    return (int)$stmt->fetchColumn();
}

function lex_current_streak($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE customer_id = ?
                           AND status IN ("delivered","completed")
                           AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)');
    $stmt->execute([$user_id]);
    $days = (int)$stmt->fetchColumn();
    return min(7, $days); // cap at 7-day streak badge
}

/* ---------- Provider reliability score ---------- */
function lex_provider_reliability_score($provider_id)
{
    global $pdo;
    $stmt = $pdo->prepare('SELECT verification_status, COALESCE(AVG(rating),0) avg
                           FROM providers p LEFT JOIN reviews r ON r.provider_id = p.provider_id
                           WHERE p.provider_id = ? GROUP BY p.provider_id');
    $stmt->execute([$provider_id]);
    $row = $stmt->fetch();
    $onTime   = (float)$pdo->query('SELECT IFNULL(AVG(CASE WHEN status IN ("delivered","completed") THEN 1 ELSE 0 END),0) FROM orders WHERE provider_id = '.$provider_id)->fetchColumn();
    $cancelled = (float)$pdo->query('SELECT COUNT(*) FROM orders WHERE provider_id = '.$provider_id.' AND status = "cancelled"')->fetchColumn();
    $total     = max(1, (float)$pdo->query('SELECT COUNT(*) FROM orders WHERE provider_id = '.$provider_id)->fetchColumn());
    $score = round(($onTime * 70) + (floatval($row['avg'] ?? 0) * 20) + (max(0, 1 - $cancelled / $total) * 10));
    return min(100, max(0, $score));
}

/* ---------- Audit log alias (disputes page calls log_audit) ---------- */
function log_audit($action, $details = '')
{
    audit_log($action, $details);
}

/* ---------- Provider station location (GPS) columns ----------
   Idempotent auto-migration so the provider map/GPS feature works on any
   database (fresh import or existing). Adds latitude / longitude /
   location_updated_at to the providers table when they are missing. */
function ensure_provider_location_columns()
{
    global $pdo;
    try {
        $have = (int)$pdo->query(
            "SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = 'providers'
               AND column_name IN ('latitude','longitude','location_updated_at')"
        )->fetchColumn();
        if ($have < 3) {
            $pdo->prepare(
                "ALTER TABLE providers ADD COLUMN latitude DECIMAL(9,6) NULL DEFAULT NULL,
                                           ADD COLUMN longitude DECIMAL(9,6) NULL DEFAULT NULL,
                                           ADD COLUMN location_updated_at TIMESTAMP NULL DEFAULT NULL"
            )->execute();
        }
    } catch (Exception $e) {
        /* schema already fine, or MySQL unavailable — never break a page for this */
    }
}

/* ---------- Payment receipts + dispute messages (auto-upgrade tables) ---------- */
function ensure_demo_upgrade_tables()
{
    global $pdo;
    try {
        $pdo->query("CREATE TABLE IF NOT EXISTS receipts (
                receipt_id      INT AUTO_INCREMENT PRIMARY KEY,
                receipt_no      VARCHAR(30) NOT NULL UNIQUE,
                order_id        INT NOT NULL UNIQUE,
                customer_id     INT NOT NULL,
                provider_id     INT NOT NULL,
                amount_paid     DECIMAL(12,2) NOT NULL DEFAULT 0,
                payment_method  VARCHAR(40)  NOT NULL DEFAULT '',
                payment_status  VARCHAR(20)  NOT NULL DEFAULT 'paid',
                mobile_network  VARCHAR(20)  NULL DEFAULT NULL,
                mobile_number   VARCHAR(30)  NULL DEFAULT NULL,
                paid_at         DATETIME     NULL DEFAULT NULL,
                created_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_rct_customer (customer_id),
                INDEX idx_rct_provider (provider_id)
            ) ENGINE=InnoDB");
            $pdo->query("CREATE TABLE IF NOT EXISTS dispute_messages (
                msg_id         INT AUTO_INCREMENT PRIMARY KEY,
                dispute_id     INT NOT NULL,
                sender_type    ENUM('customer','provider','admin') NOT NULL DEFAULT 'customer',
                sender_user_id INT NULL DEFAULT NULL,
                message        TEXT NOT NULL,
                created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_dm_dispute (dispute_id)
            ) ENGINE=InnoDB");
        } catch (Exception $e) { /* schema already present or MySQL unavailable */ }
}

/** Lazy receipt generation — creates the receipt once the payment is paid/confirmed. */
function ensure_order_receipt($orderId)
{
    global $pdo;
    ensure_demo_upgrade_tables();
    $orderId = (int)$orderId;
    if ($orderId <= 0) return null;

    $stmt = $pdo->prepare('SELECT * FROM receipts WHERE order_id = ? LIMIT 1');
    $stmt->execute([$orderId]);
    $existing = $stmt->fetch();
    if ($existing) return $existing;

    $stmt = $pdo->prepare(
        'SELECT o.customer_id, o.provider_id, o.total_price, o.payment_method,
                o.payment_status, o.mobile_network, o.mobile_number,
                o.payment_confirmed_at, o.created_at
         FROM orders o WHERE o.order_id = ? LIMIT 1'
    );
    $stmt->execute([$orderId]);
    $o = $stmt->fetch();
    if (!$o || !in_array($o['payment_status'], ['paid', 'confirmed'], true)) return null;

    $eno = 'RCT-' . $orderId . '-' . strtoupper(bin2hex(random_bytes(3)));
    $paidAt = $o['payment_confirmed_at'] ?: $o['created_at'];
    $pdo->prepare(
        'INSERT INTO receipts (receipt_no, order_id, customer_id, provider_id, amount_paid, payment_method, payment_status, mobile_network, mobile_number, paid_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([$eno, $orderId, $o['customer_id'], $o['provider_id'], (float)$o['total_price'], $o['payment_method'], $o['payment_status'], $o['mobile_network'], $o['mobile_number'], $paidAt]);

    $stmt = $pdo->prepare('SELECT * FROM receipts WHERE order_id = ? LIMIT 1');
    $stmt->execute([$orderId]);
    return $stmt->fetch();
}

/* ---------- Dispute messaging (customer <-> provider <-> admin) ---------- */
function add_dispute_message($disputeId, $senderType, $senderUserId, $message)
{
    global $pdo;
    ensure_demo_upgrade_tables();
    $message = trim((string)$message);
    if ((int)$disputeId <= 0 || $message === '') return false;
    $pdo->prepare('INSERT INTO dispute_messages (dispute_id, sender_type, sender_user_id, message) VALUES (?, ?, ?, ?)')
        ->execute([(int)$disputeId, $senderType, $senderUserId ? (int)$senderUserId : null, mb_substr($message, 0, 2000)]);
    return true;
}

function dispute_thread($disputeId)
{
    global $pdo;
    ensure_demo_upgrade_tables();
    $stmt = $pdo->prepare(
        'SELECT dm.*, u.full_name, u.user_type FROM dispute_messages dm
         LEFT JOIN users u ON u.user_id = dm.sender_user_id
         WHERE dm.dispute_id = ? ORDER BY dm.created_at ASC, dm.msg_id ASC'
    );
    $stmt->execute([(int)$disputeId]);
    return $stmt->fetchAll();
}

/* Renders a dispute thread as HTML (used by customer / provider / admin pages). */
function dispute_thread_html($messages)
{
    $out = '<ul class="list-group list-group-flush small">';
    if (!$messages) {
        $out .= '<li class="list-group-item text-muted">No messages yet.</li>';
    }
    foreach ($messages as $m) {
        $who = $m['sender_type'] === 'admin' ? 'Admin' : ($m['full_name'] ?: ucfirst($m['sender_type']));
        $badge = ['customer' => 'bg-primary', 'provider' => 'bg-success', 'admin' => 'bg-danger'][$m['sender_type']] ?? 'bg-secondary';
        $out .= '<li class="list-group-item d-flex justify-content-between align-items-start">'
              . '<span><span class="badge ' . $badge . '">' . e($who) . '</span> <span class="text-muted d-block mt-1">' . e($m['message']) . '</span></span>'
              . '<small class="text-muted ms-2 text-nowrap">' . date('d M, h:i A', strtotime($m['created_at'])) . '</small>'
              . '</li>';
    }
    return $out . '</ul>';
}


/* ---------- Live order tracking (courier GPS pings) ----------
   Idempotent auto-migration: creates the order_tracking table on any
   database (fresh import or existing) the first time the tracking
   feature is used. Mirrors ensure_provider_location_columns() above. */
function ensure_order_tracking_table()
{
    global $pdo;
    try {
        $pdo->query("CREATE TABLE IF NOT EXISTS order_tracking (
                tracking_id  INT AUTO_INCREMENT PRIMARY KEY,
                order_id     INT NOT NULL,
                latitude     DECIMAL(9,6) NOT NULL,
                longitude    DECIMAL(9,6) NOT NULL,
                accuracy_m   INT NULL DEFAULT NULL,
                speed_kmh    DECIMAL(6,2) NULL DEFAULT NULL,
                phase        VARCHAR(20) NOT NULL DEFAULT 'delivery',
                shared_by    INT NULL DEFAULT NULL,
                recorded_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_tracking_order (order_id, recorded_at),
                CONSTRAINT fk_tracking_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
            ) ENGINE=InnoDB");
    } catch (Exception $e) {
        /* table already exists or MySQL unavailable — never break a page */
    }
}

/* Record one GPS ping for an order. Returns true when stored. */
function record_order_location($orderId, $lat, $lng, $accuracyM = null, $speedKmh = null, $phase = 'delivery', $sharedBy = null)
{
    global $pdo;
    ensure_order_tracking_table();
    $orderId = (int)$orderId;
    $lat = (float)$lat;
    $lng = (float)$lng;
    if ($orderId <= 0 || !isFinite($lat) || !isFinite($lng)) return false;
    if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) return false;
    $phase = in_array($phase, ['pickup', 'delivery'], true) ? $phase : 'delivery';
    $pdo->prepare(
        'INSERT INTO order_tracking (order_id, latitude, longitude, accuracy_m, speed_kmh, phase, shared_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $orderId, $lat, $lng,
        $accuracyM !== null ? (int)$accuracyM : null,
        $speedKmh !== null ? round((float)$speedKmh, 2) : null,
        $phase,
        $sharedBy !== null ? (int)$sharedBy : null,
    ]);
    /* Housekeeping: keep only the last 7 days of pings per order. */
    $pdo->prepare('DELETE FROM order_tracking WHERE order_id = ? AND recorded_at < (NOW() - INTERVAL 7 DAY)')
        ->execute([$orderId]);
    return true;
}

/* Latest GPS ping for an order (null when none or stale). */
function latest_order_location($orderId, $maxAgeSeconds = 900)
{
    global $pdo;
    ensure_order_tracking_table();
    $stmt = $pdo->prepare(
        'SELECT latitude, longitude, accuracy_m, speed_kmh, phase, recorded_at,
                TIMESTAMPDIFF(SECOND, recorded_at, NOW()) AS age_seconds
         FROM order_tracking WHERE order_id = ?
         ORDER BY recorded_at DESC, tracking_id DESC LIMIT 1'
    );
    $stmt->execute([(int)$orderId]);
    $row = $stmt->fetch();
    if (!$row) return null;
    if ((int)$row['age_seconds'] > (int)$maxAgeSeconds) return null; /* stale — treat as no live position */
    return $row;
}

/* Recent trail (oldest -> newest) for drawing the courier route. */
function order_location_trail($orderId, $limit = 120)
{
    global $pdo;
    ensure_order_tracking_table();
    $stmt = $pdo->prepare(
        'SELECT latitude, longitude, recorded_at FROM order_tracking
         WHERE order_id = ? ORDER BY recorded_at DESC, tracking_id DESC LIMIT ' . (int)$limit
    );
    $stmt->execute([(int)$orderId]);
    $rows = array_reverse($stmt->fetchAll());
    $trail = [];
    foreach ($rows as $r) {
        $trail[] = ['lat' => (float)$r['latitude'], 'lng' => (float)$r['longitude'], 'at' => $r['recorded_at']];
    }
    return $trail;
}

/* ---------- Uganda location dictionary (shared by maps + tracking) ----------
   Covers the seeded areas + common Kampala divisions + major towns.
   Extend freely; providers fall back to their raw text location. */
function ug_locations()
{
    return [
        'kampala'          => [0.3136, 32.5811],
        'central kampala'  => [0.3136, 32.5811],
        'kawempe'          => [0.3850, 32.5850],
        'bwaise'           => [0.3550, 32.5800],
        'ntinda'           => [0.3300, 32.6100],
        'kisaasi'          => [0.3600, 32.6000],
        'kansanga'         => [0.3400, 32.5950],
        'wandegeya'        => [0.3250, 32.5750],
        'naguru'           => [0.3300, 32.6150],
        'kireka'           => [0.3100, 32.6200],
        'mukono'           => [0.3660, 32.6970],
        'wakiso'           => [0.4047, 32.5518],
        'makindye'         => [0.2930, 32.5650],
        'nakasero'         => [0.3100, 32.5850],
        'kololo'           => [0.3100, 32.5940],
        'bugolobi'         => [0.3000, 32.6000],
        'muyenga'          => [0.2930, 32.6180],
        'najeera'          => [0.3800, 32.6300],
        'kitintale'        => [0.3000, 32.6300],
        'kireka hills'     => [0.3050, 32.6250],
        'kyambogo'         => [0.3300, 32.6050],
        'buziga'           => [0.3600, 32.6200],
        'kikoni'           => [0.3400, 32.6100],
        'seeta'            => [0.3200, 32.6400],
        'nsangi'           => [0.3100, 32.6300],
        'njeru'            => [0.4000, 32.6500],
        'entebbe'          => [0.0582, 32.4710],
        'jinja'            => [0.4397, 33.2033],
        'masaka'           => [-0.2050, 31.5286],
        'mbale'            => [1.0800, 34.1700],
        'gulu'             => [2.7770, 32.2870],
        'mbarara'          => [-0.6070, 30.6540],
        'ira'              => [1.7800, 31.6000],
        'tororo'           => [0.7000, 34.1800],
        'busia'            => [0.6330, 34.0820],
        'fort portal'      => [1.5000, 30.1500],
        'kases'            => [-0.8910, 30.0840],
        'soroti'           => [1.6800, 33.4500],
        'lira'             => [1.8800, 32.5800],
        'hoima'            => [1.4300, 31.3100],
        'mindi'            => [0.2000, 32.7000],
    ];
}

/* Nearest dictionary coordinates for a location string (or null). */
function ug_geo_find($loc)
{
    $q = strtolower(trim((string)$loc));
    if ($q === '') return null;
    foreach (ug_locations() as $name => $ll) {
        if (stripos($q, $name) !== false || stripos($name, $q) !== false) {
            return ['name' => $name, 'lat' => $ll[0], 'lng' => $ll[1]];
        }
    }
    return null; /* not in the dictionary yet */
}

/* Distance (km) via equirectangular approximation (safe, no exotic math). */
function ug_geo_km($lat1, $lng1, $lat2, $lng2)
{
    $R = 6371.0;
    $pi = 3.141592653589793;
    $dLat = ($lat2 - $lat1) * $pi / 180.0;
    $dLng = ($lng2 - $lng1) * $pi / 180.0;
    $a = (($lat1 + $lat2) / 2.0) * $pi / 180.0;
    $x = $dLng * cos($a);
    return sqrt(($dLat * $dLat) + ($x * $x)) * $R;
}


