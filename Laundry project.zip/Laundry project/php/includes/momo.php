<?php
/**
 * MTN MoMo Open API (Uganda) gateway.
 *
 * Two products (each has its own API User UUID + API Key):
 *   - COLLECTION  (RequestToPay) : customers pay the platform
 *        * orders        -> externalId "ORD-<order_id>"
 *        * wallet top-up -> externalId "WALLET-<user_id>-<ts>"
 *        * subscription  -> externalId "SUB-<provider_id>-<ts>"
 *   - DISTRIBUTION (Disbursement/Transfer) : platform pays OUT
 *        * order money to provider -> externalId "Provider_<provider_id>_<order_id>"
 *
 * The MTN JSON contract is shown in php/api/momo_payload_samples.json.
 * Uses the same curl JSON helpers already used elsewhere in the app.
 */

/* ---------- Configuration helpers ---------- */

/** True when the MTN Collection keys are filled in. */
function momo_collection_configured()
{
    return defined('MTN_MOMO_COLLECTION_KEY') && MTN_MOMO_COLLECTION_KEY
        && defined('MTN_MOMO_COLLECTION_API_KEY') && MTN_MOMO_COLLECTION_API_KEY;
}

/** True when the MTN Distribution keys are filled in. */
function momo_distribution_configured()
{
    return defined('MTN_MOMO_DISTRIBUTION_KEY') && MTN_MOMO_DISTRIBUTION_KEY
        && defined('MTN_MOMO_DISTRIBUTION_API_KEY') && MTN_MOMO_DISTRIBUTION_API_KEY;
}

/** True when real MTN calls should be attempted (i.e. not set to simulate). */
function momo_live()
{
    return defined('MTN_MOMO_SIMULATE') && !MTN_MOMO_SIMULATE;
}

/* ---------- Low level helpers ---------- */

/** Normalise a Ugandan phone to plain digits (e.g. "+256 700 000000" -> "256700000000"). */
function momo_clean_phone($phone)
{
    $p = str_replace('+', '', (string)$phone);
    $p = str_replace(' ', '', $p);
    $p = str_replace('-', '', $p);
    if (strpos($p, '0') === 0) {
        $p = '256' . substr($p, 1);            // 0700... -> 256700...
    }
    return $p;
}

/** Record every MTN call into momo_transactions so admins can audit. */
function momo_log($externalId, $direction, $amount, $phone, $status, $raw)
{
    global $pdo;
    try {
        $pdo->prepare(
            'INSERT INTO momo_transactions (external_id, direction, amount, phone, status, raw_response)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$externalId, $direction, (float)$amount, $phone, $status, substr((string)$raw, 0, 500)]);
    } catch (PDOException $e) {
        // table may not exist yet on an old DB — ignore, the app still works
    }
}

/** Get a fresh OAuth2 access token for a product (collection | distribution). */
function momo_token($kind)
{
    $key  = $kind === 'distribution' ? MTN_MOMO_DISTRIBUTION_KEY  : MTN_MOMO_COLLECTION_KEY;
    $pass = $kind === 'distribution' ? MTN_MOMO_DISTRIBUTION_API_KEY : MTN_MOMO_COLLECTION_API_KEY;
    if (empty($key) || empty($pass)) return null;

    static $cache = [];
    if (!empty($cache[$kind])) return $cache[$kind];

    $url = MTN_MOMO_BASE_URL . '/' . $kind . '/token/';
    $basic = 'Basic ' . base64_encode($key . ':' . $pass);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: ' . $basic,
        'Content-Type: application/x-www-form-urlencoded',
    ]);
    $raw = @curl_exec($ch);
    @curl_close($ch);

    $res = @json_decode((string)$raw, true);
    if (empty($res['access_token'])) return null;
    $cache[$kind] = $res['access_token'];
    return $res['access_token'];
}

/** Send a JSON POST to MTN with the right auth headers and return [httpCode, decoded]. */
function momo_post($kind, $path, $payload, $headersExtra = [])
{
    $token = momo_token($kind);
    if (!$token) return [0, []];

    $ch = curl_init(MTN_MOMO_BASE_URL . $path);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 40);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    $headers = [
        'Authorization: Bearer ' . $token,
        'X-Target-Environment: ' . MTN_MOMO_ENV,
        'Content-Type: application/json',
        'X-Reference-Id: ' . bin2hex(random_bytes(12)),
    ];
    foreach ($headersExtra as $h) $headers[] = $h;
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $raw = @curl_exec($ch);
    $code = (int)@curl_getinfo($ch, CURLINFO_HTTP_CODE);
    @curl_close($ch);
    $res = @json_decode((string)$raw, true) ?: [];
    return [$code, $res];
}
/**
 * Collection — RequestToPay. Customer pays the platform.
 * Returns [bool ok, string refOrError]. On success $ref is the MTN
 * financialTransactionId that the customer should keep as proof.
 */
function momo_collect($amount, $externalId, $phone, $payerMessage = '', $payeeNote = '')
{
    if (!momo_collection_configured()) return [false, 'not_configured'];

    $partyId = momo_clean_phone($phone);
    $payload = [
        'amount'       => (string)(round((float)$amount * 100) / 100),
        'currency'     => 'UGX',
        'externalId'   => $externalId,
        'payer'        => ['partyIdType' => 'MSISDN', 'partyId' => $partyId],
        'payerMessage' => $payerMessage !== '' ? $payerMessage : 'Payment for ' . $externalId,
        'payeeNote'    => $payeeNote !== '' ? $payeeNote : 'Payment received',
    ];
    [$code, $res] = momo_post('collection', '/collection/v1_0/requesttopay', $payload, [
        'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_COLLECTION_KEY,
        'X-Callback-Url: ' . (defined('MTN_MOMO_CALLBACK_URL') ? MTN_MOMO_CALLBACK_URL : ''),
    ]);

    $status = strtoupper((string)($res['status'] ?? ($code >= 200 && $code < 300 ? 'SUCCESSFUL' : 'FAILED')));
    $ref = $res['financialTransactionId'] ?? $payload['payer']['partyId'];
    momo_log($externalId, 'collection', $amount, $partyId, $status, json_encode($res));

    if ($code >= 200 && $code < 300 && $status === 'SUCCESSFUL') {
        return [true, $ref];
    }
    return [false, $res['statusMessage'] ?? $res['statusCode'] ?? $status];
}

/**
 * Distribution — Disbursement. Platform pays OUT (order money to providers,
 * provider subscription flows). Returns [bool ok, string refOrError].
 */
function momo_disburse($amount, $externalId, $phone, $payerMessage = '', $payeeNote = '')
{
    if (!momo_distribution_configured()) return [false, 'not_configured'];

    $partyId = momo_clean_phone($phone);
    $payload = [
        'amount'       => (string)(round((float)$amount * 100) / 100),
        'currency'     => 'UGX',
        'externalId'   => $externalId,
        'payee'        => ['partyIdType' => 'MSISDN', 'partyId' => $partyId],
        'payerMessage' => $payerMessage !== '' ? $payerMessage : 'LaundryExpress payout',
        'payeeNote'    => $payeeNote !== '' ? $payeeNote : 'Payment received',
    ];
    [$code, $res] = momo_post('distribution', '/disbursement/v1_0/transfer', $payload, [
        'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_DISTRIBUTION_KEY,
    ]);

    $status = strtoupper((string)($res['status'] ?? ($code >= 200 && $code < 300 ? 'SUCCESSFUL' : 'FAILED')));
    $ref = $res['financialTransactionId'] ?? $payload['payee']['partyId'];
    momo_log($externalId, 'distribution', $amount, $partyId, $status, json_encode($res));

    if ($code >= 200 && $code < 300 && $status === 'SUCCESSFUL') {
        return [true, $ref];
    }
    return [false, $res['statusMessage'] ?? $res['statusCode'] ?? $status];
}

/**
 * Provider monthly subscription charge.
 * By default this is a Collection (RequestToPay) — the provider's MTN number
 * is debited the subscription amount (money IN to the platform).
 * If MTN_MOMO_SUBSCRIPTION_USE_DISTRIBUTION is set to true, the same amount is
 * instead routed through the Distribution (transfer) product — matching
 * sandbox setups where subscriptions are provisioned on the Distribution key.
 */
function momo_subscription_charge($amount, $externalId, $phone)
{
    if (defined('MTN_MOMO_SUBSCRIPTION_USE_DISTRIBUTION') && MTN_MOMO_SUBSCRIPTION_USE_DISTRIBUTION) {
        return momo_disburse($amount, $externalId, $phone, 'Provider subscription payment', 'Subscription received');
    }
    return momo_collect($amount, $externalId, $phone, 'Provider subscription payment', 'Subscription received');
}

/**
 * Disburse an order's full total to the provider's mobile money number.
 * Uses the provider's business_phone as the payee MSISDN.
 */
function momo_pay_provider_for_order($orderId, $providerId, $amount)
{
    global $pdo;
    if (!momo_live() || !momo_distribution_configured() || !MTN_PAYOUT_ON_COLLECT) {
        return [false, 'payout_disabled'];   // simulation / payouts disabled
    }

    /* Idempotency: never disburse the same order twice. */
    $extId = 'Provider_' . $providerId . '_' . $orderId;
    try {
        $chk = $pdo->prepare("SELECT tx_id FROM momo_transactions WHERE external_id = ? AND status = 'SUCCESSFUL' LIMIT 1");
        $chk->execute([$extId]);
        if ($chk->fetch()) return [true, 'already_paid'];
    } catch (PDOException $e) {
        // momo_transactions table missing on old DB — treat as not yet paid
    }

    $stmt = $pdo->prepare('SELECT business_phone FROM providers WHERE provider_id = ? LIMIT 1');
    $stmt->execute([$providerId]);
    $phone = $stmt->fetchColumn();
    if (!$phone) return [false, 'no_provider_msisdn'];

    return momo_disburse(
        $amount,
        $extId,
        $phone,
        'LaundryExpress payout for order ORD-' . str_pad((string)$orderId, 5, '0', STR_PAD_LEFT),
        'Order payment received'
    );
}