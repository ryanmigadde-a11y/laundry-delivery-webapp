<?php
/**
 * LaundryExpress Uganda - Authentication routines
 * (register, login, Google OAuth verification)
 */
require_once __DIR__ . '/session.php';

/* ============================================================
 * TWO-FACTOR VERIFICATION (registration + password reset OTP)
 * Uses the verification_codes table. When SMTP/SMS are not yet
 * configured, the code is shown on the verify page (dev mode).
 * ============================================================ */

/**
 * Create a 6-digit code for $email + optional phone, and "send" it.
 * Returns the code (dev copies it into the session for display).
 */
function generate_verification_code($email, $purpose = 'register', $phone = '')
{
    global $pdo;
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $stmt = $pdo->prepare('INSERT INTO verification_codes (email, code, purpose, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))');
    $stmt->execute([$email, $code, $purpose]);

    // Keep a copy so verify.php can show it while SMTP/SMS is not configured.
    $_SESSION['otp_sent'] = ['email' => $email, 'purpose' => $purpose, 'code' => $code, 'phone' => $phone];

    if (!send_otp($email, $phone, $code, $purpose)) {
        // Dev mode only: the verification page will reveal the code on screen.
    }
    return $code;
}

/** Verify a submitted code and mark it used. Returns true on success. */
function verify_code($email, $input, $purpose)
{
    global $pdo;
    $stmt = $pdo->prepare(
        "SELECT * FROM verification_codes
         WHERE email = ? AND code = ? AND purpose = ? AND used = 0 AND expires_at > NOW()
         ORDER BY code_id DESC LIMIT 1"
    );
    $stmt->execute([$email, trim((string)$input), $purpose]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }
    $pdo->prepare('UPDATE verification_codes SET used = 1 WHERE code_id = ?')->execute([(int)$row['code_id']]);
    unset($_SESSION['otp_sent']);
    return true;
}

/**
 * Deliver the code by SMS (Africa's Talking) or email (mail()). 
 * Returns true if handed to a gateway, false otherwise (dev mode).
 */
function send_otp($email, $phone, $code, $purpose)
{
    $msg = 'Your LaundryExpress ' . ($purpose === 'reset' ? 'password reset' : 'registration')
         . ' verification code is: ' . $code . '. It is valid for 15 minutes.';

    // 1) SMS via Africa's Talking (easiest for +256 numbers)
    if (defined('SMS_ENABLED') && SMS_ENABLED
        && defined('AFRICAS_TALKING_API_KEY') && AFRICAS_TALKING_API_KEY && $phone) {
        $data = http_build_query([
            'username' => defined('AFRICAS_TALKING_USERNAME') ? AFRICAS_TALKING_USERNAME : 'sandbox',
            'to'       => $phone,
            'message'  => $msg,
            'from'     => defined('SMS_SENDER_ID') ? SMS_SENDER_ID : 'LaundryExp',
        ]);
        $ch = curl_init('https://api.africastalking.com/version1/messaging');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'apiKey: ' . AFRICAS_TALKING_API_KEY,
            'Content-Type: application/x-www-form-urlencoded',
        ]);
        @curl_exec($ch);
        @curl_close($ch);
        return true;
    }

    // 2) Email via SendGrid HTTP API (uses SENDGRID_API_KEY)
    if (defined('SENDGRID_API_KEY') && SENDGRID_API_KEY) {
        $sg = [
            'personalizations' => [['to' => [['email' => $email, 'name' => '']]]],
            'from' => ['email' => defined('SENDGRID_FROM_EMAIL') ? SENDGRID_FROM_EMAIL : 'laundryexpressuganda@gmail.com', 'name' => 'LaundryExpress Uganda'],
            'subject' => 'LaundryExpress ' . ($purpose === 'reset' ? 'Password Reset Code' : 'Verification Code'),
            'content' => [['type' => 'text/plain', 'value' => $msg]],
        ];
        $ch = curl_init('https://api.sendgrid.com/v3/mail/send');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($sg));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . SENDGRID_API_KEY,
            'Content-Type: application/json',
        ]);
        @curl_exec($ch);
        @curl_close($ch);
        return true;
    }

    // 3) Email via PHP mail()/SMTP
    if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
        $from = defined('SMTP_FROM') ? SMTP_FROM : 'no-reply@laundryexpress.ug';
        $headers = 'MIME-Version: 1.0' . "\r\n"
                 . 'Content-type: text/plain; charset=UTF-8' . "\r\n"
                 . 'From: ' . $from . "\r\n";
        @mail($email, 'LaundryExpress verification code', $msg, $headers);
        return true;
    }

    return false; // dev mode: code will be shown on the verify page
}

/**
 * Lightweight registration validation (no DB insert). 
 * Returns [true, ''] or [false, errorMessage].
 */
function validate_registration($data)
{
    $type = ($data['user_type'] ?? '') === 'provider' ? 'provider' : 'customer';
    $full_name = trim($data['full_name'] ?? '');
    $email     = strtolower(trim($data['email'] ?? ''));
    $phone     = trim($data['phone'] ?? '');
    $location  = trim($data['location'] ?? '');
    $password  = $data['password'] ?? '';
    $confirm   = $data['confirm_password'] ?? '';

    if ($full_name === '' || $email === '' || $phone === '' || $location === '' || $password === '') {
        return [false, 'Please fill in all required fields.'];
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return [false, 'Please enter a valid email address.'];
    }
    if (strlen($password) < 6) {
        return [false, 'Password must be at least 6 characters.'];
    }
    if ($password !== $confirm) {
        return [false, 'Passwords do not match.'];
    }
    if ($type === 'provider' && trim($data['business_name'] ?? '') === '') {
        return [false, 'Business name is required for providers.'];
    }
    $stmt = $GLOBALS['pdo']->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        return [false, 'An account with this email already exists. Try logging in.'];
    }
    return [true, ''];
}

/**
 * Register a new customer or provider. Returns [bool ok, string errorOrId].
 */
function register_user($data, $files = [])
{
    global $pdo;

    $type = ($data['user_type'] ?? '') === 'provider' ? 'provider' : 'customer';
    $full_name = trim($data['full_name'] ?? '');
    $email     = strtolower(trim($data['email'] ?? ''));
    $phone     = trim($data['phone'] ?? '');
    $location  = trim($data['location'] ?? '');
    $password  = $data['password'] ?? '';
    $confirm   = $data['confirm_password'] ?? '';

    if ($full_name === '' || $email === '' || $phone === '' || $location === '' || $password === '') {
        return [false, 'Please fill in all required fields.'];
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return [false, 'Please enter a valid email address.'];
    }
    if (strlen($password) < 6) {
        return [false, 'Password must be at least 6 characters.'];
    }
    if ($password !== $confirm) {
        return [false, 'Passwords do not match.'];
    }
    if ($type === 'provider' && trim($data['business_name'] ?? '') === '') {
        return [false, 'Business name is required for providers.'];
    }

    $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        return [false, 'An account with this email already exists. Try logging in.'];
    }

    $pic = handle_upload($files['profile_pic'] ?? null, 'profile');

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare(
            'INSERT INTO users (email, password_hash, user_type, full_name, phone, location, profile_pic)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$email, password_hash($password, PASSWORD_DEFAULT), $type, $full_name, $phone, $location, $pic]);
        $user_id = (int)$pdo->lastInsertId();

        if ($type === 'provider') {
            $stmt = $pdo->prepare(
                'INSERT INTO providers (provider_id, business_name, business_phone, business_location, business_email, profile_pic)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $user_id,
                trim($data['business_name']),
                trim($data['business_phone'] ?? $phone),
                trim($data['business_location'] ?? $location),
                $email,
                $pic,
            ]);
            seed_default_pricing($user_id);
        }

        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [false, 'Registration failed: ' . $e->getMessage()];
    }

    add_notification($user_id, 'Welcome to LaundryExpress!', 'Thank you for joining. Start by placing your first order.', 'php/customer/dashboard.php');
    return [true, $user_id];
}

/**
 * Give brand-new providers a starter menu they can edit on the business page.
 */
function seed_default_pricing($provider_id)
{
    global $pdo;
    $starter = [
        ['Wash & Fold', 'Shirt', 500],
        ['Wash & Fold', 'Trouser', 700],
        ['Wash & Fold', 'Dress', 800],
        ['Wash & Fold', 'Suit', 1000],
        ['Dry Cleaning', 'Shirt', 800],
        ['Dry Cleaning', 'Suit', 2500],
        ['Pressing Only', 'Shirt', 400],
        ['Pressing Only', 'Trouser', 500],
    ];
    $stmt = $pdo->prepare('INSERT INTO provider_pricing (provider_id, service_name, clothing_type, price) VALUES (?, ?, ?, ?)');
    foreach ($starter as $row) {
        $stmt->execute([$provider_id, $row[0], $row[1], $row[2]]);
    }
}

/**
 * Attempt an email + password login. Returns [bool ok, mixed userOrMessage].
 */
function attempt_login($email, $password)
{
    global $pdo;
    $email = strtolower(trim($email));
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return [false, 'Invalid email or password.'];
    }
    if ($user['status'] === 'suspended') {
        return [false, 'Your account has been suspended. Please contact support.'];
    }

    login_session($user);
    return [true, $user];
}

/**
 * Persist the logged-in user in the session.
 */
function login_session($user)
{
    $_SESSION['user_id'] = (int)$user['user_id'];
    $_SESSION['user_type'] = $user['user_type'];
    $_SESSION['full_name'] = $user['full_name'];
    session_regenerate_id(true);
}

/**
 * Verify a Google Identity Services credential (JWT) using Google's tokeninfo endpoint.
 * Returns the payload array on success, null on failure.
 */
function google_verify_credential($credential)
{
    if (!GOOGLE_CLIENT_ID || !$credential) {
        return null;
    }
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($credential);
    $response = @file_get_contents($url);
    if ($response === false) {
        return null;
    }
    $payload = json_decode($response, true);
    if (!$payload || empty($payload['aud']) || $payload['aud'] !== GOOGLE_CLIENT_ID) {
        return null;
    }
    if (strtoupper($payload['email_verified'] ?? '') !== 'TRUE') {
        return null;
    }
    return $payload;
}

/**
 * Login (or auto-register) a Google user. Returns [bool ok, mixed userOrMessage].
 */
function google_login_or_register($payload, $type = 'customer')
{
    global $pdo;
    $email = strtolower($payload['email']);
    $google_id = $payload['sub'];
    $name = !empty($payload['name']) ? $payload['name'] : $email;

    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? OR google_id = ? LIMIT 1');
    $stmt->execute([$email, $google_id]);
    $user = $stmt->fetch();

    if ($user) {
        if ($user['status'] === 'suspended') {
            return [false, 'Your account has been suspended. Please contact support.'];
        }
        if (!$user['google_id']) {
            $pdo->prepare('UPDATE users SET google_id = ? WHERE user_id = ?')->execute([$google_id, $user['user_id']]);
        }
        login_session($user);
        return [true, $user];
    }

    // Auto-register the Google account (random unusable password)
    $stmt = $pdo->prepare(
        'INSERT INTO users (email, password_hash, google_id, user_type, full_name, phone, location)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $email,
        password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT),
        $google_id,
        $type === 'provider' ? 'provider' : 'customer',
        $name,
        '',
        '',
    ]);
    $user_id = (int)$pdo->lastInsertId();

    if ($type === 'provider') {
        $pdo->prepare('INSERT INTO providers (provider_id, business_name, business_email) VALUES (?, ?, ?)')
            ->execute([$user_id, $name . ' Laundry', $email]);
        seed_default_pricing($user_id);
    }

    $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    add_notification($user_id, 'Welcome to LaundryExpress!', 'Thank you for joining with Google. Complete your profile in settings.', 'php/customer/dashboard.php');
    login_session($user);
    return [true, $user];
}

