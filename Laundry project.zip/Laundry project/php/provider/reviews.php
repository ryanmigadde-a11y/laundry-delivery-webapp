<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$pid = (int)$_SESSION['user_id'];

$rating = provider_rating($pid);

$stmt = $pdo->prepare(
    'SELECT r.*, u.full_name AS customer_name FROM reviews r JOIN users u ON u.user_id = r.customer_id
     WHERE r.provider_id = ? ORDER BY r.created_at DESC'
);
$stmt->execute([$pid]);
$reviews = $stmt->fetchAll();

/* Rating breakdown */
$breakdown = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
foreach ($reviews as $r) {
    $breakdown[(int)$r['rating']] = ($breakdown[(int)$r['rating']] ?? 0) + 1;
}

$active = 'reviews';
$page_title = 'Reviews';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-star me-2"></i>Customer Reviews</h2>

        <!-- Summary -->
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <div class="row align-items-center">
                <div class="col-md-4 text-center">
                    <h1 class="fw-bold mb-0" style="color: #0077b6;"><?php echo $rating['avg']; ?></h1>
                    <div class="mb-1"><?php echo star_icons($rating['avg']); ?></div>
                    <small class="text-muted"><?php echo $rating['count']; ?> review<?php echo $rating['count'] == 1 ? '' : 's'; ?></small>
                </div>
                <div class="col-md-8">
                    <?php for ($i = 5; $i >= 1; $i--):
                        $pct = $rating['count'] > 0 ? round($breakdown[$i] / $rating['count'] * 100) : 0; ?>
                    <div class="d-flex align-items-center mb-1">
                        <small class="me-2" style="width: 40px;"><?php echo $i; ?> star<?php echo $i > 1 ? 's' : ''; ?></small>
                        <div class="progress flex-grow-1" style="height: 8px;">
                            <div class="progress-bar bg-warning" style="width: <?php echo $pct; ?>%;"></div>
                        </div>
                        <small class="ms-2 text-muted" style="width: 30px;"><?php echo $breakdown[$i]; ?></small>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <?php if (!$reviews): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-star fa-3x text-muted mb-3"></i>
                <p class="text-muted mb-0">No reviews yet. Complete orders to receive reviews from customers.</p>
            </div>
        <?php endif; ?>

        <?php foreach ($reviews as $r): ?>
        <div class="card border-0 shadow-sm rounded-4 mb-3">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between flex-wrap gap-2">
                    <div>
                        <h6 class="fw-bold"><?php echo e($r['customer_name']); ?></h6>
                        <div class="mb-2"><?php echo star_icons($r['rating']); ?></div>
                        <p class="mb-0"><?php echo e($r['comment'] ?: 'No comment left.'); ?></p>
                    </div>
                    <small class="text-muted text-end">Order <?php echo order_code($r['order_id']); ?><br><?php echo date('d M Y', strtotime($r['created_at'])); ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
