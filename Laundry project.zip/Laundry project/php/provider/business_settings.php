<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();

/* Auto-migration: providers table must have latitude/longitude columns. */
ensure_provider_location_columns();

/* ---- Save station GPS location (the pin customers see on the map) ---- */
if (isset($_POST['save_station']) && (string)$_POST['save_station'] === '1') {
    $sLat = (float)($_POST['station_lat'] ?? 0);
    $sLng = (float)($_POST['station_lng'] ?? 0);
    if ($sLat >= -5 && $sLat <= 5 && $sLng >= 25 && $sLng <= 36) {
        $pdo->prepare('UPDATE providers SET latitude = ?, longitude = ?, location_updated_at = NOW() WHERE provider_id = ?')
            ->execute([$sLat, $sLng, $user['user_id']]);
        flash('success', 'Station location saved — customers can now find you on the Laundry Stations map.');
    } else {
        flash('danger', 'Those coordinates look outside Uganda. Use "Locate My Station (GPS)" or drop the pin on the map.');
    }
    redirect('business_settings.php');
}

$provider = get_provider_for_user($user['user_id']);

/* ---- Save business info ---- */
if (isset($_POST['save_business'])) {
    $businessName = trim($_POST['business_name'] ?? '');
    $businessPhone = trim($_POST['business_phone'] ?? '');
    $businessLocation = trim($_POST['business_location'] ?? '');
    $businessEmail = trim($_POST['business_email'] ?? '');

    if ($businessName === '') {
        flash('danger', 'Business name is required.');
    } else {
        $pic = handle_upload($_FILES['business_pic'] ?? null, 'business');
        if ($pic) {
            $pdo->prepare('UPDATE providers SET profile_pic = ? WHERE provider_id = ?')->execute([$pic, $user['user_id']]);
        }
        $stmt = $pdo->prepare('UPDATE providers SET business_name = ?, business_phone = ?, business_location = ?, business_email = ? WHERE provider_id = ?');
        $stmt->execute([$businessName, $businessPhone, $businessLocation, $businessEmail, $user['user_id']]);
        /* Keep the customer-facing search location in sync */
        $pdo->prepare('UPDATE users SET location = ? WHERE user_id = ? AND location IS NOT NULL AND location != \'\'')->execute([$businessLocation, $user['user_id']]);

        /* Eco scores + verification request */
        $eco = ['eco_water' => 0, 'eco_packaging' => 0, 'eco_detergent' => 0];
        foreach (array_keys($eco) as $k) $eco[$k] = !empty($_POST[$k]) ? 1 : 0;
        $ecoScore = ($eco['eco_water'] ? 40 : 0) + ($eco['eco_packaging'] ? 30 : 0) + ($eco['eco_detergent'] ? 30 : 0);
        $pdo->prepare('UPDATE providers SET eco_water = ?, eco_packaging = ?, eco_detergent = ?, eco_score = ? WHERE provider_id = ?')
            ->execute([$eco['eco_water'], $eco['eco_packaging'], $eco['eco_detergent'], $ecoScore, $user['user_id']]);

        if (!empty($_POST['request_verification']) && $provider['verification_status'] !== 'verified') {
            $pdo->prepare("UPDATE providers SET verification_status = 'pending', verification_note = ? WHERE provider_id = ?")
                ->execute([trim($_POST['verification_details'] ?? ''), $user['user_id']]);
            add_notification($user['user_id'], 'Verification Requested', 'Your business documents are now under review.', 'php/provider/business_settings.php');
            audit_log('verification_requested', 'Provider ' . $user['user_id'] . ' requested verification');
        }
        flash('success', 'Business information saved successfully.');
    }
    redirect('business_settings.php');
}

/* ---- Save pricing menu (full service x clothing grid) ---- */
if (isset($_POST['save_pricing'])) {
    $pricing = $_POST['pricing'] ?? [];
    $serviceNames = $_POST['service_names'] ?? [];
    $valid = [];
    $clothingTypes = clothing_type_list();
    foreach ($pricing as $si => $rows) {
        $service = trim($serviceNames[$si] ?? '');
        if ($service === '') continue;
        foreach ($rows as $ci => $price) {
            $cloth = $clothingTypes[$ci] ?? '';
            $p = (float)$price;
            if ($cloth === '' || $p <= 0) continue;
            $valid[] = [$service, $cloth, $p];
        }
    }
    try {
        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM provider_pricing WHERE provider_id = ?')->execute([$user['user_id']]);
        if ($valid) {
            $stmt = $pdo->prepare('INSERT INTO provider_pricing (provider_id, service_name, clothing_type, price) VALUES (?, ?, ?, ?)');
            foreach ($valid as $v) {
                $stmt->execute([$user['user_id'], $v[0], $v[1], $v[2]]);
            }
        }
        $pdo->commit();
        flash('success', count($valid) . ' price item(s) saved successfully.');
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', 'Could not save pricing: ' . $e->getMessage());
    }
    redirect('business_settings.php');
}

/* Refresh provider + pricing */
$provider = get_provider_for_user($user['user_id']);
$stmt = $pdo->prepare('SELECT * FROM provider_pricing WHERE provider_id = ? ORDER BY pricing_id ASC');
$stmt->execute([$user['user_id']]);
$pricingRows = $stmt->fetchAll();

$serviceOptions = ['Wash & Fold', 'Dry Cleaning', 'Pressing Only', 'Stain Removal', 'Shoe Cleaning', 'Bedding & Curtains'];
$clothingTypes = clothing_type_list();
$colors = clothing_color_list();

$active = 'business';
$page_title = 'Business Settings';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-store me-2"></i>Business Settings</h2>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-briefcase me-2" style="color: #0077b6;"></i>Business Information</h5>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="text-center mb-4">
                            <div class="position-relative d-inline-block">
                                <img id="bizPicPreview" src="<?php echo avatar_src($provider['profile_pic'], $provider['business_name']); ?>"
                                     class="rounded-circle" width="100" height="100" style="object-fit: cover;" alt="logo">
                                <label class="position-absolute bottom-0 end-0 btn btn-sm btn-primary rounded-circle" style="cursor: pointer;">
                                    <i class="fas fa-camera"></i><input type="file" name="business_pic" class="d-none" accept="image/*" onchange="document.getElementById('bizPicPreview').src = window.URL.createObjectURL(this.files[0])">
                                </label>
                            </div>
                        </div>
                        <div class="mb-3"><label class="form-label">Business Name</label><input type="text" name="business_name" class="form-control" value="<?php echo e($provider['business_name']); ?>" required></div>
                        <div class="mb-3"><label class="form-label">Business Phone</label><input type="tel" name="business_phone" class="form-control" value="<?php echo e($provider['business_phone']); ?>"></div>
                        <div class="mb-3"><label class="form-label">Business Location</label><input type="text" name="business_location" class="form-control" value="<?php echo e($provider['business_location']); ?>" placeholder="e.g. Kampala, Kawempe"></div>
                        <div class="mb-3"><label class="form-label">Business Email</label><input type="email" name="business_email" class="form-control" value="<?php echo e($provider['business_email']); ?>"></div>
                        <div class="mb-3">
                            <label class="form-label fw-bold"><i class="fas fa-leaf me-1 text-success"></i>Green Laundry Score (optional)</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="eco_water" id="ecoWater" <?php echo (int)($provider['eco_water'] ?? 0) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="ecoWater">I conserve water (low-water washing)</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="eco_packaging" id="ecoPack" <?php echo (int)($provider['eco_packaging'] ?? 0) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="ecoPack">Reusable packaging</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="eco_detergent" id="ecoDet" <?php echo (int)($provider['eco_detergent'] ?? 0) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="ecoDet">Eco-friendly / biodegradable detergent</label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold"><i class="fas fa-check-circle me-1 text-primary"></i>Business Verification</label>
                            <?php if (($provider['verification_status'] ?? 'unverified') === 'verified'): ?>
                                <div class="alert alert-success py-2 mb-2"><i class="fas fa-check me-1"></i>Your business is verified.</div>
                            <?php elseif (($provider['verification_status'] ?? 'unverified') === 'pending'): ?>
                                <div class="alert alert-warning py-2 mb-2"><i class="fas fa-clock me-1"></i>Verification pending review.</div>
                            <?php else: ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="request_verification" id="reqVer">
                                    <label class="form-check-label" for="reqVer">Request verification (admin review)</label>
                                </div>
                                <input type="text" name="verification_details" class="form-control mt-2" placeholder="Business documents / TIN / license details (optional)" value="<?php echo e($provider['verification_note'] ?? ''); ?>">
                            <?php endif; ?>
                        </div>
                        <button type="submit" name="save_business" value="1" class="btn btn-primary w-100"><i class="fas fa-save me-2"></i>Save Business Info</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-tags me-2" style="color: #0077b6;"></i>Pricing Menu</h5>
                    <form method="POST" id="pricingForm">
                        <?php
                        /* Pre-fill prices from existing rows -> priceMap[service][clothing] */
                        $priceMap = [];
                        foreach ($pricingRows as $row) {
                            $priceMap[$row['service_name']][$row['clothing_type']] = (float)$row['price'];
                        }
                        ?>
                        <?php foreach ($serviceOptions as $si => $service): ?>
                        <div class="service-price-block mb-4 p-3 border rounded">
                            <h6 class="fw-bold"><i class="fas <?php echo service_icon($service); ?> me-2" style="color:#0077b6;"></i><?php echo e($service); ?></h6>
                            <small class="text-muted d-block mb-2">Leave a price empty to disable that item for this service.</small>
                            <?php foreach ($clothingTypes as $ci => $cloth): ?>
                            <div class="row align-items-center g-1 mb-1">
                                <div class="col-md-5"><label class="small mb-0"><?php echo e($cloth); ?></label></div>
                                <div class="col-md-7">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text">UGX</span>
                                        <input type="number" name="pricing[<?php echo $si; ?>][<?php echo $ci; ?>]" class="form-control"
                                               placeholder="Price per piece" min="0" step="100"
                                               value="<?php echo e($priceMap[$service][$cloth] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <input type="hidden" name="service_names[<?php echo $si; ?>]" value="<?php echo e($service); ?>">
                        </div>
                        <?php endforeach; ?>
                        <button type="submit" name="save_pricing" value="1" class="btn btn-primary w-100"><i class="fas fa-save me-2"></i>Save Pricing Menu</button>
                    </form>
                    <p class="text-muted small mt-3 mb-0"><i class="fas fa-info-circle me-1"></i>Customers see these prices per piece when ordering. Everything is saved to the database.</p>
                </div>
            </div>

        </div>
    <!-- ===== Station Location on Map (customers see this pin in Laundry Stations) ===== -->
        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-map-marked-alt me-2" style="color:#0077b6;"></i>Station Location on Map</h5>
            <p class="small text-muted mb-2">Customers find your business on the <strong>Laundry Stations</strong> map. Tap <strong>Locate My Station (GPS)</strong> to use this browser&rsquo;s GPS, or click anywhere on the map to drop the pin, then <strong>Save Station Position</strong>.</p>
            <div class="row g-3">
                <div class="col-md-7">
                    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet.css">
                    <div id="stationMap" class="border" style="height: 320px; width: 100%; border-radius: 12px;"></div>
                    <script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
                    <script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
                    <div class="d-flex flex-wrap align-items-center gap-2 mt-2">
                        <button type="button" class="btn btn-sm btn-primary" id="stationLocateBtn" onclick="initStationLocator()"><i class="fas fa-location-arrow me-1"></i>Locate My Station (GPS)</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="clearStationPin()"><i class="fas fa-undo-alt me-1"></i>Clear</button>
                        <span class="small text-muted ms-1" id="stationGpsStatus"></span>
                    </div>
                </div>
                <div class="col-md-5">
                    <form method="POST">
                        <input type="hidden" name="save_station" value="1">
                        <input type="hidden" name="station_lat" id="stationLat" value="<?php echo is_numeric($provider['latitude'] ?? null) ? e((string)$provider['latitude']) : ''; ?>">
                        <input type="hidden" name="station_lng" id="stationLng" value="<?php echo is_numeric($provider['longitude'] ?? null) ? e((string)$provider['longitude']) : ''; ?>">
                        <div class="mb-2">
                            <label class="form-label small fw-bold">GPS coordinates</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text">Lat</span>
                                <input type="text" class="form-control" id="stationLatText" value="<?php echo is_numeric($provider['latitude'] ?? null) ? round((float)$provider['latitude'], 6) : '—'; ?>" readonly>
                            </div>
                            <div class="input-group input-group-sm mt-1">
                                <span class="input-group-text">Lng</span>
                                <input type="text" class="form-control" id="stationLngText" value="<?php echo is_numeric($provider['longitude'] ?? null) ? round((float)$provider['longitude'], 6) : '—'; ?>" readonly>
                            </div>
                        </div>
                        <p class="small text-muted mb-2" id="stationHelp">Set your pin, then press <strong>Save Station Position</strong>.</p>
                        <?php if (!empty($provider['location_updated_at'])): ?>
                        <p class="small text-muted mb-2"><i class="fas fa-clock me-1"></i>Last updated <?php echo time_ago($provider['location_updated_at']); ?></p>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary w-100" id="stationSaveBtn" disabled><i class="fas fa-save me-2"></i>Save Station Position</button>
                    </form>
                    <p class="small text-muted mt-2 mb-0"><i class="fas fa-info-circle me-1"></i>Only registered providers appear on the customer map — saving your pin here places your station at that exact spot.</p>
                </div>
            </div>
        </div>
    </main>
</div></div>
<?php $extra_scripts = ['assets/js/provider.js']; $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
