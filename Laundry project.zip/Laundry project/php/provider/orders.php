<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$pid = (int)$user['user_id'];
$provider = get_provider_for_user($pid);
$subActive = provider_subscription_active($provider);

/* Stats row */
$stats = [
    'total'     => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid")->fetchColumn(),
    'completed' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status IN ('delivered','completed')")->fetchColumn(),
    'pending'   => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status = 'pending'")->fetchColumn(),
    'revenue'   => (float)$pdo->query("SELECT COALESCE(SUM(total_price), 0) FROM orders WHERE provider_id = $pid AND status IN ('delivered','completed')")->fetchColumn(),
];

/* Status filter */
$filter = $_GET['status'] ?? 'all';
$where = "o.provider_id = $pid";
switch ($filter) {
    case 'pending':   $where .= " AND o.status = 'pending'"; break;
    case 'active':    $where .= " AND o.status IN ('active','in_progress','out_for_delivery')"; break;
    case 'completed': $where .= " AND o.status IN ('delivered','completed')"; break;
    case 'cancelled': $where .= " AND o.status = 'cancelled'"; break;
}

$stmt = $pdo->prepare(
    "SELECT o.*, u.full_name AS customer_name, u.phone AS customer_phone
     FROM orders o JOIN users u ON u.user_id = o.customer_id
     WHERE $where ORDER BY o.created_at DESC"
);
$stmt->execute();
$orders = $stmt->fetchAll();

$tabs = ['all' => 'All', 'pending' => 'Pending', 'active' => 'Active', 'completed' => 'Completed', 'cancelled' => 'Cancelled'];

$active = 'orders';
$page_title = 'Provider Orders';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-shopping-bag me-2"></i>Orders</h2>

        <div class="row g-3 mb-4">
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3 text-center"><h3 class="fw-bold mb-0" style="color: #0077b6;"><?php echo $stats['total']; ?></h3><small class="text-muted">Total Orders</small></div></div>
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3 text-center"><h3 class="fw-bold mb-0" style="color: #28a745;"><?php echo $stats['completed']; ?></h3><small class="text-muted">Completed</small></div></div>
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3 text-center"><h3 class="fw-bold mb-0" style="color: #ffc107;"><?php echo $stats['pending']; ?></h3><small class="text-muted">Pending</small></div></div>
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3 text-center"><h3 class="fw-bold mb-0" style="color: #0077b6;"><?php echo format_ugx($stats['revenue']); ?></h3><small class="text-muted">Revenue</small></div></div>
        </div>

        <ul class="nav nav-tabs mb-4">
            <?php foreach ($tabs as $key => $label): ?>
            <li class="nav-item"><a class="nav-link <?php echo $filter === $key ? 'active' : ''; ?>" href="?status=<?php echo $key; ?>"><?php echo $label; ?></a></li>
            <?php endforeach; ?>
        </ul>

        <div class="card border-0 shadow-sm rounded-4 p-4">
            <?php if (!$orders): ?>
                <p class="text-muted text-center py-4 mb-0">No orders in this category.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach ($orders as $o): ?>
                        <tr>
                            <td><span class="fw-bold"><?php echo order_code($o['order_id']); ?></span></td>
                            <td><?php echo e($o['customer_name']); ?><br><small class="text-muted"><?php echo e($o['customer_phone']); ?></small></td>
                            <td><?php echo format_ugx($o['total_price']); ?></td>
                            <td><?php echo status_badge($o['status']); ?></td>
                            <td><?php echo format_date($o['created_at']); ?></td>
                            <td>
                                <a href="order_details.php?id=<?php echo (int)$o['order_id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                                <?php if ($o['status'] === 'pending'): ?>
                                <?php if ($subActive): ?>
                                <form method="POST" class="d-inline" action="dashboard.php">
                                    <input type="hidden" name="accept_order" value="<?php echo (int)$o['order_id']; ?>">
                                    <button class="btn btn-sm btn-success"><i class="fas fa-check"></i> Accept</button>
                                </form>
                                <?php else: ?>
                                <a href="pay_fee.php" class="btn btn-sm btn-warning" title="Pay subscription to accept orders"><i class="fas fa-lock"></i> Pay to Accept</a>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
