<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$orderId = (int)($_GET['order_id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT o.*, u.full_name AS customer_name FROM orders o JOIN users u ON u.user_id = o.customer_id
     WHERE o.order_id = ? AND o.provider_id = ? LIMIT 1'
);
$stmt->execute([$orderId, $user['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    flash('danger', 'Order not found.');
    redirect('orders.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && trim($_POST['message'] ?? '') !== '') {
    $stmt = $pdo->prepare('INSERT INTO chat_messages (order_id, sender_id, message) VALUES (?, ?, ?)');
    $stmt->execute([$orderId, $user['user_id'], trim($_POST['message'])]);
    redirect('chat.php?order_id=' . $orderId);
}

$stmt = $pdo->prepare(
    'SELECT m.*, u.full_name FROM chat_messages m JOIN users u ON u.user_id = m.sender_id
     WHERE m.order_id = ? ORDER BY m.message_id ASC LIMIT 200'
);
$stmt->execute([$orderId]);
$messages = $stmt->fetchAll();
$lastId = $messages ? (int)end($messages)['message_id'] : 0;

$active = 'orders';
$page_title = 'Chat';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-transparent pt-4 px-4">
                <div class="d-flex align-items-center">
                    <a href="order_details.php?id=<?php echo $orderId; ?>" class="btn btn-outline-secondary btn-sm me-3"><i class="fas fa-arrow-left"></i></a>
                    <div>
                        <h5 class="fw-bold mb-0">Chat with <?php echo e($order['customer_name']); ?></h5>
                        <small class="text-muted">Order <?php echo order_code($orderId); ?></small>
                    </div>
                </div>
            </div>
            <div class="card-body p-4" style="height: 500px; overflow-y: auto;" id="chatBox">
                <div id="chatMessages">
                <?php foreach ($messages as $m): $mine = (int)$m['sender_id'] === (int)$user['user_id']; ?>
                    <div class="chat-message <?php echo $mine ? 'sent' : 'received'; ?>" data-mid="<?php echo (int)$m['message_id']; ?>">
                        <div class="message-content">
                            <small class="fw-bold"><?php echo $mine ? 'You' : e($m['full_name']); ?></small>
                            <p class="mb-1"><?php echo e($m['message']); ?></p>
                            <small class="text-muted"><?php echo date('h:i A, d M', strtotime($m['sent_at'])); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
            <div class="card-footer bg-transparent px-4 pb-4">
                <form class="d-flex gap-2" method="POST" id="chatForm">
                    <input type="text" name="message" class="form-control" id="chatInput" placeholder="Type your message..." required autocomplete="off">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
                </form>
            </div>
        </div>
    </main>
</div></div>
<script>
(function () {
    const box = document.getElementById('chatBox');
    const msgWrap = document.getElementById('chatMessages');
    const form = document.getElementById('chatForm');
    const input = document.getElementById('chatInput');
    let lastId = <?php echo $lastId; ?>;
    const API = '<?php echo $BASE; ?>php/api/chat.php';
    const ORDER_ID = <?php echo $orderId; ?>;

    function esc(s) {
        const d = document.createElement('div');
        d.textContent = s || '';
        return d.innerHTML;
    }

    function addMessage(m) {
        const wrap = document.createElement('div');
        wrap.className = 'chat-message ' + (m.mine ? 'sent' : 'received');
        wrap.setAttribute('data-mid', m.id);
        wrap.innerHTML = '<div class="message-content"><small class="fw-bold">' + esc(m.mine ? 'You' : m.sender) + '</small>' +
            '<p class="mb-1">' + esc(m.message) + '</p>' +
            '<small class="text-muted">' + esc(m.time) + '</small></div>';
        msgWrap.appendChild(wrap);
        box.scrollTop = box.scrollHeight;
    }

    function poll() {
        fetch(API + '?order_id=' + ORDER_ID + '&after=' + lastId)
            .then(r => r.json())
            .then(data => {
                if (data.ok && data.messages.length) {
                    data.messages.forEach(m => { lastId = Math.max(lastId, m.id); addMessage(m); });
                }
            }).catch(() => {});
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const text = input.value.trim();
        if (!text) return;
        const fd = new FormData();
        fd.append('order_id', ORDER_ID);
        fd.append('message', text);
        fetch(API, { method: 'POST', body: fd })
            .then(r => r.json())
            .then(data => {
                if (data.ok) {
                    lastId = Math.max(lastId, data.message_id);
                    addMessage({ id: data.message_id, mine: true, sender: 'You', message: text, time: 'sending...' });
                    input.value = '';
                }
            }).catch(() => { form.submit(); });
    });

    box.scrollTop = box.scrollHeight;
    setInterval(poll, 4000);
})();
</script>
<?php $close_layout = false; include BASE_PATH . '/php/partials/footer.php'; ?>
