<?php
/**
 * Disputes on my orders — providers see every dispute a customer raised,
 * chat with the customer (and admin) to solve it in one place, and can
 * move a case "in review" so the customer knows it is being looked after.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$pid = (int)$user['user_id'];

ensure_demo_upgrade_tables();

/* ---- POST actions ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (isset($_POST['dispute_reply'])) {
        $did = (int)($_POST['reply_dispute_id'] ?? 0);
        $msg = trim($_POST['reply_message'] ?? '');
        if ($did > 0 && $msg !== '') {
            $v = $pdo->prepare('SELECT dispute_id, customer_id, dispute_code FROM disputes WHERE dispute_id = ? AND provider_id = ? LIMIT 1');
            $v->execute([$did, $pid]);
            $vd = $v->fetch();
            if ($vd) {
                add_dispute_message($did, 'provider', $pid, $msg);
                add_notification((int)$vd['customer_id'], 'Provider Reply', 'The provider replied on dispute ' . $vd['dispute_code'] . ' — check the conversation.', 'php/customer/disputes.php');
                flash('success', 'Your reply was sent to the customer (and is visible to admin).');
            } else {
                flash('danger', 'Dispute not found.');
            }
        }
        redirect('disputes.php');
    }

    if ($action === 'update_status') {
        $did = (int)($_POST['dispute_id'] ?? 0);
        $st = in_array($_POST['status'] ?? '', ['open', 'in_review'], true) ? $_POST['status'] : 'in_review';
        $v = $pdo->prepare('SELECT dispute_id, customer_id, dispute_code, status FROM disputes WHERE dispute_id = ? AND provider_id = ? LIMIT 1');
        $v->execute([$did, $pid]);
        $vd = $v->fetch();
        if ($vd) {
            $pdo->prepare('UPDATE disputes SET status = ? WHERE dispute_id = ?')->execute([$st, $did]);
            add_notification((int)$vd['customer_id'], 'Dispute Update', 'Your case ' . $vd['dispute_code'] . ' is now "' . str_replace('_', ' ', $st) . '".', 'php/customer/disputes.php');
            flash('success', 'Dispute marked as ' . ucwords(str_replace('_', ' ', $st)) . '.');
        } else {
            flash('danger', 'Dispute not found.');
        }
        redirect('disputes.php');
    }
    redirect('disputes.php');
}

/* ---- List disputes on my orders ---- */
$stmt = $pdo->prepare(
    "SELECT d.*, o.status AS order_status, o.total_price, o.created_at AS order_created,
            u.full_name AS customer_name, u.phone AS customer_phone
     FROM disputes d
     JOIN orders o ON o.order_id = d.order_id
     JOIN users u ON u.user_id = d.customer_id
     WHERE d.provider_id = ?
     ORDER BY d.created_at DESC"
);
$stmt->execute([$pid]);
$disputes = $stmt->fetchAll();

$active = 'disputes';
$page_title = 'Disputes on My Orders';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-1"><i class="fas fa-shield-halved me-2"></i>Disputes on My Orders</h2>
        <p class="text-muted mb-4">Customers raise issues on delivered/completed orders. Reply below to solve them directly with the customer — an admin can also join the conversation or resolve the case.</p>

        <?php if (!$disputes): ?>
        <div class="card border-0 shadow-sm rounded-4 p-4">
            <div class="text-center py-4">
                <i class="fas fa-shield-alt fa-3x mb-3" style="color:#28a745;"></i>
                <p class="fw-bold mb-1">No active disputes</p>
                <p class="text-muted small mb-0">When a customer raises an issue on one of your orders, it will appear here so you can give your view and resolve it together.</p>
            </div>
        </div>
        <?php endif; ?>

        <?php foreach ($disputes as $d): ?>
        <div class="card border-0 shadow-sm rounded-4 mb-3">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <strong><?php echo e($d['dispute_code']); ?></strong> &nbsp;<span class="badge bg-secondary"><?php echo e(ucwords(str_replace('_', ' ', (string)($d['type'] ?? 'other')))); ?></span>
                        <br><small class="text-muted"><?php echo order_code((int)$d['order_id']); ?> &middot; Order status: <?php echo e(ucfirst(str_replace('_', ' ', (string)($d['order_status'] ?? 'unknown')))); ?> &middot; Opened <?php echo format_date($d['created_at']); ?></small>
                        <br><small class="text-muted"><i class="fas fa-user me-1"></i><?php echo e($d['customer_name']); ?> (<?php echo e((string)($d['customer_phone'] ?? 'no phone')); ?>)</small>
                    </div>
                    <span class="badge <?php echo $d['status'] === 'resolved' ? 'bg-success' : ($d['status'] === 'open' ? 'bg-danger' : 'bg-warning text-dark'); ?> fs-6"><?php echo e(ucwords(str_replace('_', ' ', (string)$d['status']))); ?></span>
                </div>

                <div class="alert alert-light border rounded-3 mb-2"><strong>Customer says:</strong> <?php echo e($d['description']); ?></div>
                <?php if ($d['admin_note']): ?>
                <div class="alert alert-info border rounded-3 mb-2"><strong>Admin note:</strong> <?php echo e($d['admin_note']); ?></div>
                <?php endif; ?>

                <div class="bg-light border rounded-3 p-2 small mb-2">
                    <strong class="small"><i class="fas fa-comments me-1"></i>Conversation (customer / you / admin)</strong>
                    <?php echo dispute_thread_html(dispute_thread((int)$d['dispute_id'])); ?>
                </div>

                <?php if ($d['status'] !== 'resolved' && $d['status'] !== 'rejected'): ?>
                <form method="POST" class="d-flex gap-2 align-items-center">
                    <input type="hidden" name="reply_dispute_id" value="<?php echo (int)$d['dispute_id']; ?>">
                    <input type="text" name="reply_message" class="form-control form-control-sm" placeholder="Give your side / reply to the customer...">
                    <button type="submit" name="dispute_reply" value="1" class="btn btn-sm btn-outline-success text-nowrap"><i class="fas fa-paper-plane me-1"></i>Send Reply</button>
                </form>
                <div class="d-flex align-items-center gap-2 mt-2 small">
                    <form method="POST" class="d-inline-block">
                        <input type="hidden" name="dispute_id" value="<?php echo (int)$d['dispute_id']; ?>">
                        <input type="hidden" name="status" value="in_review">
                        <button name="action" value="update_status" class="btn btn-sm btn-outline-warning text-nowrap"><i class="fas fa-clock me-1"></i>Mark as "In review"</button>
                    </form>
                    <?php if ($d['status'] === 'in_review'): ?>
                    <form method="POST" class="d-inline-block">
                        <input type="hidden" name="dispute_id" value="<?php echo (int)$d['dispute_id']; ?>">
                        <input type="hidden" name="status" value="open">
                        <button name="action" value="update_status" class="btn btn-sm btn-link text-muted text-nowrap">Reopen</button>
                    </form>
                    <?php endif; ?>
                    <span class="text-muted ms-1">For refunds or full resolution, admin will step in.</span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>