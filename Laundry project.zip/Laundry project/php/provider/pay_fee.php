<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$provider = get_provider_for_user($user['user_id']);
$fee = get_subscription_fee();

/* ---- Pay the monthly platform fee (real MTN when live, else simulated) ---- */
if (isset($_POST['pay_fee'])) {
    $method = ($_POST['payment_method'] ?? 'mtn_money') === 'airtel_money' ? 'airtel_money' : 'mtn_money';
    $number = trim($_POST['mobile_number'] ?? '');
    if ($number === '') {
        flash('danger', 'Please enter your mobile money number.');
    } else {
        $paid = false;
        $ref  = '';

        /* Real MTN subscription charge (Collection by default; uses the Distribution
           product if MTN_MOMO_SUBSCRIPTION_USE_DISTRIBUTION is enabled). */
        if (momo_live() && $method === 'mtn_money' && (momo_collection_configured() || momo_distribution_configured())) {
            $extId = 'SUB-' . $user['user_id'] . '-' . time();
            $res = momo_subscription_charge($fee, $extId, $number);
            if ($res[0]) {
                $paid = true;
                $ref = $res[1];
            } else {
                flash('danger', 'MTN payment failed: ' . e($res[1]) . ' Please try again or choose another method.');
            }
        } else {
            /* Simulation / Airtel (no Airtel keys provided yet) */
            $paid = true;
        }

        if ($paid) {
            $stmt = $pdo->prepare('INSERT INTO provider_payments (provider_id, amount, method, mobile_number, status) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$user['user_id'], $fee, $method, $number, 'success']);
            $pdo->prepare('UPDATE providers SET fee_paid_until = DATE_ADD(CURDATE(), INTERVAL 30 DAY) WHERE provider_id = ?')->execute([$user['user_id']]);
            flash('success', 'Payment successful! Your platform subscription is now valid for the next 30 days.' . ($ref !== '' ? ' MTN ref: ' . $ref : ''));
        }
    }
    redirect('pay_fee.php');
}

$provider = get_provider_for_user($user['user_id']);
$feeUntil = $provider['fee_paid_until'] ?? null;
$feeActive = $feeUntil && strtotime($feeUntil) >= strtotime(date('Y-m-d'));

/* Payment history */
$stmt = $pdo->prepare('SELECT * FROM provider_payments WHERE provider_id = ? ORDER BY paid_at DESC LIMIT 10');
$stmt->execute([$user['user_id']]);
$payments = $stmt->fetchAll();

$active = 'pay_fee';
$page_title = 'Monthly Subscription';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <?php if ($feeActive): ?>
                    <div class="alert alert-success rounded-4 text-center">
                        <i class="fas fa-check-circle fa-2x mb-2"></i>
                        <h5 class="fw-bold mb-1">Subscription Active</h5>
                        <p class="mb-0">Valid until <strong><?php echo format_date($feeUntil); ?></strong></p>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning rounded-4 text-center">
                        <i class="fas fa-lock fa-2x mb-2"></i>
                        <h5 class="fw-bold mb-1">Monthly Subscription Required</h5>
                        <p class="mb-0">You need an active monthly subscription to accept and manage orders.</p>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm rounded-4 p-4 text-center">
                    <div class="bg-light rounded-4 p-4 mb-4">
                        <h5 class="fw-bold mb-2">Monthly Subscription (MTN / Airtel Money)</h5>
                        <h1 class="fw-bold mb-0" style="color: #0077b6;"><?php echo format_ugx($fee); ?></h1>
                        <p class="text-muted mb-0">Valid for 30 days from payment</p>
                    </div>
                    <form method="POST">
                        <div class="mb-3 text-start">
                            <label class="form-label fw-bold">Select Payment Method</label>
                            <select name="payment_method" class="form-select" required>
                                <option value="mtn_money">MTN Mobile Money</option>
                                <option value="airtel_money">Airtel Money</option>
                            </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label fw-bold">Mobile Money Number</label>
                            <input type="tel" name="mobile_number" class="form-control" placeholder="+256 700 000000" required>
                            <small class="text-muted">Enter the mobile money number to receive USSD prompt</small>
                        </div>
                        <div class="alert alert-info text-start mb-3">
                            <i class="fas fa-info-circle me-2"></i>After clicking "Proceed with Payment", you will receive a USSD prompt on your phone. Enter your PIN to complete the payment.
                        </div>
                        <button type="submit" name="pay_fee" value="1" class="btn btn-success btn-lg w-100"><i class="fas fa-mobile-alt me-2"></i>Proceed with Payment</button>
                    </form>
                </div>

                <?php if ($payments): ?>
                <div class="card border-0 shadow-sm rounded-4 p-4 mt-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-history me-2"></i>Payment History</h5>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php foreach ($payments as $p): ?>
                                <tr>
                                    <td><?php echo format_date($p['paid_at']); ?></td>
                                    <td><?php echo format_ugx($p['amount']); ?></td>
                                    <td><?php echo e(str_replace('_', ' ', ucfirst($p['method']))); ?></td>
                                    <td><span class="badge bg-success"><?php echo e(ucfirst($p['status'])); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
