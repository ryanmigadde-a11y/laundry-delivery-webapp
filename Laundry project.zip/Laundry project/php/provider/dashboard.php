<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$provider = get_provider_for_user($user['user_id']);
$pid = (int)$user['user_id'];

/* ---- Accept a pending order straight from the dashboard (subscription required) ---- */
if (isset($_POST['accept_order'])) {
    $acceptId = (int)$_POST['accept_order'];
    $prov = get_provider_for_user($pid);
    if (!provider_subscription_active($prov)) {
        flash('danger', 'Your monthly subscription is not active. Pay your UGX ' . number_format(get_subscription_fee()) . ' subscription to accept orders.');
        redirect('pay_fee.php');
    }
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ? AND provider_id = ? AND status = 'pending'");
    $stmt->execute([$acceptId, $pid]);
    if ($stmt->fetch()) {
        $pdo->prepare("UPDATE orders SET status = 'active' WHERE order_id = ?")->execute([$acceptId]);
        record_history($acceptId, 'pending', 'active', $pid);
        $stmt = $pdo->prepare('SELECT customer_id FROM orders WHERE order_id = ?');
        $stmt->execute([$acceptId]);
        $cid = (int)$stmt->fetchColumn();
        add_notification($cid, 'Order Accepted', 'Your order ' . order_code($acceptId) . ' was accepted by the provider.', 'php/customer/order_details.php?id=' . $acceptId);
        flash('success', 'Order accepted successfully.');
    }
    redirect('dashboard.php');
}

/* ---- Stats ---- */
$stats = [
    'total'     => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid")->fetchColumn(),
    'pending'   => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status = 'pending'")->fetchColumn(),
    'completed' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status IN ('delivered','completed')")->fetchColumn(),
    'revenue'   => (float)$pdo->query("SELECT COALESCE(SUM(total_price), 0) FROM orders WHERE provider_id = $pid AND status IN ('delivered','completed')")->fetchColumn(),
];
$rating = provider_rating($pid);

/* ---- Pending order requests ---- */
$stmt = $pdo->prepare(
    'SELECT o.order_id, o.total_price, u.full_name FROM orders o JOIN users u ON u.user_id = o.customer_id
     WHERE o.provider_id = ? AND o.status = ? ORDER BY o.created_at ASC'
);
$stmt->execute([$pid, 'pending']);
$pendingOrders = $stmt->fetchAll();

/* ---- Revenue for the last 7 days (net earnings per day) ---- */
$stmt = $pdo->prepare(
    "SELECT DATE(created_at) d, SUM(total_price) amount
     FROM orders
     WHERE provider_id = ? AND status NOT IN ('cancelled') AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
     GROUP BY DATE(created_at)"
);
$stmt->execute([$pid]);
$byDay = [];
foreach ($stmt->fetchAll() as $row) {
    $byDay[$row['d']] = (float)$row['amount'];
}
$chartLabels = [];
$chartData = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i day"));
    $chartLabels[] = date('d M', strtotime($day));
    $chartData[] = isset($byDay[$day]) ? round($byDay[$day]) : 0;
}

$feeUntil = $provider['fee_paid_until'] ?? null;
$feeActive = $feeUntil && strtotime($feeUntil) >= strtotime(date('Y-m-d'));

$active = 'dashboard';
$page_title = 'Provider Dashboard';
$load_chartjs = true;
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <?php if (!$feeActive): ?>
        <div class="alert alert-warning d-flex justify-content-between align-items-center rounded-4">
            <span><i class="fas fa-exclamation-triangle me-2"></i>Your monthly subscription is not up to date. Pay UGX <?php echo number_format(get_subscription_fee()); ?> to keep accepting orders.</span>
            <a href="pay_fee.php" class="btn btn-warning btn-sm">Pay Now</a>
        </div>
        <?php endif; ?>

        <!-- Metric Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-6">
                <a href="orders.php?status=all" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['total']; ?></h3><small class="text-white-50">Total Orders</small></div>
                            <i class="fas fa-shopping-bag fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="orders.php?status=completed" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #43e97b, #38f9d7);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['completed']; ?></h3><small class="text-white-50">Completed Orders</small></div>
                            <i class="fas fa-check-circle fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="orders.php?status=pending" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['pending']; ?></h3><small class="text-white-50">Pending Orders</small></div>
                            <i class="fas fa-clock fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="orders.php" class="text-decoration-none">
                    <div class="card border-0 shadow-sm rounded-4 p-3 stat-card" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
                        <div class="d-flex justify-content-between">
                            <div><h3 class="text-white fw-bold mb-0"><?php echo format_ugx($stats['revenue']); ?></h3><small class="text-white-50">Revenue</small></div>
                            <i class="fas fa-money-bill-wave fa-3x text-white-50"></i>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="row g-4">
            <!-- Pending order requests -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-transparent border-bottom-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0"><i class="fas fa-clock me-2" style="color: #f5576c;"></i>Pending Order Requests</h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if (!$pendingOrders): ?>
                            <p class="text-muted text-center py-4 mb-0">No pending orders right now. New requests will appear here.</p>
                        <?php endif; ?>
                        <?php foreach ($pendingOrders as $po): ?>
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-2">
                            <div>
                                <span class="fw-bold"><?php echo order_code($po['order_id']); ?></span>
                                <small class="d-block text-muted"><?php echo e($po['full_name']); ?></small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="fw-bold me-2"><?php echo format_ugx($po['total_price']); ?></span>
                                <a href="order_details.php?id=<?php echo (int)$po['order_id']; ?>" class="btn btn-sm btn-outline-primary me-1">View</a>
                                <form method="POST">
                                    <button name="accept_order" value="<?php echo (int)$po['order_id']; ?>" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Accept</button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Revenue chart -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-transparent border-bottom-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0"><i class="fas fa-chart-bar me-2" style="color: #0077b6;"></i>Revenue (Last 7 Days)</h5>
                    </div>
                    <div class="card-body p-4"><canvas id="revenueChart"></canvas></div>
                </div>
            </div>
        </div>

        <!-- Rating widget -->
        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4 d-flex flex-row align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <i class="fas fa-star fa-3x text-warning me-3"></i>
                <div>
                    <h3 class="fw-bold mb-0"><?php echo $rating['avg']; ?> <small class="fs-6 text-muted">/ 5</small></h3>
                    <small class="text-muted">Based on <?php echo $rating['count']; ?> review<?php echo $rating['count'] == 1 ? '' : 's'; ?></small>
                </div>
            </div>
            <a href="reviews.php" class="btn btn-outline-primary"><i class="fas fa-eye me-2"></i>See Reviews</a>
        </div>


    </main>
</div></div>
<script>
    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chartLabels); ?>,
            datasets: [{
                label: 'Revenue (UGX)',
                data: <?php echo json_encode($chartData); ?>,
                borderColor: '#0077b6',
                backgroundColor: 'rgba(0,119,182,0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
</script>
<?php $close_layout = false; include BASE_PATH . '/php/partials/footer.php'; ?>
