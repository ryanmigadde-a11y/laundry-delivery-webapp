<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$user = current_user();
$provider = get_provider_for_user((int)$user['user_id']);
$page_title = 'Share Live Location';
$active = 'live_location';
$extra_css = ['assets/vendor/leaflet/leaflet.css'];
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-2"><i class="fas fa-satellite-dish me-2 text-success"></i>Share Live Provider Location</h2>
        <p class="text-muted">When you turn sharing on, customers viewing the laundry station map can see your current position for up to two minutes after your last update. Your saved station pin remains separate.</p>
        <div class="alert alert-info rounded-4"><strong>Privacy:</strong> GPS sharing is optional. Start it only while you want customers nearby to see your live position. Stop sharing when finished. Keep this page open while sharing.</div>
        <div class="card border-0 shadow-sm rounded-4 p-3">
            <div id="providerLiveMap" style="height:420px;width:100%;border-radius:12px;"></div>
            <div class="d-flex gap-2 flex-wrap mt-3">
                <button type="button" id="providerLiveStart" class="btn btn-success"><i class="fas fa-play me-1"></i>Start sharing GPS</button>
                <button type="button" id="providerLiveStop" class="btn btn-outline-danger" disabled><i class="fas fa-stop me-1"></i>Stop sharing</button>
            </div>
            <p id="providerLiveStatus" class="small text-muted mt-3 mb-0" aria-live="polite">Location sharing is off. Press Start sharing GPS to begin.</p>
        </div>
    </main>
</div></div>
<script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
<script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
<script src="<?php echo $BASE; ?>assets/js/provider_live_location.js"></script>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
