<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$pid = (int)$user['user_id'];
$orderId = (int)($_GET['id'] ?? $_POST['order_id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT o.*, u.full_name AS customer_name, u.phone AS customer_phone, u.email AS customer_email, u.location AS customer_location
     FROM orders o JOIN users u ON u.user_id = o.customer_id
     WHERE o.order_id = ? AND o.provider_id = ? LIMIT 1'
);
$stmt->execute([$orderId, $pid]);
$order = $stmt->fetch();

if (!$order) {
    flash('danger', 'Order not found.');
    redirect('orders.php');
}

/* ---- Sequential status updates ---- */
$provider = get_provider_for_user($pid);
$subActive = provider_subscription_active($provider);

$transitions = [
    'pending'          => ['active' => 'Accept Order'],
    'active'           => ['in_progress' => 'Order Picked Up — Start Cleaning'],
    'in_progress'      => ['out_for_delivery' => 'Out for Delivery'],
    'out_for_delivery' => ['delivered' => 'Mark as Delivered'],
    'delivered'        => ($order['payment_status'] === 'confirmed') ? ['completed' => 'Mark as Completed'] : [],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_status'])) {
    $newStatus = $_POST['new_status'];
    $allowed = $transitions[$order['status']] ?? [];

    /* Provider must have a valid monthly subscription to accept any order. */
    if ($newStatus === 'active' && !$subActive) {
        flash('danger', 'Your monthly subscription is not active. Please pay your UGX ' . number_format(get_subscription_fee()) . ' subscription fee first.');
        redirect('pay_fee.php');
    }
    if ($newStatus === 'completed' && $order['payment_status'] !== 'confirmed') {
        flash('danger', 'Please confirm that you received the payment before completing this order.');
        redirect('order_details.php?id=' . $orderId);
    }

    if (isset($allowed[$newStatus])) {
        $pdo->prepare('UPDATE orders SET status = ? WHERE order_id = ?')->execute([$newStatus, $orderId]);
        if ($newStatus === 'active') {
            $pdo->prepare("UPDATE orders SET payment_status = 'pending' WHERE order_id = ?")->execute([$orderId]);
        }
        record_history($orderId, $order['status'], $newStatus, $pid);
        $msgs = [
            'active'           => 'Your order ' . order_code($orderId) . ' has been accepted and is now active.',
            'in_progress'      => 'Your clothes have been picked up and cleaning is in progress for order ' . order_code($orderId) . '.',
            'out_for_delivery' => 'Your order ' . order_code($orderId) . ' is out for delivery.',
            'delivered'        => 'Your order ' . order_code($orderId) . ' has been delivered. Kindly confirm the provider received payment.',
            'completed'        => 'Your order ' . order_code($orderId) . ' is fully completed. Thank you for choosing us. Please leave a review!',
        ];
        add_notification((int)$order['customer_id'], 'Order Update', $msgs[$newStatus] ?? 'Order status updated.', 'php/customer/order_details.php?id=' . $orderId);

        /* Real MTN: disburse the order total to the provider (payout only in live mode). */
        if ($newStatus === 'completed') {
            $p_res = momo_pay_provider_for_order($orderId, $pid, (float)$order['total_price']);
            if ($p_res[0]) {
                add_notification($pid, 'Payment Received', 'Your UGX ' . number_format($order['total_price']) . ' payout for order ' . order_code($orderId) . ' has been sent via MTN MoMo.', 'php/provider/dashboard.php');
            }
        }

        flash('success', 'Order status updated to ' . str_replace('_', ' ', $newStatus) . '.');
    } else {
        flash('danger', 'That status change is not allowed right now.');
    }
    redirect('order_details.php?id=' . $orderId);
}

/* ---- Provider confirms they received the payment (cash/mobile money) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    if ($order['status'] !== 'delivered') {
        flash('danger', 'You can only confirm payment once the order has been delivered.');
    } else {
        $pdo->prepare("UPDATE orders SET payment_status = 'confirmed', payment_confirmed_at = NOW() WHERE order_id = ?")->execute([$orderId]);
        ensure_demo_upgrade_tables();
        ensure_order_receipt($orderId); /* issue the customer's payment receipt now */
        record_history($orderId, 'payment_pending', 'payment_confirmed', $pid);
        add_notification((int)$order['customer_id'], 'Payment Confirmed', 'The provider confirmed receiving payment for order ' . order_code($orderId) . '. Your payment receipt is ready.', 'php/customer/receipt.php?order_id=' . $orderId);
        flash('success', 'Payment received confirmed. The order is ready to be marked as completed.');
    }
    redirect('order_details.php?id=' . $orderId);
}

/* ---- Provider uploads garment evidence (before/after) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_evidence'])) {
    $stage = in_array($_POST['stage'] ?? '', ['picked_up', 'before_delivery', 'delivered'], true) ? $_POST['stage'] : 'picked_up';
    $note = trim($_POST['evidence_note'] ?? '');
    $pic = handle_upload($_FILES['evidence_img'] ?? null, 'evidence');
    if ($pic) {
        $pdo->prepare('INSERT INTO order_evidence (order_id, stage, image, note) VALUES (?, ?, ?, ?)')
            ->execute([$orderId, $stage, $pic, $note]);
        add_notification((int)$order['customer_id'], 'Garment Evidence', 'The provider attached photo evidence for order ' . order_code($orderId) . '.', 'php/customer/order_details.php?id=' . $orderId);
        flash('success', 'Evidence photo uploaded.');
    } else {
        flash('warning', 'Evidence not saved: ' . ($GLOBALS['upload_error'] ?? 'Select an image.'));
    }
    redirect('order_details.php?id=' . $orderId);
}

/* ---- Driver assignment (smart delivery) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_driver'])) {
    $name = trim($_POST['driver_name'] ?? '');
    $phone = trim($_POST['driver_phone'] ?? '');
    if ($name === '') {
        flash('danger', 'Enter a driver name.');
    } else {
        $pdo->prepare('UPDATE orders SET driver_name = ?, driver_phone = ? WHERE order_id = ?')->execute([$name, $phone, $orderId]);
        add_notification((int)$order['customer_id'], 'Driver Assigned', $name . ' will handle delivery of order ' . order_code($orderId) . '.', 'php/customer/order_details.php?id=' . $orderId);
        flash('success', 'Driver assigned.');
    }
    redirect('order_details.php?id=' . $orderId);
}

/* Evidence images for this order */
ensure_demo_upgrade_tables();
$evidenceRows = [];
$stmt = $pdo->prepare('SELECT * FROM order_evidence WHERE order_id = ? ORDER BY evidence_id DESC');
$stmt->execute([$orderId]);
$evidenceRows = $stmt->fetchAll();

/* Items */
$stmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY item_id ASC');
$stmt->execute([$orderId]);
$items = $stmt->fetchAll();

/* Dispute reference for this order (quick link) */
$disputeRow = null;
$dstmt = $pdo->prepare('SELECT dispute_id, dispute_code, status FROM disputes WHERE order_id = ? AND provider_id = ? LIMIT 1');
$dstmt->execute([$orderId, $pid]);
$disputeRow = $dstmt->fetch();

$netEarning = (float)$order['total_price'] - (float)$order['platform_deduction'];
$nextAction = $transitions[$order['status']] ?? [];

$active = 'orders';
$page_title = 'Order Details';
$extra_css = ['assets/vendor/leaflet/leaflet.css'];
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1"><?php echo order_code($orderId); ?> <?php echo status_badge($order['status']); ?></h2>
                <p class="text-muted mb-0">Customer: <?php echo e($order['customer_name']); ?> | <?php echo e($order['customer_phone']); ?></p>
            </div>
            <a href="orders.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-2"></i>Back to Orders</a>
        </div>

        <div class="row g-4">
            <div class="col-md-8">
                <!-- Order Items -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Order Items</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead><tr><th>Service</th><th>Item</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td><?php echo e($item['service_name']); ?></td>
                                        <td><?php echo e($item['clothing_type']); ?></td>
                                        <td><?php echo (int)$item['quantity']; ?></td>
                                        <td><?php echo format_ugx($item['price_per_item']); ?></td>
                                        <td class="fw-bold"><?php echo format_ugx($item['subtotal']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr><td colspan="5" class="text-end fw-bold">Total:</td><td class="fw-bold fs-5" style="color: #0077b6;"><?php echo format_ugx($order['total_price']); ?></td></tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Customer Info -->
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Customer Info</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Name:</strong> <?php echo e($order['customer_name']); ?></p>
                                <p><strong>Phone:</strong> <?php echo e($order['customer_phone']); ?></p>
                                <p><strong>Email:</strong> <?php echo e($order['customer_email']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Location:</strong> <?php echo e((string)($order['customer_location'] ?? '&mdash;')); ?></p>
                                <p><strong>Pickup Address:</strong> <?php echo e($order['pickup_address']); ?></p>
                                <?php if ($order['special_instructions']): ?>
                                <p class="mb-0"><strong>Special Instructions:</strong> <?php echo e($order['special_instructions']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <!-- Actions -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Actions</h5>
                        <div class="d-grid gap-2">
                            <?php foreach ($nextAction as $newStatus => $label): ?>
                            <form method="POST" onsubmit="return confirm('Proceed: <?php echo e($label); ?>?');">
                                <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                                <input type="hidden" name="new_status" value="<?php echo e($newStatus); ?>">
                                <button type="submit" class="btn btn-success w-100"><i class="fas fa-check me-2"></i><?php echo e($label); ?></button>
                            </form>
                            <?php endforeach; ?>
                            <?php if ($order['status'] === 'delivered' && $order['payment_status'] !== 'confirmed'): ?>
                                <form method="POST" onsubmit="return confirm('Have you received the payment?');">
                                    <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                                    <button name="confirm_payment" value="1" class="btn btn-warning w-100"><i class="fas fa-hand-holding-usd me-2"></i>Confirm Payment Received</button>
                                </form>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'delivered' && $order['payment_status'] !== 'confirmed'): ?>
                                <div class="alert alert-warning mb-0 small"><i class="fas fa-exclamation-triangle me-2"></i>Confirm that you received the payment before marking the order completed.</div>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'completed'): ?>
                                <div class="alert alert-success mb-0 small"><i class="fas fa-check-circle me-2"></i>This order is complete. <?php echo format_ugx($order['total_price']); ?> was added to your earnings.</div>
                            <?php endif; ?>
                            <a href="chat.php?order_id=<?php echo $orderId; ?>" class="btn btn-outline-primary"><i class="fas fa-comment me-2"></i>Chat with Customer</a>
                            <?php if ($disputeRow): ?>
                            <a href="disputes.php" class="btn btn-outline-danger"><i class="fas fa-shield-halved me-2"></i>Discuss Dispute <?php echo e($disputeRow['dispute_code']); ?></a>
                            <?php endif; ?>
                            <?php if ($order['status'] === 'in_progress'): ?>
                            <div class="alert alert-info mb-0 small"><i class="fas fa-spinner fa-spin me-1"></i>Cleaning in progress — the customer now sees this stage on their tracking bar.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Payment -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Payment</h5>
                        <p class="mb-2"><strong>Method:</strong> <?php echo e(ucfirst(str_replace('_', ' ', $order['payment_method']))); ?></p>
                        <p class="mb-2"><strong>Status:</strong> <?php echo status_badge($order['payment_status']); ?></p>
                        <p class="mb-0"><strong>Total:</strong> <?php echo format_ugx($order['total_price']); ?></p>
                    </div>
                </div>

                <!-- Schedule info -->
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Order Info</h5>
                        <p class="mb-2"><strong>Pickup:</strong> <?php echo format_date($order['pickup_date']); ?></p>
                        <p class="mb-2"><strong>Pickup Time:</strong> <?php echo e($order['pickup_time'] ?? '&mdash;'); ?></p>
                        <p class="mb-2"><strong>Delivery:</strong> <?php echo format_date($order['delivery_date']); ?></p>
                        <p class="mb-0"><strong>Delivery Time:</strong> <?php echo e($order['delivery_time'] ?? '&mdash;'); ?></p>
                    </div>
                </div>

                <!-- Driver -->
                <div class="card border-0 shadow-sm rounded-4 mt-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-truck me-2" style="color:#0077b6;"></i>Driver / Delivery Assignment</h5>
                        <form method="POST" class="row g-2">
                            <div class="col-12"><input type="text" name="driver_name" class="form-control" placeholder="Driver name" value="<?php echo e($order['driver_name'] ?? ''); ?>"></div>
                            <div class="col-12"><input type="tel" name="driver_phone" class="form-control" placeholder="Driver phone" value="<?php echo e($order['driver_phone'] ?? ''); ?>"></div>
                            <div class="col-12"><button type="submit" name="assign_driver" value="1" class="btn btn-outline-primary btn-sm w-100"><i class="fas fa-truck-fast me-1"></i>Save Driver</button></div>
                        </form>
                    </div>
                </div>

                <!-- Evidence -->
                <div class="card border-0 shadow-sm rounded-4 mt-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-camera me-2" style="color:#0077b6;"></i>Before / After Garment Evidence</h5>
                        <form method="POST" enctype="multipart/form-data" class="row g-2">
                            <div class="col-12">
                                <select name="stage" class="form-select">
                                    <option value="picked_up">At pickup</option>
                                    <option value="before_delivery">Before delivery</option>
                                    <option value="delivered">At delivery</option>
                                </select>
                            </div>
                            <div class="col-12"><input type="file" name="evidence_img" class="form-control" accept="image/*" required></div>
                            <div class="col-12"><input type="text" name="evidence_note" class="form-control" placeholder="Note (optional)"></div>
                            <div class="col-12"><button type="submit" name="upload_evidence" value="1" class="btn btn-outline-success btn-sm w-100"><i class="fas fa-cloud-arrow-up me-1"></i>Upload Evidence</button></div>
                        </form>
                        <?php if ($evidenceRows): ?>
                        <hr>
                        <div class="row g-2">
                            <?php foreach ($evidenceRows as $ev): ?>
                            <div class="col-6">
                                <img src="<?php echo $BASE . 'assets/images/uploads/' . rawurlencode($ev['image']); ?>" class="img-fluid rounded-3 border" alt="Evidence">
                                <small class="text-muted d-block"><?php echo e(ucwords(str_replace('_', ' ', $ev['stage']))); ?> · <?php echo format_date($ev['created_at']); ?></small>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Live Delivery Tracking (share courier GPS while the order moves) -->
                <?php if (in_array($order['status'], ['active', 'in_progress', 'out_for_delivery'], true)): ?>
                <div class="card border-0 shadow-sm rounded-4 mt-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-2"><i class="fas fa-satellite-dish me-2" style="color:#198754;"></i>Live Delivery Tracking</h5>
                        <p class="small text-muted mb-3">Share your GPS position while picking up or delivering so the customer can watch the courier move on their map in real time.</p>
                        <div id="shareMap" class="border mb-2" style="height: 220px; width: 100%; border-radius: 12px;"></div>
                        <div class="d-flex gap-2 mb-2">
                            <button type="button" id="shareStartBtn" class="btn btn-success btn-sm"><i class="fas fa-play me-1"></i>Start Sharing Location</button>
                            <button type="button" id="shareStopBtn" class="btn btn-outline-danger btn-sm" style="display:none;"><i class="fas fa-stop me-1"></i>Stop Sharing</button>
                        </div>
                        <div id="shareStatus" class="small text-muted"></div>
                    </div>
                </div>
                <?php endif; ?>
            </div>


    </main>
</div></div>
<?php if (in_array($order['status'], ['active', 'in_progress', 'out_for_delivery'], true)): ?>
<script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
<script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
<script>
    window.SHARE_CONFIG = {
        apiUrl:     '<?php echo $BASE; ?>php/api/tracking.php',
        orderId:    <?php echo (int)$order['order_id']; ?>,
        status:     <?php echo json_encode($order['status']); ?>,
        intervalMs: 5000
    };
</script>
<script src="<?php echo $BASE; ?>assets/js/share_location.js"></script>
<?php endif; ?>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
