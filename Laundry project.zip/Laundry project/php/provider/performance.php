<?php
/**
 * Provider Performance Center — reliability score with breakdown for ratings,
 * delivery reliability, response time, complaints and completion.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);

$pdo = $GLOBALS['pdo'];
$user = current_user();
$pid = (int)$user['user_id'];

$rel = provider_reliability($pid);
$avg = provider_avg_delivery_days($pid);
$rating = provider_rating($pid);

$stats = [
    'total' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid")->fetchColumn(),
    'completed' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status IN ('delivered','completed')")->fetchColumn(),
    'pending' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status = 'pending'")->fetchColumn(),
    'cancelled' => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE provider_id = $pid AND status = 'cancelled'")->fetchColumn(),
];

/* Score bars: Rating 40%, Reliability 25%, Delivery 20%, Response 15% */
$ratingScore = $rating['count'] > 0 ? $rating['avg'] / 5 * 100 : 0;
$relScore = $rel ? $rel['score'] : 60;
$deliveryScore = $rel ? $rel['on_time'] : 100;
$response = $stats['total'] > 0 ? min(100, round((1 - $stats['pending'] / max(1, $stats['total'])) * 100)) : 50;
$overall = round(min(100, max(0, $ratingScore * 0.4 + $relScore * 0.25 + $deliveryScore * 0.20 + $response * 0.15)));

$active = 'performance';
$page_title = 'Performance Center';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-chart-line me-2"></i>Performance Center</h2>

        <div class="row g-4 mb-4">
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100">
                    <h1 class="fw-bold mb-0" style="color:#0077b6;"><?php echo $overall; ?></h1>
                    <small class="text-muted">Performance Score / 100</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100">
                    <h3 class="fw-bold mb-0"><?php echo $stats['total']; ?></h3>
                    <small class="text-muted">Total Orders</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100">
                    <h3 class="fw-bold mb-0"><?php echo $stats['completed']; ?></h3>
                    <small class="text-muted">Completed</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3 text-center h-100">
                    <h3 class="fw-bold mb-0"><?php echo $stats['cancelled']; ?></h3>
                    <small class="text-muted">Cancelled</small>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4">
            <h5 class="fw-bold mb-4"><i class="fas fa-sliders me-2" style="color:#0077b6;"></i>Score Breakdown</h5>
            <?php
            $bars = [
                'Customer rating' => $ratingScore,
                'Reliability (completion, no disputes)' => $relScore,
                'Delivery performance (on-time)' => $deliveryScore,
                'Response (pending workload)' => $response,
            ];
            foreach ($bars as $label => $val): ?>
            <div class="mb-3">
                <div class="d-flex justify-content-between small">
                    <span><?php echo e($label); ?></span>
                    <strong><?php echo round((float)$val); ?>/100</strong>
                </div>
                <div class="progress" style="height:10px;">
                    <div class="progress-bar <?php echo $val >= 80 ? 'bg-success' : ($val >= 60 ? 'bg-warning' : 'bg-danger'); ?>" style="width:<?php echo (float)$val; ?>%;"></div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if ($rel): ?>
            <div class="alert alert-info rounded-4 mb-0 small"><i class="fas fa-info-circle me-2"></i>
                <?php echo (int)$rel['complaints']; ?> open dispute(s) · <?php echo (int)$rel['cancelled']; ?> cancelled order(s) · Avg delivery <?php echo $avg !== null ? $avg . ' days' : 'N/A'; ?> · <?php echo (int)$rating['count']; ?> review(s) at <?php echo $rating['avg']; ?>/5.
            </div>
            <?php else: ?>
            <div class="alert alert-warning rounded-4 mb-0 small"><i class="fas fa-info-circle me-2"></i>Not enough data yet — complete orders to build your score.</div>
            <?php endif; ?>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>