<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_login(['provider'], $BASE);
ensure_provider_location_columns();
$pdo = $GLOBALS['pdo'];
$user = current_user();
$provider = get_provider_for_user($user['user_id']);
$active = 'share_location';
$page_title = 'Share Live Location';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/provider_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-2"><i class="fas fa-location-crosshairs me-2"></i>Share Live Location</h2>
        <p class="text-muted">Let nearby customers find your laundry station while you are open. Your location is only shared while you choose to share it.</p>
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                    <div id="providerLiveMap" style="height:430px;width:100%;"></div>
                    <div class="card-body">
                        <div class="d-flex flex-wrap gap-2">
                            <button type="button" class="btn btn-success" id="providerShareStart"><i class="fas fa-location-arrow me-1"></i>Start sharing my location</button>
                            <button type="button" class="btn btn-outline-danger" id="providerShareStop" disabled><i class="fas fa-stop me-1"></i>Stop sharing</button>
                        </div>
                        <p id="providerShareStatus" class="small mt-3 mb-0" role="status">Location sharing is off. Press Start and allow GPS access.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold">How it works</h5>
                    <ol class="ps-3 mb-0">
                        <li class="mb-2">Press <strong>Start sharing my location</strong>.</li>
                        <li class="mb-2">Allow location permission in your browser.</li>
                        <li class="mb-2">Keep this page open while sharing.</li>
                        <li class="mb-2">Customers can see your moving marker on <strong>Laundry Stations Near You</strong>.</li>
                        <li>Press Stop when you no longer want to share.</li>
                    </ol>
                    <hr>
                    <p class="small text-muted mb-0">GPS requires HTTPS on public websites. Localhost is allowed for testing. The map shows a live marker for up to two minutes after the last update; after that, it falls back to your saved station pin.</p>
                </div>
            </div>
        </div>
    </main>
</div></div>
<link rel="stylesheet" href="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet.css">
<script src="<?php echo $BASE; ?>assets/vendor/leaflet/leaflet-global.js"></script>
<script src="<?php echo $BASE; ?>assets/js/leaflet-compat.js"></script>
<script>
(function () {
    const map = L.map('providerLiveMap').setView([0.3136, 32.5811], 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map);
    let marker = null;
    let watchId = null;
    let lastSent = 0;
    const startBtn = document.getElementById('providerShareStart');
    const stopBtn = document.getElementById('providerShareStop');
    const statusEl = document.getElementById('providerShareStatus');
    const apiUrl = '../../php/api/provider_live_location.php';

    function setStatus(message, type) {
        statusEl.className = 'small mt-3 mb-0 ' + (type || 'text-muted');
        statusEl.textContent = message;
    }
    function setMarker(lat, lng) {
        if (!marker) {
            marker = L.marker([lat, lng]).addTo(map).bindPopup('Your live location');
        } else {
            marker.setLatLng([lat, lng]);
        }
        map.setView([lat, lng], Math.max(map.getZoom(), 15));
    }
    function sendLocation(position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setMarker(lat, lng);
        const now = Date.now();
        if (now - lastSent < 5000) return;
        lastSent = now;
        const body = new FormData();
        body.append('action', 'update');
        body.append('lat', lat);
        body.append('lng', lng);
        body.append('accuracy', position.coords.accuracy || '');
        fetch(apiUrl, { method: 'POST', body: body, credentials: 'same-origin' })
            .then(response => response.json())
            .then(data => {
                if (data.ok) setStatus('Sharing live GPS. Last update: ' + new Date().toLocaleTimeString(), 'text-success');
                else setStatus(data.message || 'Could not share location. Check that your provider account is approved and active.', 'text-danger');
            })
            .catch(() => setStatus('Network error while sharing GPS. Check your connection and try again.', 'text-danger'));
    }
    function locationError(error) {
        const messages = {
            1: 'Location permission was denied. Allow location access in your browser settings.',
            2: 'GPS position is unavailable. Check your device location setting.',
            3: 'GPS timed out. Try again in an area with a better signal.'
        };
        setStatus(messages[error.code] || 'Could not obtain your GPS location.', 'text-danger');
        if (error.code === 1) stopSharing(false);
    }
    function startSharing() {
        if (!navigator.geolocation) {
            setStatus('This browser does not support GPS location.', 'text-danger');
            return;
        }
        if (watchId !== null) return;
        watchId = navigator.geolocation.watchPosition(sendLocation, locationError, {
            enableHighAccuracy: true,
            maximumAge: 3000,
            timeout: 20000
        });
        startBtn.disabled = true;
        stopBtn.disabled = false;
        setStatus('Waiting for GPS signal. Keep this page open.', 'text-primary');
    }
    function stopSharing(sendStop) {
        if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
        watchId = null;
        startBtn.disabled = false;
        stopBtn.disabled = true;
        if (sendStop !== false) {
            const body = new FormData();
            body.append('action', 'stop');
            fetch(apiUrl, { method: 'POST', body: body, credentials: 'same-origin' }).catch(() => {});
        }
        setStatus('Location sharing is off.', 'text-muted');
    }
    startBtn.addEventListener('click', startSharing);
    stopBtn.addEventListener('click', () => stopSharing(true));
    window.addEventListener('beforeunload', () => {
        if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    });
})();
</script>
<?php include BASE_PATH . '/php/partials/footer.php'; ?>
