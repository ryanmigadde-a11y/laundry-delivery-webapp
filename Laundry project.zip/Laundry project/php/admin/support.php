<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Support actions ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'mark_read') {
        $pdo->prepare('UPDATE support_messages SET is_read = 1 WHERE support_id = ?')->execute([(int)$_POST['support_id']]);
        flash('success', 'Message marked as read.');
    }
    if (($_POST['action'] ?? '') === 'delete') {
        $pdo->prepare('DELETE FROM support_messages WHERE support_id = ?')->execute([(int)$_POST['support_id']]);
        flash('success', 'Message deleted.');
    }
    redirect('support.php');
}

$messages = $pdo->query('SELECT * FROM support_messages ORDER BY is_read ASC, created_at DESC')->fetchAll();

$active = 'support';
$page_title = 'Support';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-headset me-2"></i>Support &amp; Feedback Messages</h2>

        <?php if (!$messages): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <p class="text-muted mb-0">No support messages yet.</p>
            </div>
        <?php endif; ?>

        <?php foreach ($messages as $m): ?>
        <div class="card border-0 shadow-sm rounded-4 mb-3 border-start <?php echo $m['is_read'] ? '' : 'border-primary border-4'; ?>">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between flex-wrap gap-2">
                    <div>
                        <h6 class="fw-bold"><?php echo e($m['name']); ?> <small class="text-muted">(<?php echo e($m['email']); ?>)</small></h6>
                        <h6 class="text-primary"><?php echo e($m['subject']); ?></h6>
                        <p class="mb-1"><?php echo e($m['message']); ?></p>
                        <small class="text-muted"><?php echo date('d M Y, h:i A', strtotime($m['created_at'])); ?></small>
                    </div>
                    <div class="text-end">
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="support_id" value="<?php echo (int)$m['support_id']; ?>">
                            <button name="action" value="mark_read" class="btn btn-sm btn-outline-success mt-2" <?php echo $m['is_read'] ? 'disabled' : ''; ?>><i class="fas fa-check"></i> Mark Read</button>
                        </form>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this message?');">
                            <input type="hidden" name="support_id" value="<?php echo (int)$m['support_id']; ?>">
                            <button name="action" value="delete" class="btn btn-sm btn-outline-danger mt-2"><i class="fas fa-trash"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
