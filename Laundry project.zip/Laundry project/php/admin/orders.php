<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Admin can cancel any order (oversight) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancel_order') {
    $orderId = (int)($_POST['order_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ? AND status = 'pending'");
    $stmt->execute([$orderId]);
    if ($stmt->fetch()) {
        $pdo->prepare("UPDATE orders SET status = 'cancelled' WHERE order_id = ?")->execute([$orderId]);
        record_history($orderId, 'pending', 'cancelled', null);
        flash('success', 'Order cancelled.');
    }
    redirect('orders.php?status=' . urlencode($_GET['status'] ?? 'all'));
}

$filter = $_GET['status'] ?? 'all';
$where = '1=1';
switch ($filter) {
    case 'pending':   $where = "o.status = 'pending'"; break;
    case 'active':    $where = "o.status IN ('active','in_progress','out_for_delivery')"; break;
    case 'completed': $where = "o.status IN ('delivered','completed')"; break;
    case 'cancelled': $where = "o.status = 'cancelled'"; break;
}

$orders = $pdo->query(
    "SELECT o.*, c.full_name AS customer_name, p.business_name
     FROM orders o
     JOIN users c ON c.user_id = o.customer_id
     JOIN providers p ON p.provider_id = o.provider_id
     WHERE $where
     ORDER BY o.created_at DESC"
)->fetchAll();

$tabs = ['all' => 'All', 'pending' => 'Pending', 'active' => 'Active', 'completed' => 'Completed', 'cancelled' => 'Cancelled'];

$active = 'orders';
$page_title = 'All Orders';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-shopping-bag me-2"></i>All Orders</h2>
        <ul class="nav nav-tabs mb-4">
            <?php foreach ($tabs as $key => $label): ?>
            <li class="nav-item"><a class="nav-link <?php echo $filter === $key ? 'active' : ''; ?>" href="?status=<?php echo $key; ?>"><?php echo $label; ?></a></li>
            <?php endforeach; ?>
        </ul>
        <div class="card border-0 shadow-sm rounded-4 p-4">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>ID</th><th>Customer</th><th>Provider</th><th>Total</th><th>Platform Fee</th><th>Status</th><th>Payment</th><th>Date</th><th></th></tr></thead>
                    <tbody>
                        <?php foreach ($orders as $o): ?>
                        <tr>
                            <td><?php echo order_code($o['order_id']); ?></td>
                            <td><?php echo e($o['customer_name']); ?></td>
                            <td><?php echo e($o['business_name']); ?></td>
                            <td><?php echo format_ugx($o['total_price']); ?></td>
                            <td><?php echo format_ugx($o['platform_deduction']); ?></td>
                            <td><?php echo status_badge($o['status']); ?></td>
                            <td><?php echo status_badge($o['payment_status']); ?></td>
                            <td><?php echo format_date($o['created_at']); ?></td>
                            <td>
                                <?php if ($o['status'] === 'pending'): ?>
                                <form method="POST" onsubmit="return confirm('Cancel this pending order?');">
                                    <input type="hidden" name="order_id" value="<?php echo (int)$o['order_id']; ?>">
                                    <button name="action" value="cancel_order" class="btn btn-sm btn-outline-danger">Cancel</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (!$orders): ?><tr><td colspan="9" class="text-center text-muted py-4">No orders found.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
