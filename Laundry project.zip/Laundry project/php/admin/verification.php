<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Admin actions: approve / reject / request more info ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action     = $_POST['action'] ?? '';
    $providerId = (int)($_POST['provider_id'] ?? 0);
    $note       = trim($_POST['note'] ?? '');

    if ($providerId && in_array($action, ['approve', 'reject', 'pending'], true)) {
        $pdo->prepare('UPDATE providers SET verification_status = ?, verification_note = ? WHERE provider_id = ?')
            ->execute([$action, $note ?: null, $providerId]);

        if ($action === 'approve') {
            $pdo->prepare('UPDATE providers SET is_approved = 1 WHERE provider_id = ?')->execute([$providerId]);
            $msg = 'Congratulations! Your laundry business has been verified and approved. Customers can now find you with the verified badge.';
        } elseif ($action === 'reject') {
            $msg = 'Sorry, your verification was rejected.' . ($note ? ' Reason: ' . $note : '');
        } else {
            $msg = 'Our team needs more information to verify your business.' . ($note ? ' ' . $note : '');
        }
        add_notification($providerId, 'Verification Update', $msg, 'php/provider/business_settings.php');
        lex_log_audit('verification_' . $action, 'Provider ' . $providerId . ' => ' . $action . $note);
        flash('success', 'Provider verification updated to "' . $action . '".');
    }
    redirect('verification.php');
}

/* ---- List all providers with verification state ---- */
$providers = $pdo->query(
    "SELECT u.user_id, u.full_name, u.email, u.phone, u.status AS user_status,
            p.provider_id, p.business_name, p.business_location, p.business_phone, p.business_email,
            p.verification_status, p.verification_note, p.is_approved, p.fee_paid_until, p.created_at
     FROM providers p
     JOIN users u ON u.user_id = p.provider_id
     ORDER BY FIELD(p.verification_status,'pending','unverified','verified','rejected'), p.created_at DESC"
)->fetchAll();

$counts = ['pending' => 0, 'verified' => 0, 'unverified' => 0, 'rejected' => 0];
foreach ($providers as $pv) {
    $counts[$pv['verification_status']] = ($counts[$pv['verification_status']] ?? 0) + 1;
}

$active = 'verification';
$page_title = 'Provider Verification';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-user-check me-2"></i>Provider Verification</h2>

        <div class="row g-4 mb-4">
            <div class="col-md-3"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h5 class="fw-bold mb-0" style="color:#f0ad4e;"><?php echo $counts['pending']; ?></h5>
                <small class="text-muted">Pending Review</small></div></div>
            <div class="col-md-3"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h5 class="fw-bold mb-0" style="color:#28a745;"><?php echo $counts['verified']; ?></h5>
                <small class="text-muted">Verified</small></div></div>
            <div class="col-md-3"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h5 class="fw-bold mb-0" style="color:#0077b6;"><?php echo $counts['unverified']; ?></h5>
                <small class="text-muted">Not Submitted</small></div></div>
            <div class="col-md-3"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h5 class="fw-bold mb-0" style="color:#d9534f;"><?php echo $counts['rejected']; ?></h5>
                <small class="text-muted">Rejected</small></div></div>
        </div>
<div class="card border-0 shadow-sm rounded-4 p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead><tr><th>Provider</th><th>Business</th><th>Contact</th><th>Subscription</th><th>Status</th><th>Note</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php if (!$providers): ?>
                            <tr><td colspan="7" class="text-center text-muted py-4">No providers registered yet.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($providers as $pv): ?>
                        <tr>
                            <td>
                                <strong><?php echo e($pv['full_name']); ?></strong><br>
                                <small class="text-muted"><?php echo e($pv['email']); ?></small>
                            </td>
                            <td>
                                <strong><?php echo e($pv['business_name']); ?></strong><br>
                                <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i><?php echo e($pv['business_location'] ?: '—'); ?></small>
                            </td>
                            <td><small><?php echo e($pv['business_phone'] ?: $pv['phone']); ?><br><?php echo e($pv['business_email'] ?: '—'); ?></small></td>
                            <td>
                                <?php echo provider_subscription_active($pv) ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Not Paid</span>'; ?>
                                <?php if ($pv['fee_paid_until']): ?><small class="d-block text-muted">til <?php echo format_date($pv['fee_paid_until']); ?></small><?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $vc = $pv['verification_status'];
                                $badge = ['pending' => 'bg-warning text-dark', 'verified' => 'bg-success', 'unverified' => 'bg-secondary', 'rejected' => 'bg-danger'][$vc] ?? 'bg-secondary';
                                echo '<span class="badge ' . $badge . '">' . e(ucfirst($vc)) . '</span>';
                                if ($vc === 'verified') echo ' <i class="fas fa-check-circle text-success ms-1"></i>';
                                ?>
                            </td>
                            <td><small class="text-muted"><?php echo e($pv['verification_note'] ?: '—'); ?></small></td>
                            <td style="min-width: 260px;">
                                <form method="POST" class="row g-1">
                                    <input type="hidden" name="provider_id" value="<?php echo (int)$pv['provider_id']; ?>">
                                    <div class="col-12"><input type="text" name="note" class="form-control form-control-sm" placeholder="Note / reason (optional)"></div>
                                    <div class="col-4">
                                        <button name="action" value="approve" class="btn btn-sm btn-success w-100" <?php echo $vc === 'verified' ? 'disabled' : ''; ?>><i class="fas fa-check me-1"></i>Approve</button>
                                    </div>
                                    <div class="col-4">
                                        <button name="action" value="pending" class="btn btn-sm btn-warning w-100" <?php echo $vc === 'pending' ? 'disabled' : ''; ?>><i class="fas fa-clock me-1"></i>Request Info</button>
                                    </div>
                                    <div class="col-4">
                                        <button name="action" value="reject" class="btn btn-sm btn-danger w-100" <?php echo $vc === 'rejected' ? 'disabled' : ''; ?>><i class="fas fa-times me-1"></i>Reject</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="text-muted small mb-0 mt-2"><i class="fas fa-info-circle me-1"></i>Verified providers receive a badge on their cards for customers. Approve only after confirming their business documents/license.</p>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>