<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Broadcast notification to active users ---- */
if (($_POST['broadcast'] ?? '') === '1') {
    $target = $_POST['broadcast_target'] ?? 'all';
    $title  = trim($_POST['broadcast_title'] ?? 'Announcement');
    $msg    = trim($_POST['broadcast_msg'] ?? '');
    if ($msg === '') {
        flash('danger', 'Broadcast message cannot be empty.');
    } else {
        $sql = "SELECT user_id FROM users WHERE status = 'active'";
        if ($target === 'customers') $sql .= " AND user_type = 'customer'";
        elseif ($target === 'providers') $sql .= " AND user_type = 'provider'";
        $rows = $pdo->query($sql)->fetchAll();
        $ins = $pdo->prepare('INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)');
        foreach ($rows as $r) {
            $ins->execute([$r['user_id'], $title, $msg, 'php/notifications.php']);
        }
        lex_log_audit('broadcast_sent', 'Broadcast "' . $title . '" to ' . $target . ' (' . count($rows) . ' users)');
        flash('success', 'Broadcast sent to ' . count($rows) . ' active user(s).');
    }
    redirect('dashboard.php');
}

/* ---- Master stats ---- */
$stats = [
    'customers'   => (int)$pdo->query("SELECT COUNT(*) FROM users WHERE user_type = 'customer'")->fetchColumn(),
    'providers'   => (int)$pdo->query("SELECT COUNT(*) FROM users WHERE user_type = 'provider'")->fetchColumn(),
    'orders'      => (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'active'      => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('pending','active','in_progress','out_for_delivery')")->fetchColumn(),
    'completed'   => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('delivered','completed')")->fetchColumn(),
    'feeRevenue'  => (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM provider_payments WHERE status = 'success'")->fetchColumn(),
];
$stats['totalRevenue'] = $stats['feeRevenue'];

/* Revenue for the last 7 days (subscription fees + net completed orders) */
$byDay = [];
$rows = $pdo->query(
    "SELECT DATE(paid_at) d, SUM(amount) a FROM provider_payments
     WHERE status = 'success' AND paid_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(paid_at)"
)->fetchAll();
foreach ($rows as $r) $byDay[$r['d']] = ($byDay[$r['d']] ?? 0) + (float)$r['a'];

$chartLabels = [];
$chartData = [];
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i day"));
    $chartLabels[] = date('d M', strtotime($day));
    $chartData[] = isset($byDay[$day]) ? round($byDay[$day]) : 0;
}

/* Recent orders */
$recent = $pdo->query(
    'SELECT o.*, c.full_name AS customer_name, p.business_name
     FROM orders o
     JOIN users c ON c.user_id = o.customer_id
     JOIN providers p ON p.provider_id = o.provider_id
     ORDER BY o.created_at DESC LIMIT 6'
)->fetchAll();

$unreadSupport = get_admin_unread_support();

$active = 'dashboard';
$page_title = 'Admin Dashboard';
$load_chartjs = true;
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <!-- Stat Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                    <div class="d-flex justify-content-between">
                        <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['customers']; ?></h3><small class="text-white-50">Customers</small></div>
                        <i class="fas fa-users fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                    <div class="d-flex justify-content-between">
                        <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['providers']; ?></h3><small class="text-white-50">Providers</small></div>
                        <i class="fas fa-store fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
                    <div class="d-flex justify-content-between">
                        <div><h3 class="text-white fw-bold mb-0"><?php echo $stats['orders']; ?></h3><small class="text-white-50">Total Orders</small></div>
                        <i class="fas fa-shopping-bag fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm rounded-4 p-3" style="background: linear-gradient(135deg, #43e97b, #38f9d7);">
                    <div class="d-flex justify-content-between">
                        <div><h3 class="text-white fw-bold mb-0"><?php echo format_ugx($stats['totalRevenue']); ?></h3><small class="text-white-50">Platform Revenue</small></div>
                        <i class="fas fa-money-bill-wave fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 p-4 h-100">
                    <h5 class="fw-bold mb-3"><i class="fas fa-chart-line me-2" style="color:#0077b6"></i>Revenue (Last 7 Days)</h5>
                    <canvas id="revenueChart" style="max-height: 250px;"></canvas>
                    <hr>
                    <div class="row text-center">
                        <div class="col-4"><div class="quick-stat"><div class="number"><?php echo $stats['active']; ?></div><div class="label">Active Orders</div></div></div>
                        <div class="col-4"><div class="quick-stat"><div class="number"><?php echo $stats['completed']; ?></div><div class="label">Completed</div></div></div>
                        <div class="col-4"><div class="quick-stat"><div class="number"><?php echo format_ugx($stats['feeRevenue']); ?></div><div class="label">From Subscriptions</div></div></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 p-4 h-100">
                    <h5 class="fw-bold mb-3"><i class="fas fa-headset me-2" style="color:#f5576c"></i>Quick Actions</h5>
                    <div class="d-grid gap-2">
                        <a href="users.php" class="btn btn-outline-primary"><i class="fas fa-users me-2"></i>Manage Users</a>
                        <a href="orders.php" class="btn btn-outline-primary"><i class="fas fa-shopping-bag me-2"></i>View Orders</a>
                        <a href="support.php" class="btn btn-outline-primary"><i class="fas fa-headset me-2"></i>Support Messages <?php if ($unreadSupport): ?><span class="badge bg-danger ms-1"><?php echo $unreadSupport; ?></span><?php endif; ?></a>
                        <a href="system_config.php" class="btn btn-outline-primary"><i class="fas fa-cog me-2"></i>System Config</a>
                    </div>
                </div>

                <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-bullhorn me-2" style="color:#0077b6;"></i>Broadcast Notification</h5>
                    <form method="POST">
                        <div class="mb-2">
                            <select name="broadcast_target" class="form-select">
                                <option value="all">All active users</option>
                                <option value="customers">All customers</option>
                                <option value="providers">All providers</option>
                            </select>
                        </div>
                        <div class="mb-2"><input type="text" name="broadcast_title" class="form-control" placeholder="Title (e.g. Holiday Promotion)" value="Announcement"></div>
                        <div class="mb-2"><textarea name="broadcast_msg" class="form-control" rows="3" placeholder="Message..." required></textarea></div>
                        <button name="broadcast" value="1" class="btn btn-primary w-100"><i class="fas fa-paper-plane me-2"></i>Send Broadcast</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-clock me-2" style="color:#0077b6"></i>Recent Orders</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>ID</th><th>Customer</th><th>Provider</th><th>Total</th><th>Fee</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($recent as $o): ?>
                        <tr>
                            <td><?php echo order_code($o['order_id']); ?></td>
                            <td><?php echo e($o['customer_name']); ?></td>
                            <td><?php echo e($o['business_name']); ?></td>
                            <td><?php echo format_ugx($o['total_price']); ?></td>
                            <td><?php echo format_ugx($o['platform_deduction']); ?></td>
                            <td><?php echo status_badge($o['status']); ?></td>
                            <td><?php echo format_date($o['created_at']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div></div>
<script>
    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chartLabels); ?>,
            datasets: [{
                label: 'Revenue (UGX)',
                data: <?php echo json_encode($chartData); ?>,
                backgroundColor: '#0077b6',
                borderRadius: 5
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
</script>
<?php $close_layout = false; include BASE_PATH . '/php/partials/footer.php'; ?>
