<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Summary stats ---- */
$customers  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE user_type = 'customer'")->fetchColumn();
$providers  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE user_type = 'provider'")->fetchColumn();
$ordersAll  = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$ordersComp = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('delivered','completed')")->fetchColumn();
$revenue    = (float)$pdo->query("SELECT COALESCE(SUM(total_price),0) FROM orders WHERE status IN ('delivered','completed')")->fetchColumn();
$feeRev     = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM provider_payments WHERE status = 'success'")->fetchColumn();
$aov        = $ordersComp > 0 ? round($revenue / $ordersComp) : 0;

/* ---- Orders per day (last 14 days) ---- */
$byDay = [];
foreach ($pdo->query('SELECT DATE(created_at) d, COUNT(*) c FROM orders WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY) GROUP BY DATE(created_at)') as $r) {
    $byDay[$r['d']] = (int)$r['c'];
}
$labels = []; $data = [];
for ($i = 13; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-$i day"));
    $labels[] = date('d M', strtotime($day));
    $data[] = $byDay[$day] ?? 0;
}

/* ---- Top providers ---- */
$topProviders = $pdo->query(
    "SELECT p.business_name,
            COUNT(CASE WHEN o.status IN ('delivered','completed') THEN 1 END) AS completed,
            COUNT(o.order_id) AS total_orders,
            COALESCE(AVG(r.rating),0) AS avg_rating
     FROM providers p
     LEFT JOIN orders o ON o.provider_id = p.provider_id
     LEFT JOIN reviews r ON r.provider_id = p.provider_id
     GROUP BY p.provider_id, p.business_name
     ORDER BY completed DESC LIMIT 6"
)->fetchAll();

/* ---- Churn: customers inactive 30+ days ---- */
$churn = $pdo->query(
    "SELECT u.user_id, u.full_name, u.email, u.location,
            (SELECT COUNT(*) FROM orders o WHERE o.customer_id = u.user_id) AS total_orders,
            (SELECT MAX(created_at) FROM orders o WHERE o.customer_id = u.user_id) AS last_order
     FROM users u
     WHERE u.user_type = 'customer'
       AND (SELECT COUNT(*) FROM orders o WHERE o.customer_id = u.user_id) > 0
       AND (SELECT MAX(created_at) FROM orders o WHERE o.customer_id = u.user_id) < DATE_SUB(NOW(), INTERVAL 30 DAY)
     ORDER BY last_order DESC"
)->fetchAll();

/* ---- Smart admin alerts ---- */
$alerts = [];
$overdue = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending' AND created_at < DATE_SUB(NOW(), INTERVAL 2 DAY)")->fetchColumn();
if ($overdue) $alerts[] = ['type' => 'danger', 'icon' => 'fa-clock', 'msg' => $overdue . ' pending order(s) waiting over 48 hours.'];
if ($pdo->query("SHOW TABLES LIKE 'disputes'")->rowCount()) {
    $openD = (int)$pdo->query("SELECT COUNT(*) FROM disputes WHERE status IN ('open','in_review')")->fetchColumn();
    if ($openD) $alerts[] = ['type' => 'warning', 'icon' => 'fa-shield-halved', 'msg' => $openD . ' dispute(s) are still open.'];
}
$pendingV = (int)$pdo->query("SELECT COUNT(*) FROM providers WHERE verification_status = 'pending'")->fetchColumn();
if ($pendingV) $alerts[] = ['type' => 'info', 'icon' => 'fa-user-check', 'msg' => $pendingV . ' provider(s) waiting for verification.'];
$unpaidDelivered = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE payment_status IN ('pending','paid') AND status = 'delivered'")->fetchColumn();
if ($unpaidDelivered) $alerts[] = ['type' => 'warning', 'icon' => 'fa-money-bill-wave', 'msg' => $unpaidDelivered . ' delivered order(s) with unconfirmed payment.'];

$active = 'analytics';
$page_title = 'Advanced Analytics';
$load_chartjs = true;
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-chart-bar me-2"></i>Advanced Analytics</h2>
<div class="row g-4 mb-4">
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3" style="background:linear-gradient(135deg,#667eea,#764ba2);">
                <h3 class="text-white fw-bold mb-0"><?php echo $customers; ?></h3><small class="text-white-50">Customers</small></div></div>
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3" style="background:linear-gradient(135deg,#f093fb,#f5576c);">
                <h3 class="text-white fw-bold mb-0"><?php echo $providers; ?></h3><small class="text-white-50">Providers</small></div></div>
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3" style="background:linear-gradient(135deg,#4facfe,#00f2fe);">
                <h3 class="text-white fw-bold mb-0"><?php echo $ordersAll; ?></h3><small class="text-white-50">Total Orders</small></div></div>
            <div class="col-md-3 col-6"><div class="card border-0 shadow-sm rounded-4 p-3" style="background:linear-gradient(135deg,#43e97b,#38f9d7);">
                <h3 class="text-white fw-bold mb-0"><?php echo format_ugx($aov); ?></h3><small class="text-white-50">Avg Order Value</small></div></div>
        </div>
        <div class="row g-4 mb-4">
            <div class="col-md-4"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h3 class="fw-bold mb-0" style="color:#0077b6;"><?php echo $ordersComp; ?></h3><small class="text-muted">Completed Orders</small></div></div>
            <div class="col-md-4"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h3 class="fw-bold mb-0" style="color:#28a745;"><?php echo format_ugx($revenue); ?></h3><small class="text-muted">Gross Order Value</small></div></div>
            <div class="col-md-4"><div class="card border-0 shadow-sm rounded-4 p-3 text-center">
                <h3 class="fw-bold mb-0" style="color:#f5576c;"><?php echo format_ugx($feeRev); ?></h3><small class="text-muted">Subscription Revenue</small></div></div>
        </div>

        <?php if ($alerts): ?>
        <div class="mb-4">
            <?php foreach ($alerts as $a): ?>
            <div class="alert alert-<?php echo $a['type']; ?> shadow-sm rounded-4 d-flex align-items-center">
                <i class="fas <?php echo $a['icon']; ?> fa-lg me-3"></i><span><?php echo e($a['msg']); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-chart-line me-2" style="color:#0077b6;"></i>Orders (Last 14 Days)</h5>
                    <canvas id="ordersChart" style="max-height:250px;"></canvas>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 p-4 h-100">
                    <h5 class="fw-bold mb-3"><i class="fas fa-trophy me-2" style="color:#f0ad4e;"></i>Top Providers</h5>
                    <?php if (!$topProviders): ?><p class="text-muted text-center py-4 mb-0">No provider data yet.</p><?php endif; ?>
                    <?php foreach ($topProviders as $i => $tp): ?>
                    <div class="d-flex align-items-center mb-3">
                        <div class="me-3 fs-5 fw-bold text-muted" style="width:22px;"><?php echo $i + 1; ?></div>
                        <div class="flex-grow-1">
                            <strong><?php echo e($tp['business_name']); ?></strong>
                            <div class="progress" style="height:6px;"><div class="progress-bar bg-primary" style="width:<?php echo $tp['total_orders'] ? round(($tp['completed'] / $tp['total_orders']) * 100) : 0; ?>%"></div></div>
                            <small class="text-muted"><?php echo (int)$tp['completed']; ?> completed · <?php echo star_icons($tp['avg_rating'], true); ?></small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mt-4 p-4">
            <h5 class="fw-bold mb-3"><i class="fas fa-user-slash me-2" style="color:#d9534f;"></i>Potential Churn — Customers Inactive 30+ Days</h5>
            <?php if (!$churn): ?>
                <p class="text-muted mb-0">Great news — no customers have gone silent in the last 30 days.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Name</th><th>Email</th><th>Location</th><th>Total Orders</th><th>Last Order</th></tr></thead>
                    <tbody>
                        <?php foreach ($churn as $c): ?>
                        <tr>
                            <td><?php echo e($c['full_name']); ?></td>
                            <td><?php echo e($c['email']); ?></td>
                            <td><?php echo e($c['location'] ?: '—'); ?></td>
                            <td><?php echo (int)$c['total_orders']; ?></td>
                            <td><?php echo format_date($c['last_order']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <small class="text-muted"><i class="fas fa-lightbulb me-1"></i>Tip: target these customers with a promo code (see Promotions) or an in-app notification.</small>
            <?php endif; ?>
        </div>
    </main>
</div></div>
<script>
    const ctx = document.getElementById('ordersChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Orders',
                data: <?php echo json_encode($data); ?>,
                borderColor: '#0077b6',
                backgroundColor: 'rgba(0,119,182,0.12)',
                fill: true,
                tension: 0.35
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
</script>
<?php $close_layout = false; include BASE_PATH . '/php/partials/footer.php'; ?>