<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

/* ---- Save configuration ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_fees'])) {
        // Per-order platform deduction removed - only the monthly subscription remains.
        $subscription = max(0, (float)($_POST['subscription_fee'] ?? 2500));
        set_config('provider_subscription_fee', (string)$subscription);
        flash('success', 'Subscription fee settings saved. New subscriptions will use the updated amount.');
    }
    if (isset($_POST['save_general'])) {
        set_config('site_name', trim($_POST['site_name'] ?? 'LaundryExpress Uganda'));
        set_config('support_email', trim($_POST['support_email'] ?? ''));
        set_config('support_phone', trim($_POST['support_phone'] ?? ''));
        flash('success', 'General settings saved.');
    }
    if (isset($_POST['save_feature_flags'])) {
        $flags = ['assistant','repeat','recurring','compare','loyalty','streaks','referrals','wallet','qr_tracking','evidence','disputes','promotions','driver','verification'];
        foreach ($flags as $f) {
            $enabled = !empty($_POST['flag_' . $f]) ? 1 : 0;
            $pdo->prepare('INSERT INTO feature_flags (flag_key, label, enabled) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE enabled = VALUES(enabled)')
                ->execute([$f, $f, $enabled]);
        }
        lex_log_audit('feature_flags_updated', 'Admin updated feature flags');
        flash('success', 'Feature flags updated successfully.');
    }
    redirect('system_config.php');
}

$rules = json_decode(get_config('revenue_deduction', '{"below_5000":0,"above_5000":0}'), true) ?: [];
$below = $rules['below_5000'] ?? 0;
$above = $rules['above_5000'] ?? 0;
$monthlyFee = get_subscription_fee();
$siteName = get_config('site_name', 'LaundryExpress Uganda');
$supportEmail = get_config('support_email', 'support@laundryexpress.ug');
$supportPhone = get_config('support_phone', '+256 700 123456');

$pdo = $GLOBALS['pdo'];
$orderRevenue = (float)$pdo->query('SELECT COALESCE(SUM(amount), 0) FROM platform_revenue')->fetchColumn();
$feeRevenue = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM provider_payments WHERE status = 'success'")->fetchColumn();

$flagMap = [];
foreach ($pdo->query('SELECT flag_key, enabled, label FROM feature_flags') as $fr) {
    $flagMap[$fr['flag_key']] = (int)$fr['enabled'];
}

$active = 'config';
$page_title = 'System Config';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <!-- Revenue summary -->
        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h6 class="text-muted mb-1">Revenue from Provider Subscriptions</h6>
                    <h3 class="fw-bold mb-0" style="color: #28a745;"><?php echo format_ugx($feeRevenue); ?></h3>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h6 class="text-muted mb-1">Registered Providers</h6>
                    <h3 class="fw-bold mb-0" style="color: #0077b6;"><?php echo (int)$pdo->query("SELECT COUNT(*) FROM providers")->fetchColumn(); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-money-bill-wave me-2" style="color:#0077b6"></i>Provider Monthly Subscription</h5>
                    <p class="text-muted small mb-3"><i class="fas fa-info-circle me-1"></i>Providers pay this amount every 30 days to accept and manage orders. The per-order platform deduction (UGX 500 / 1000) has been removed.</p>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Monthly Subscription Fee (UGX)</label>
                            <input type="number" name="subscription_fee" class="form-control" value="<?php echo (float)$monthlyFee; ?>" min="0" step="500">
                            <small class="text-muted">e.g. UGX 2,500 per month. Increase or reduce it here anytime.</small>
                        </div>
                        <button type="submit" name="save_fees" value="1" class="btn btn-primary w-100"><i class="fas fa-save me-2"></i>Save Subscription Fee</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-4"><i class="fas fa-globe me-2" style="color:#0077b6"></i>General Settings</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Site Name</label>
                            <input type="text" name="site_name" class="form-control" value="<?php echo e($siteName); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Support Email</label>
                            <input type="email" name="support_email" class="form-control" value="<?php echo e($supportEmail); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Support Phone</label>
                            <input type="tel" name="support_phone" class="form-control" value="<?php echo e($supportPhone); ?>">
                        </div>
                        <button type="submit" name="save_general" value="1" class="btn btn-primary w-100"><i class="fas fa-save me-2"></i>Save Settings</button>
                    </form>
                </div>

                <div class="card border-0 shadow-sm rounded-4 p-4 mt-4">
                    <h5 class="fw-bold mb-3"><i class="fab fa-google me-2" style="color:#f5576c"></i>Google Sign-In</h5>
                    <p class="text-muted small mb-2">The "Continue with Google" buttons activate automatically once you paste your Google OAuth Client ID into <code>php/includes/config.php</code> (the <code>GOOGLE_CLIENT_ID</code> constant).</p>
                    <p class="text-muted small mb-0">Current status: <span class="badge <?php echo GOOGLE_CLIENT_ID ? 'bg-success' : 'bg-warning text-dark'; ?>"><?php echo GOOGLE_CLIENT_ID ? 'Configured' : 'Not configured (buttons show a setup hint)'; ?></span></p>
                </div>
            </div>
        </div>

    <div class="card border-0 shadow-sm rounded-4 p-4 mt-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-toggle-on me-2" style="color:#0077b6;"></i>Feature Flags</h5>
                    <p class="text-muted small mb-3">Turn optional platform features on or off without touching any code. Changes apply instantly to customer/provider menus and pages.</p>
                    <form method="POST">
                        <div class="row g-3">
                        <?php
                        $flagLabels = [
                            'assistant'    => ['Smart Laundry Assistant', 'AI-style assistant that suggests services & prices from normal language'],
                            'repeat'       => ['Repeat My Last Order', 'One-click recreation of a previous order'],
                            'recurring'    => ['Automatic Laundry Schedule', 'Weekly/biweekly/monthly recurring schedules with reminders'],
                            'compare'      => ['Smart Price Comparison', 'Compare providers by price, rating, speed & reliability'],
                            'loyalty'      => ['Customer Loyalty System', 'Earn points per completed order'],
                            'streaks'      => ['Laundry Streaks', 'Track consecutive qualifying orders'],
                            'referrals'    => ['Referral System', 'Referral codes with rewards for referrer & friend'],
                            'wallet'       => ['Laundry Wallet', 'Digital wallet for refunds, credits & rewards'],
                            'qr_tracking'  => ['QR Order Tracking', 'QR code on each order for scan-to-track'],
                            'evidence'     => ['Before/After Garment Evidence', 'Providers attach photos at pickup & delivery'],
                            'disputes'     => ['Laundry Protection / Disputes', 'Customers can report missing/ damaged items'],
                            'promotions'   => ['Promotion Engine', 'Discount codes, vouchers & campaigns'],
                            'driver'       => ['Driver Assignment', 'Assign a driver name & phone per order'],
                            'verification' => ['Provider Verification', 'Badge & admin review for verified businesses'],
                        ];
                        foreach ($flagLabels as $key => $info):
                            $on = !empty($flagMap[$key]);
                        ?>
                        <div class="col-md-6">
                            <div class="form-check form-switch border rounded-3 p-3 mb-0">
                                <input class="form-check-input" type="checkbox" name="flag_<?php echo $key; ?>" id="flag_<?php echo $key; ?>" value="1" <?php echo $on ? 'checked' : ''; ?>>
                                <label class="form-check-label fw-bold" for="flag_<?php echo $key; ?>"><?php echo e($info[0]); ?></label>
                                <small class="d-block text-muted mt-1"><?php echo e($info[1]); ?></small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        </div>
                        <button type="submit" name="save_feature_flags" value="1" class="btn btn-primary mt-4"><i class="fas fa-save me-2"></i>Save Feature Flags</button>
                    </form>
                </div>

    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
