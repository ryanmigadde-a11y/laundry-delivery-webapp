<?php
/** Admin Promotion Engine — create discount codes with min-order, expiry, usage limits. */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_promo'])) {
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $type = ($_POST['type'] ?? 'percent') === 'fixed' ? 'fixed' : 'percent';
    $value = (float)($_POST['value'] ?? 0);
    $minOrder = (float)($_POST['min_order'] ?? 0);
    $maxUses = max(1, (int)($_POST['max_uses'] ?? 100));
    $expires = trim($_POST['expires_at'] ?? '') ?: null;
    if ($code === '' || $value <= 0) {
        flash('danger', 'Code and value are required.');
    } else {
        $pdo->prepare('INSERT INTO promotions (code, type, value, min_order, max_uses, expires_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$code, $type, $value, $minOrder, $maxUses, $expires]);
        audit_log('promo_created', 'Promo ' . $code . ' (' . $value . ($type === 'percent' ? '%' : ' fixed') . ')');
        flash('success', 'Promotion ' . $code . ' created.');
    }
    redirect('promotions.php');
}

if (isset($_POST['toggle_promo'])) {
    $pdo->prepare('UPDATE promotions SET active = 1 - active WHERE promo_id = ?')->execute([(int)$_POST['toggle_promo']]);
    redirect('promotions.php');
}
if (isset($_POST['delete_promo'])) {
    $pdo->prepare('DELETE FROM promotions WHERE promo_id = ?')->execute([(int)$_POST['delete_promo']]);
    redirect('promotions.php');
}

$promos = $pdo->query('SELECT * FROM promotions ORDER BY created_at DESC')->fetchAll();

$active = 'promotions';
$page_title = 'Promotions';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-gift me-2"></i>Promotion Engine</h2>

        <div class="row g-4">
            <div class="col-md-5">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-plus-circle me-2" style="color:#28a745;"></i>Create Discount Code</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Code</label>
                            <input type="text" name="code" class="form-control" placeholder="e.g. WELCOME10" required>
                        </div>
                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <label class="form-label small fw-bold">Type</label>
                                <select name="type" class="form-select">
                                    <option value="percent">Percentage (%)</option>
                                    <option value="fixed">Fixed Amount (UGX)</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-bold">Value</label>
                                <input type="number" name="value" class="form-control" min="0.01" step="0.01" required>
                            </div>
                        </div>
                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <label class="form-label small fw-bold">Min Order (UGX)</label>
                                <input type="number" name="min_order" class="form-control" value="0" min="0">
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-bold">Max Uses</label>
                                <input type="number" name="max_uses" class="form-control" value="100" min="1">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Expires (optional)</label>
                            <input type="date" name="expires_at" class="form-control">
                        </div>
                        <button name="create_promo" value="1" class="btn btn-primary w-100"><i class="fas fa-tag me-2"></i>Create Promotion</button>
                    </form>
                </div>
            </div>
            <div class="col-md-7">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-list me-2" style="color:#0077b6;"></i>Active Codes</h5>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min Order</th><th>Used</th><th>Expires</th><th>State</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php if (!$promos): ?>
                                    <tr><td colspan="8" class="text-center text-muted py-4">No promotions yet. Create your first discount code.</td></tr>
                                <?php endif; ?>
                                <?php foreach ($promos as $pp): ?>
                                <tr>
                                    <td><strong><?php echo e($pp['code']); ?></strong></td>
                                    <td><?php echo $pp['type'] === 'percent' ? '%' : 'UGX'; ?></td>
                                    <td class="fw-bold"><?php echo $pp['type'] === 'percent' ? (float)$pp['value'] . '%' : format_ugx($pp['value']); ?></td>
                                    <td><?php echo format_ugx($pp['min_order']); ?></td>
                                    <td><?php echo (int)$pp['used_count']; ?> / <?php echo (int)$pp['max_uses']; ?></td>
                                    <td><?php echo $pp['expires_at'] ? format_date($pp['expires_at']) : '—'; ?></td>
                                    <td><?php echo $pp['active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Off</span>'; ?></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <button name="toggle_promo" value="<?php echo (int)$pp['promo_id']; ?>" class="btn btn-sm <?php echo $pp['active'] ? 'btn-warning' : 'btn-success'; ?>"><?php echo $pp['active'] ? 'Disable' : 'Enable'; ?></button>
                                        </form>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this promo code?');">
                                            <button name="delete_promo" value="<?php echo (int)$pp['promo_id']; ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <small class="text-muted"><i class="fas fa-info-circle me-1"></i>Customers enter the code on the payment page. Promo discount is applied automatically when valid.</small>
                </div>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>