<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

$filter = trim($_GET['action'] ?? '');

/* ---- List audit log entries joined with the admin name ---- */
$sql = 'SELECT al.*, u.full_name AS admin_name
        FROM audit_log al
        LEFT JOIN users u ON u.user_id = al.admin_id
        WHERE 1=1';
$params = [];
if ($filter !== '') {
    $sql .= ' AND al.action LIKE ?';
    $params[] = '%' . $filter . '%';
}
$sql .= ' ORDER BY al.created_at DESC LIMIT 200';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

/* Distinct action types for the filter dropdown */
$actions = $pdo->query('SELECT DISTINCT action FROM audit_log ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);

$active = 'audit';
$page_title = 'Admin Audit Log';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-history me-2"></i>Admin Audit Log</h2>

        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-8">
                    <label class="form-label small mb-1">Filter by action</label>
                    <select name="action" class="form-select">
                        <option value="">All actions</option>
                        <?php foreach ($actions as $a): ?>
                            <option value="<?php echo e($a); ?>" <?php echo $a === $filter ? 'selected' : ''; ?>><?php echo e($a); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-primary w-100"><i class="fas fa-filter me-2"></i>Filter</button>
                </div>
            </form>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Date</th><th>Admin</th><th>Action</th><th>Details</th></tr></thead>
                    <tbody>
                        <?php if (!$logs): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No audit entries yet. Actions such as verification changes, suspensions, config edits and dispute resolutions will appear here.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($logs as $l): ?>
                        <tr>
                            <td><?php echo format_date($l['created_at']); ?></td>
                            <td><?php echo e($l['admin_name'] ?: 'System'); ?></td>
                            <td><span class="badge bg-primary"><?php echo e($l['action']); ?></span></td>
                            <td class="text-muted small"><?php echo e($l['details']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>