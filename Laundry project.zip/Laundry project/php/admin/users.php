<?php
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Admin actions ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['user_id'] ?? 0);

    if ($action === 'suspend' || $action === 'activate') {
        $status = $action === 'suspend' ? 'suspended' : 'active';
        $pdo->prepare('UPDATE users SET status = ? WHERE user_id = ?')->execute([$status, $userId]);
        flash('success', 'User ' . ($action === 'suspend' ? 'suspended' : 'activated') . ' successfully.');
    }

    if ($action === 'approve_provider') {
        $pdo->prepare('UPDATE providers SET is_approved = 1 WHERE provider_id = ?')->execute([$userId]);
        add_notification($userId, 'Business Approved', 'Your laundry business has been approved. Customers can now find you!', 'php/provider/dashboard.php');
        flash('success', 'Provider approved successfully.');
    }

    if ($action === 'delete') {
        $pdo->prepare('DELETE FROM users WHERE user_id = ?')->execute([$userId]);
        flash('success', 'User deleted permanently (their orders and data were removed).');
    }
    redirect('users.php');
}

$customers = $pdo->query("SELECT * FROM users WHERE user_type = 'customer' ORDER BY created_at DESC")->fetchAll();
$providers = $pdo->query(
    "SELECT u.*, p.business_name, p.business_location, p.is_approved, p.fee_paid_until
     FROM users u JOIN providers p ON p.provider_id = u.user_id
     WHERE u.user_type = 'provider'
     ORDER BY u.created_at DESC"
)->fetchAll();

$active = 'users';
$page_title = 'User Management';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-users me-2"></i>User Management</h2>
        <ul class="nav nav-tabs mb-4" id="userTabs">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#customers">Customers (<?php echo count($customers); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#providers">Providers (<?php echo count($providers); ?>)</button></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="customers">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php foreach ($customers as $c): ?>
                                <tr>
                                    <td><?php echo (int)$c['user_id']; ?></td>
                                    <td><?php echo e($c['full_name']); ?></td>
                                    <td><?php echo e($c['email']); ?></td>
                                    <td><?php echo e($c['phone']); ?></td>
                                    <td><?php echo e($c['location']); ?></td>
                                    <td><span class="badge <?php echo $c['status'] === 'active' ? 'bg-success' : 'bg-danger'; ?>"><?php echo e(ucfirst($c['status'])); ?></span></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$c['user_id']; ?>">
                                            <button name="action" value="<?php echo $c['status'] === 'active' ? 'suspend' : 'activate'; ?>" class="btn btn-sm <?php echo $c['status'] === 'active' ? 'btn-warning' : 'btn-success'; ?>">
                                                <?php echo $c['status'] === 'active' ? 'Suspend' : 'Activate'; ?>
                                            </button>
                                        </form>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this user and all their data? This cannot be undone.');">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$c['user_id']; ?>">
                                            <button name="action" value="delete" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (!$customers): ?><tr><td colspan="7" class="text-center text-muted py-4">No customers yet.</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="providers">
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><tr><th>ID</th><th>Business</th><th>Name</th><th>Email</th><th>Phone</th><th>Approved</th><th>Subscription</th><th>Status</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php foreach ($providers as $p): ?>
                                <tr>
                                    <td><?php echo (int)$p['user_id']; ?></td>
                                    <td><strong><?php echo e($p['business_name']); ?></strong><br><small class="text-muted"><?php echo e($p['business_location']); ?></small></td>
                                    <td><?php echo e($p['full_name']); ?></td>
                                    <td><?php echo e($p['email']); ?></td>
                                    <td><?php echo e($p['phone']); ?></td>
                                    <td><?php echo $p['is_approved'] ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-danger"></i>'; ?></td>
                                    <td><?php echo provider_subscription_active($p) ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Expired</span>'; ?>
                                        <?php if ($p['fee_paid_until']): ?><small class="d-block text-muted"><?php echo format_date($p['fee_paid_until']); ?></small><?php endif; ?></td>
                                    <td><span class="badge <?php echo $p['status'] === 'active' ? 'bg-success' : 'bg-danger'; ?>"><?php echo e(ucfirst($p['status'])); ?></span></td>
                                    <td>
                                        <?php if (!$p['is_approved']): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$p['user_id']; ?>">
                                            <button name="action" value="approve_provider" class="btn btn-sm btn-success">Approve</button>
                                        </form>
                                        <?php endif; ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$p['user_id']; ?>">
                                            <button name="action" value="<?php echo $p['status'] === 'active' ? 'suspend' : 'activate'; ?>" class="btn btn-sm <?php echo $p['status'] === 'active' ? 'btn-warning' : 'btn-success'; ?>">
                                                <?php echo $p['status'] === 'active' ? 'Suspend' : 'Activate'; ?>
                                            </button>
                                        </form>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('Delete this provider and all their data? This cannot be undone.');">
                                            <input type="hidden" name="user_id" value="<?php echo (int)$p['user_id']; ?>">
                                            <button name="action" value="delete" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (!$providers): ?><tr><td colspan="9" class="text-center text-muted py-4">No providers yet.</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>
