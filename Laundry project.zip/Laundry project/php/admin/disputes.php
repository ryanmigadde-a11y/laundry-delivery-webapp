<?php
/**
 * Admin Dispute Center — see every customer complaint with the full order
 * context, send a note to the provider, change status and resolve/reject with
 * an optional wallet refund to the customer.
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';
require_admin_page($BASE);

$pdo = $GLOBALS['pdo'];

/* ---- Admin actions ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action    = $_POST['action'] ?? '';
    $disputeId = (int)($_POST['dispute_id'] ?? 0);

    $d = null;
    if ($disputeId) {
        $stmt = $pdo->prepare('SELECT * FROM disputes WHERE dispute_id = ? LIMIT 1');
        $stmt->execute([$disputeId]);
        $d = $stmt->fetch();
    }

    if ($disputeId && $d) {
        if ($action === 'update') {
            $newStatus = in_array($_POST['status'] ?? '', ['open', 'in_review', 'resolved', 'rejected'], true) ? $_POST['status'] : 'open';
            $note = trim($_POST['admin_note'] ?? '');

            /* Resolving with a refund credits the customer's wallet. */
            $refund = 0;
            if ($newStatus === 'resolved') {
                $refund = max(0, (float)($_POST['refund_amount'] ?? 0));
                if ($refund > 0) {
                    wallet_tx((int)$d['customer_id'], $refund, 'credit', 'Dispute ' . $d['dispute_code'] . ' refund');
                }
            }

            $pdo->prepare('UPDATE disputes SET status = ?, admin_note = ?, refund_amount = ?, resolved_at = ? WHERE dispute_id = ?')
                ->execute([$newStatus, $note ?: null, $refund, ($newStatus === 'resolved' || $newStatus === 'rejected') ? date('Y-m-d H:i:s') : null, $disputeId]);

            /* Notify the customer. */
            $orderCode = order_code((int)$d['order_id']);
            $notifMsg = 'Your dispute ' . $d['dispute_code'] . ' for ' . $orderCode . ' is now "' . str_replace('_', ' ', $newStatus) . '".'
                . ($note !== '' ? ' Admin: ' . $note : '')
                . ($refund > 0 ? ' A refund of ' . format_ugx($refund) . ' was credited to your wallet.' : '');
            add_notification((int)$d['customer_id'], 'Dispute Update', $notifMsg, 'php/customer/disputes.php');
            add_notification((int)$d['provider_id'], 'Dispute Update', 'Dispute ' . $d['dispute_code'] . ' (' . $orderCode . ') is "' . str_replace('_', ' ', $newStatus) . '".' . ($note !== '' ? ' ' . $note : ''), 'php/provider/dashboard.php');

            /* Point the provider at it for resolution. */
            if (isset($_POST['send_to_provider'])) {
                add_notification((int)$d['provider_id'], 'Dispute Assigned to You', 'Please review and resolve dispute ' . $d['dispute_code'] . ' for ' . $orderCode . '. ' . $note, 'php/provider/orders.php');
            }

            log_audit('dispute_' . $newStatus, 'Dispute ' . $d['dispute_code'] . ' => ' . $newStatus . ' refund ' . $refund . (string)$note);
            flash('success', 'Dispute updated.');
        }

        if ($action === 'delete') {
            $pdo->prepare('DELETE FROM disputes WHERE dispute_id = ?')->execute([$disputeId]);
            log_audit('dispute_deleted', 'Dispute ' . ($d['dispute_code'] ?? $disputeId) . ' deleted');
            flash('success', 'Dispute record deleted.');
        }

        if ($action === 'reply') {
            $msg = trim($_POST['reply_message'] ?? '');
            if ($msg === '') {
                flash('warning', 'Type a reply first.');
            } else {
                add_dispute_message($disputeId, 'admin', isset($_SESSION['admin_user_id']) ? (int)$_SESSION['admin_user_id'] : null, $msg);
                add_notification((int)$d['customer_id'], 'Admin Reply', 'An admin replied on dispute ' . $d['dispute_code'] . '.', 'php/customer/disputes.php');
                add_notification((int)$d['provider_id'], 'Admin Reply', 'An admin replied on dispute ' . $d['dispute_code'] . '.', 'php/provider/disputes.php');
                log_audit('dispute_reply', 'Admin replied on dispute ' . $d['dispute_code']);
                flash('success', 'Reply sent to the customer and provider.');
            }
        }
    }
    redirect('disputes.php');
}
/* ---- List all disputes with order + customer + provider context ---- */
$disputes = $pdo->query(
    "SELECT d.*, o.status AS order_status, o.total_price, o.created_at AS order_created,
            c.full_name AS customer_name, c.email AS customer_email, c.phone AS customer_phone,
            p.business_name, p.business_phone
     FROM disputes d
     JOIN orders o ON o.order_id = d.order_id
     JOIN users c ON c.user_id = d.customer_id
     JOIN providers p ON p.provider_id = d.provider_id
     ORDER BY FIELD(d.status,'open','in_review','resolved','rejected'), d.created_at DESC"
)->fetchAll();

$counts = ['open' => 0, 'in_review' => 0, 'resolved' => 0, 'rejected' => 0];
foreach ($disputes as $dd) $counts[$dd['status']] = ($counts[$dd['status']] ?? 0) + 1;

$types = ['missing_item' => 'Missing Item', 'damage' => 'Damage', 'poor_cleaning' => 'Poor Cleaning', 'late_delivery' => 'Late Delivery', 'wrong_item' => 'Wrong Item', 'other' => 'Other'];
$typeIcons = ['missing_item' => 'fa-box-open', 'damage' => 'fa-triangle-exclamation', 'poor_cleaning' => 'fa-soap', 'late_delivery' => 'fa-clock', 'wrong_item' => 'fa-shuffle', 'other' => 'fa-circle-question'];

/* ---- Status filter ---- */
$filter = $_GET['filter'] ?? 'all';
$validFilters = ['all', 'open', 'in_review', 'resolved', 'rejected'];
if (!in_array($filter, $validFilters, true)) $filter = 'all';
$filteredDisputes = $filter === 'all' ? $disputes : array_filter($disputes, fn($d) => $d['status'] === $filter);

$active = 'disputes';
$page_title = 'Dispute Center';
include BASE_PATH . '/php/partials/header.php';
?>
<div class="container-fluid"><div class="row">
    <?php include BASE_PATH . '/php/partials/admin_sidebar.php'; ?>
    <main class="col ms-0 p-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-shield-halved me-2"></i>Dispute / Laundry Protection Center</h2>

        <!-- Status filter tabs -->
        <div class="d-flex flex-wrap gap-2 mb-4">
            <?php
            $filterLabels = ['all' => 'All', 'open' => 'Open', 'in_review' => 'In Review', 'resolved' => 'Resolved', 'rejected' => 'Rejected'];
            foreach ($filterLabels as $fk => $fl):
                $isActive = $filter === $fk;
                $btnClass = $isActive ? 'btn-primary' : 'btn-outline-secondary';
                $count = $fk === 'all' ? count($disputes) : ($counts[$fk] ?? 0);
            ?>
            <a href="?filter=<?php echo $fk; ?>" class="btn <?php echo $btnClass; ?> btn-sm">
                <?php echo $fl; ?> <span class="badge <?php echo $isActive ? 'bg-light text-primary' : 'bg-secondary'; ?> ms-1"><?php echo $count; ?></span>
            </a>
            <?php endforeach; ?>
        </div>

        <?php if (!$disputes): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-shield-halved fa-3x text-muted mb-3"></i>
                <p class="text-muted mb-0">No disputes submitted yet.</p>
            </div>
        <?php endif; ?>

        <?php if ($filter !== 'all' && empty($filteredDisputes)): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <p class="text-muted mb-0">No <?php echo str_replace('_', ' ', $filter); ?> disputes.</p>
            </div>
        <?php endif; ?>

<?php $i = 0; foreach ($filteredDisputes as $dd): $i++; ?>
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4 position-relative">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                <div>
                    <h5 class="fw-bold mb-0">
                        <i class="fas <?php echo $typeIcons[$dd['type']] ?? 'fa-circle-question'; ?> me-2" style="color:#0077b6;"></i>
                        <span class="text-primary"><?php echo e($dd['dispute_code']); ?></span>
                        <small class="text-muted">· <?php echo e($types[$dd['type']] ?? $dd['type']); ?> · <?php echo format_date($dd['created_at']); ?></small>
                    </h5>
                    <small class="text-muted">
                        order <?php echo order_code((int)$dd['order_id']); ?> &nbsp;·&nbsp; <?php echo format_ugx($dd['total_price']); ?> &nbsp;·&nbsp;
                        <i class="fas fa-user me-1"></i><?php echo e($dd['customer_name']); ?> (<?php echo e($dd['customer_phone'] ?: 'no phone'); ?>)
                        &nbsp;·&nbsp; <i class="fas fa-store me-1"></i><?php echo e($dd['business_name']); ?> (<?php echo e($dd['business_phone'] ?: 'no phone'); ?>)
                    </small>
                </div>
                <div>
                    <?php
                    $sc = ['open' => 'bg-danger', 'in_review' => 'bg-warning text-dark', 'resolved' => 'bg-success', 'rejected' => 'bg-secondary'][$dd['status']] ?? 'bg-secondary';
                    echo '<span class="badge ' . $sc . ' fs-6">' . e(ucwords(str_replace('_', ' ', $dd['status']))) . '</span>';
                    ?>
                </div>
            </div>

            <div class="alert alert-light border rounded-3 mb-2">
                <strong>Customer says:</strong> <?php echo e($dd['description']); ?>
            </div>
            <?php if ($dd['admin_note']): ?>
            <div class="alert alert-info border rounded-3 mb-2">
                <strong>Admin note:</strong> <?php echo e($dd['admin_note']); ?>
            </div>
            <?php endif; ?>

            <div class="card bg-light border rounded-3 mb-2 small">
                <div class="card-body py-2">
                    <strong class="small"><i class="fas fa-comments me-1"></i>Conversation (customer / provider / admin)</strong>
                    <?php echo dispute_thread_html(dispute_thread((int)$dd['dispute_id'])); ?>
                    <form method="POST" class="d-flex gap-2 align-items-center mt-2">
                        <input type="hidden" name="dispute_id" value="<?php echo (int)$dd['dispute_id']; ?>">
                        <input type="text" name="reply_message" class="form-control form-control-sm" placeholder="Reply to the customer & provider...">
                        <button name="action" value="reply" class="btn btn-sm btn-outline-danger text-nowrap"><i class="fas fa-paper-plane me-1"></i>Send</button>
                    </form>
                </div>
            </div>

            <form method="POST" class="row g-2 align-items-end">
                <input type="hidden" name="dispute_id" value="<?php echo (int)$dd['dispute_id']; ?>">
                <div class="col-md-3">
                    <label class="form-label small mb-1">Status</label>
                    <select name="status" class="form-select form-select-sm">
                        <?php foreach (['open', 'in_review', 'resolved', 'rejected'] as $st): ?>
                        <option value="<?php echo $st; ?>" <?php echo $dd['status'] === $st ? 'selected' : ''; ?>><?php echo ucwords(str_replace('_', ' ', $st)); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small mb-1">Refund amount if resolving (UGX)</label>
                    <input type="number" name="refund_amount" class="form-control form-control-sm" min="0" step="100" value="<?php echo (float)$dd['refund_amount']; ?>" placeholder="0">
                </div>
                <div class="col-md-5">
                    <label class="form-label small mb-1">Note for customer &amp; provider</label>
                    <input type="text" name="admin_note" class="form-control form-control-sm" value="<?php echo e($dd['admin_note'] ?? ''); ?>" placeholder="Resolution note...">
                </div>
                <div class="col-md-3">
                    <button name="action" value="update" class="btn btn-sm btn-primary w-100"><i class="fas fa-save me-1"></i>Update</button>
                </div>
                <div class="col-md-4">
                    <label class="form-check d-flex align-items-center small">
                        <input class="form-check-input me-2" type="checkbox" name="send_to_provider" value="1">
                        Also assign to provider for resolution (notifies them)
                    </label>
                </div>
                <div class="col-md-3">
                    <button name="action" value="delete" class="btn btn-sm btn-outline-danger w-100" onclick="return confirm('Delete this dispute record?');"><i class="fas fa-trash me-1"></i>Delete</button>
                </div>
            </form>
        </div>
        <?php endforeach; ?>
    </main>
</div></div>
<?php $close_layout = true; include BASE_PATH . '/php/partials/footer.php'; ?>