<?php
/**
 * Admin login - hardcoded credentials as specified.
 * Email: ryanhitmus@gmail.com | Password: 2224.Ryan
 */
$BASE = '../../';
require_once __DIR__ . '/../includes/session.php';

if (is_admin()) {
    redirect('dashboard.php');
}

if (isset($_GET['logout'])) {
    unset($_SESSION['admin_logged_in']);
    flash('success', 'Admin logged out.');
    redirect('login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    if ($email === ADMIN_EMAIL && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        session_regenerate_id(true);
        flash('success', 'Welcome, Admin!');
        redirect('dashboard.php');
    }
    $error = 'Invalid admin credentials.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/auth.css">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { background: linear-gradient(135deg, #03045e 0%, #023e8a 50%, #0077b6 100%); min-height: 100vh; display: flex; align-items: center; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="logo">
                <i class="fas fa-user-shield"></i>
                <h3>Admin Login</h3>
                <p class="text-muted">Restricted area</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?php echo e($error); ?></div>
            <?php endif; ?>
            <?php echo flash(); ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label">Admin Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Admin email" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Admin password" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-shield-alt me-2"></i>Login as Admin</button>
            </form>

            <div class="auth-footer">
                <a href="<?php echo $BASE; ?>index.php"><i class="fas fa-home me-1"></i>Back to Home</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
