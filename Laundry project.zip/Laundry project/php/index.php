<?php
/**
 * Compatibility entry point: this file lives at /php/index.php so that any
 * stale link (e.g. logout redirects or old bookmarks pointing to php/index.php)
 * reaches the real landing page at the project root.
 */
header('Location: ../index.php');
exit;
?>

