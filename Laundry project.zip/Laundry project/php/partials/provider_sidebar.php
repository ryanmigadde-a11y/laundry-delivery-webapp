<?php
/**
 * Provider dashboard sidebar.
 * Expects: $BASE, $active ('dashboard'|'orders'|'business'|'reviews'|'pay_fee'|'notifications'|'settings').
 */
$user = current_user();
$provider = get_provider_for_user($user['user_id']);
$unread = unread_count($user['user_id']);
$bizName = $provider['business_name'] ?? $user['full_name'];
function ps_link($key, $href, $icon, $label, $badge = null) {
    $active = ($GLOBALS['active'] ?? '') === $key ? ' active' : '';
    echo '<a href="' . $href . '" class="nav-link text-white' . $active . '"><i class="' . $icon . ' me-2"></i>' . $label;
    if ($badge) echo ' <span class="badge bg-danger ms-1">' . $badge . '</span>';
    echo '</a>';
}
?>
<div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark panel-sidebar" id="panelSidebar" style="width: 250px; min-height: 100vh;">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <a href="<?php echo $BASE; ?>php/provider/dashboard.php" class="d-flex align-items-center text-white text-decoration-none">
            <i class="fas fa-store fa-2x me-2"></i><span class="fs-5 fw-bold">Provider Panel</span>
        </a>
        <button type="button" class="btn-close btn-close-white d-lg-none sidebar-close" aria-label="Close menu"></button>
    </div>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <?php
        ps_link('dashboard', $BASE . 'php/provider/dashboard.php', 'fas fa-tachometer-alt', 'Dashboard');
        ps_link('orders', $BASE . 'php/provider/orders.php', 'fas fa-shopping-bag', 'Orders');
        ps_link('share_location', $BASE . 'php/provider/share_location.php', 'fas fa-location-crosshairs', 'Share Live Location');
        ps_link('business', $BASE . 'php/provider/business_settings.php', 'fas fa-store-alt', 'Business Settings');
        ps_link('reviews', $BASE . 'php/provider/reviews.php', 'fas fa-star', 'Reviews');
        ps_link('performance', $BASE . 'php/provider/performance.php', 'fas fa-chart-line', 'Performance Center');
        ps_link('disputes', $BASE . 'php/provider/disputes.php', 'fas fa-shield-halved', 'Disputes');
        ps_link('pay_fee', $BASE . 'php/provider/pay_fee.php', 'fas fa-money-bill-wave', 'Subscription');
        ps_link('notifications', $BASE . 'php/notifications.php', 'fas fa-bell', 'Notifications', $unread ?: null);
        ps_link('settings', $BASE . 'php/provider/settings.php', 'fas fa-cog', 'Settings');
        ?>
    </ul>
    <hr>
    <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
            <?php echo avatar_img($provider['profile_pic'] ?? null, $bizName, 32); ?><strong class="ms-2"><?php echo e($bizName); ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item" href="<?php echo $BASE; ?>php/provider/settings.php"><i class="fas fa-user me-2"></i>Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?php echo $BASE; ?>php/auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
        </ul>
    </div>
</div>
