<?php
/**
 * Customer dashboard sidebar.
 * Expects: $BASE, $active ('dashboard'|'orders'|'new_order'|'support'|'notifications'|'settings').
 */
$user = current_user();
$unread = unread_count($user['user_id']);
function cs_link($key, $href, $icon, $label, $badge = null) {
    $active = ($GLOBALS['active'] ?? '') === $key ? ' active' : '';
    echo '<a href="' . $href . '" class="nav-link text-white' . $active . '"><i class="' . $icon . ' me-2"></i>' . $label;
    if ($badge) echo ' <span class="badge bg-danger ms-1">' . $badge . '</span>';
    echo '</a>';
}
?>
<div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark panel-sidebar" id="panelSidebar" style="width: 250px; min-height: 100vh;">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <a href="<?php echo $BASE; ?>php/customer/dashboard.php" class="d-flex align-items-center text-white text-decoration-none">
            <i class="fas fa-tshirt fa-2x me-2"></i><span class="fs-5 fw-bold">Customer Panel</span>
        </a>
        <button type="button" class="btn-close btn-close-white d-lg-none sidebar-close" aria-label="Close menu"></button>
    </div>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <?php
        cs_link('dashboard', $BASE . 'php/customer/dashboard.php', 'fas fa-tachometer-alt', 'Dashboard');
        cs_link('orders', $BASE . 'php/customer/orders.php', 'fas fa-shopping-bag', 'My Orders');
        cs_link('new_order', $BASE . 'php/customer/new_order/select_provider.php', 'fas fa-plus-circle', 'New Order');
        if (feature_enabled('compare')) cs_link('compare', $BASE . 'php/customer/compare.php', 'fas fa-scale-balanced', 'Price Comparison');
        if (feature_enabled('recurring')) cs_link('recurring', $BASE . 'php/customer/schedules.php', 'fas fa-calendar-week', 'Auto Laundry Schedules');
        if (feature_enabled('locations')) cs_link('locations', $BASE . 'php/customer/locations.php', 'fas fa-map-marked-alt', 'Laundry Stations');
        cs_link('leaderboard', $BASE . 'php/customer/leaderboard.php', 'fas fa-ranking-star', 'Leaderboard');
        if (feature_enabled('wallet')) cs_link('wallet', $BASE . 'php/customer/wallet.php', 'fas fa-wallet', 'My Wallet');
        cs_link('receipts', $BASE . 'php/customer/receipts.php', 'fas fa-receipt', 'My Receipts');
        if (feature_enabled('disputes')) cs_link('disputes', $BASE . 'php/customer/disputes.php', 'fas fa-shield-halved', 'Laundry Protection');
        cs_link('support', $BASE . 'php/customer/support.php', 'fas fa-headset', 'Support');
        cs_link('notifications', $BASE . 'php/notifications.php', 'fas fa-bell', 'Notifications', $unread ?: null);
        cs_link('settings', $BASE . 'php/customer/settings.php', 'fas fa-cog', 'Settings');
        ?>
    </ul>
    <hr>
    <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
            <?php echo avatar_img($user['profile_pic'], $user['full_name'], 32); ?><strong class="ms-2"><?php echo e($user['full_name']); ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item" href="<?php echo $BASE; ?>php/customer/settings.php"><i class="fas fa-user me-2"></i>Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?php echo $BASE; ?>php/auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
        </ul>
    </div>
</div>
