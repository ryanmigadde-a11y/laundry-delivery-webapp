<?php
/**
 * Page header: <head>, CSS, top navbar.
 * Expects: $BASE, $page_title.
 * Optional: $extra_css (array), $load_chartjs (bool), $plain (bool - hide navbar).
 */
if (!isset($BASE)) $BASE = '../';
$page_title = $page_title ?? 'LaundryExpress Uganda';
$extra_css = $extra_css ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($page_title); ?> | LaundryExpress Uganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/dashboard.css">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/components.css">
    <link rel="stylesheet" href="<?php echo $BASE; ?>assets/css/landing.css">
    <?php foreach ($extra_css as $css): ?>
    <link rel="stylesheet" href="<?php echo $BASE . $css; ?>">
    <?php endforeach; ?>
    <?php if (!empty($load_chartjs)): ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php endif; ?>
    <style>* { font-family: 'Poppins', sans-serif; }</style>
</head>
<body>
<?php if (empty($plain)) include BASE_PATH . '/php/includes/navbar.php'; ?>
<?php echo flash(); // global flash messages ?>
