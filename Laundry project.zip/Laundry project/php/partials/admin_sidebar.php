<?php
/**
 * Admin dashboard sidebar.
  * Expects: $BASE, $active ('dashboard'|'users'|'orders'|'support'|'config'|'verification'|'promotions'|'analytics'|'audit'|'notifications').
 */
$unread = get_admin_unread_support();
function as_link($key, $href, $icon, $label, $badge = null) {
    $active = ($GLOBALS['active'] ?? '') === $key ? ' active' : '';
    echo '<a href="' . $href . '" class="nav-link text-white' . $active . '"><i class="' . $icon . ' me-2"></i>' . $label;
    if ($badge) echo ' <span class="badge bg-danger ms-1">' . $badge . '</span>';
    echo '</a>';
}
?>
<div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark panel-sidebar" id="panelSidebar" style="width: 250px; min-height: 100vh;">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <a href="<?php echo $BASE; ?>php/admin/dashboard.php" class="d-flex align-items-center text-white text-decoration-none">
            <i class="fas fa-shield-alt fa-2x me-2"></i><span class="fs-5 fw-bold">Admin Panel</span>
        </a>
        <button type="button" class="btn-close btn-close-white d-lg-none sidebar-close" aria-label="Close menu"></button>
    </div>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <?php
        as_link('dashboard', $BASE . 'php/admin/dashboard.php', 'fas fa-tachometer-alt', 'Dashboard');
        as_link('users', $BASE . 'php/admin/users.php', 'fas fa-users', 'Users');
                                as_link('orders', $BASE . 'php/admin/orders.php', 'fas fa-shopping-bag', 'Orders');
        as_link('support', $BASE . 'php/admin/support.php', 'fas fa-headset', 'Support', $unread ?: null);
        as_link('disputes', $BASE . 'php/admin/disputes.php', 'fas fa-shield-halved', 'Dispute Center');
        as_link('config', $BASE . 'php/admin/system_config.php', 'fas fa-cog', 'System Config');
        as_link('verification', $BASE . 'php/admin/verification.php', 'fas fa-user-check', 'Provider Verification');
        as_link('promotions', $BASE . 'php/admin/promotions.php', 'fas fa-gift', 'Promotions');
        as_link('analytics', $BASE . 'php/admin/analytics.php', 'fas fa-chart-bar', 'Analytics');
        as_link('audit', $BASE . 'php/admin/audit_log.php', 'fas fa-history', 'Audit Log');
        as_link('notifications', $BASE . 'php/notifications.php', 'fas fa-bell', 'Notifications');
        ?>
    </ul>
    <hr>
    <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
            <i class="fas fa-user-shield fa-2x me-2"></i><strong>Admin</strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-dark">
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?php echo $BASE; ?>php/admin/login.php?logout=1"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
        </ul>
    </div>
</div>
