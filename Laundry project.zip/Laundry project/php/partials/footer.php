<?php
/**
 * Page footer: closes the dashboard layout, loads scripts, closes body.
 * Expects: $BASE. Optional: $extra_scripts (array), $close_layout (bool, default true).
 */
$extra_scripts = $extra_scripts ?? [];
if (!isset($close_layout)) $close_layout = true;
?>
<?php if ($close_layout): ?>
        </main>
    </div>
</div>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $BASE; ?>assets/js/main.js"></script>
<?php foreach ($extra_scripts as $script): ?>
<script src="<?php echo $BASE . $script; ?>"></script>
<?php endforeach; ?>
</body>
</html>
