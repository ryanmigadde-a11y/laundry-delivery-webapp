<?php
/**
 * Live order tracking API - courier GPS sharing + polling.
 * POST order_id & lat & lng [& accuracy & speed & phase] -> store a GPS ping (provider only)
 * GET  ?order_id=X            -> latest courier position + trail (authorized session)
 * GET  ?token=UNIQUE_TOKEN    -> latest courier position + trail (public QR page)
 */
require_once __DIR__ . '/../includes/session.php';
header('Content-Type: application/json');

$pdo = $GLOBALS['pdo'];

/* Who may VIEW tracking for an order: customer owner, provider owner, admin,
   or anyone holding the order's unique QR token (public track page). */
function tracking_can_view($order, $token)
{
    if (!$order) return false;
    if ($token !== '' && hash_equals((string)$order['unique_order_token'], $token)) return true;
    if (!is_logged_in()) return false;
    if (is_admin()) return true;
    $user = current_user();
    if (!$user) return false;
    if ((int)$order['customer_id'] === (int)$user['user_id']) return true;
    if (($_SESSION['user_type'] ?? '') === 'provider' && (int)$order['provider_id'] === (int)$user['user_id']) return true;
    return false;
}

/* Load order by id or by public token. */
$orderId = (int)($_GET['order_id'] ?? $_POST['order_id'] ?? 0);
$token   = trim($_GET['token'] ?? '');

$order = null;
if ($orderId > 0) {
    $stmt = $pdo->prepare(
        'SELECT o.*, p.business_name, p.business_location, p.latitude AS station_lat, p.longitude AS station_lng
         FROM orders o JOIN providers p ON p.provider_id = o.provider_id WHERE o.order_id = ? LIMIT 1'
    );
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
} elseif ($token !== '') {
    $stmt = $pdo->prepare(
        'SELECT o.*, p.business_name, p.business_location, p.latitude AS station_lat, p.longitude AS station_lng
         FROM orders o JOIN providers p ON p.provider_id = o.provider_id WHERE o.unique_order_token = ? LIMIT 1'
    );
    $stmt->execute([$token]);
    $order = $stmt->fetch();
}

if (!$order || !tracking_can_view($order, $token)) {
    echo json_encode(['ok' => false, 'error' => is_logged_in() ? 'access_denied' : 'not_logged_in']);
    exit;
}

$orderId = (int)$order['order_id'];

/* ---- Share a GPS ping (provider only, only while the order is moving) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = current_user();
    if (!$user || (($_SESSION['user_type'] ?? '') !== 'provider' && !is_admin())
        || (int)$order['provider_id'] !== (int)$user['user_id']) {
        echo json_encode(['ok' => false, 'error' => 'access_denied']);
        exit;
    }
    if (!in_array($order['status'], ['active', 'in_progress', 'out_for_delivery'], true)) {
        echo json_encode(['ok' => false, 'error' => 'order_not_active']);
        exit;
    }

    $lat = $_POST['lat'] ?? null;
    $lng = $_POST['lng'] ?? null;
    $acc = is_numeric($_POST['accuracy'] ?? null) ? (float)$_POST['accuracy'] : null;
    $spd = is_numeric($_POST['speed'] ?? null) ? (float)$_POST['speed'] : null;

    /* Phase follows the order status: heading to the customer = pickup leg,
       everything else (cleaning at station, delivery) = delivery pin. */
    $phase = ($order['status'] === 'active') ? 'pickup' : 'delivery';

    $stored = record_order_location($orderId, $lat, $lng, $acc, $spd, $phase, (int)$user['user_id']);
    echo json_encode(['ok' => $stored, 'phase' => $phase, 'time' => date('c')]);
    exit;
}

/* ---- Poll current position + trail (customer / provider / admin / token) ---- */
$latest = latest_order_location($orderId, 900); /* live only if < 15 min old */
$trail  = order_location_trail($orderId, 120);

/* Pin the pickup point (customer address) with the shared Uganda dictionary. */
$pickup = ug_geo_find($order['pickup_address'] ?? '');
if (!$pickup) {
    $stmt = $pdo->prepare('SELECT location FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([(int)$order['customer_id']]);
    $pickup = ug_geo_find((string)$stmt->fetchColumn());
}

$stationPin = null;
if (is_numeric($order['station_lat']) && is_numeric($order['station_lng'])) {
    $stationPin = ['lat' => (float)$order['station_lat'], 'lng' => (float)$order['station_lng'], 'gps' => true];
} else {
    $g = ug_geo_find($order['business_location']);
    if ($g) $stationPin = ['lat' => $g['lat'], 'lng' => $g['lng'], 'gps' => false];
}

echo json_encode([
    'ok'       => true,
    'order'    => [
        'order_id'        => $orderId,
        'code'            => order_code($orderId),
        'status'          => $order['status'],
        'payment_status'  => $order['payment_status'],
        'business_name'   => $order['business_name'],
        'driver_name'     => $order['driver_name'] ?? null,
        'driver_phone'    => $order['driver_phone'] ?? null,
    ],
    'live'     => $latest !== null,
    'position' => $latest ? [
        'lat'      => (float)$latest['latitude'],
        'lng'      => (float)$latest['longitude'],
        'accuracy' => $latest['accuracy_m'] !== null ? (int)$latest['accuracy_m'] : null,
        'speed'    => $latest['speed_kmh'] !== null ? (float)$latest['speed_kmh'] : null,
        'phase'    => $latest['phase'],
        'at'       => $latest['recorded_at'],
        'age'      => (int)$latest['age_seconds'],
    ] : null,
    'trail'    => $trail,
    'station'  => $stationPin,
    'pickup'   => $pickup ? ['lat' => $pickup['lat'], 'lng' => $pickup['lng'], 'name' => $pickup['name']] : null,
]);
