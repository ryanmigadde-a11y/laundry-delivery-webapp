<?php
/**
 * Chat API - order-linked messaging with AJAX polling.
 * GET  ?order_id=X&after=Y  -> JSON list of new messages
 * POST order_id & message   -> send a message (JSON response)
 */
require_once __DIR__ . '/../includes/session.php';
header('Content-Type: application/json');

function api_user_can_access_order($order) {
    if (!$order) return false;
    if (is_admin()) return true;
    $user = current_user();
    if (!$user) return false;
    if ((int)$order['customer_id'] === (int)$user['user_id']) return true;
    if ($_SESSION['user_type'] === 'provider' && (int)$order['provider_id'] === (int)$user['user_id']) return true;
    return false;
}

if (!is_logged_in()) {
    echo json_encode(['ok' => false, 'error' => 'not_logged_in']);
    exit;
}

$orderId = (int)($_GET['order_id'] ?? $_POST['order_id'] ?? 0);
$stmt = $GLOBALS['pdo']->prepare('SELECT * FROM orders WHERE order_id = ? LIMIT 1');
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!api_user_can_access_order($order)) {
    echo json_encode(['ok' => false, 'error' => 'access_denied']);
    exit;
}

$userId = (int)$_SESSION['user_id'];

/* ---- Send a message ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message'] ?? '');
    if ($message === '') {
        echo json_encode(['ok' => false, 'error' => 'empty_message']);
        exit;
    }
    $stmt = $GLOBALS['pdo']->prepare('INSERT INTO chat_messages (order_id, sender_id, message) VALUES (?, ?, ?)');
    $stmt->execute([$orderId, $userId, $message]);
    echo json_encode(['ok' => true, 'message_id' => (int)$GLOBALS['pdo']->lastInsertId()]);
    exit;
}

/* ---- Poll for messages ---- */
$after = (int)($_GET['after'] ?? 0);
$stmt = $GLOBALS['pdo']->prepare(
    'SELECT m.message_id, m.sender_id, m.message, m.sent_at, u.full_name, u.user_type
     FROM chat_messages m JOIN users u ON u.user_id = m.sender_id
     WHERE m.order_id = ? AND m.message_id > ? ORDER BY m.message_id ASC LIMIT 200'
);
$stmt->execute([$orderId, $after]);

$messages = [];
foreach ($stmt->fetchAll() as $row) {
    $messages[] = [
        'id'         => (int)$row['message_id'],
        'mine'       => (int)$row['sender_id'] === $userId,
        'sender'     => $row['full_name'],
        'sender_type'=> $row['user_type'],
        'message'    => $row['message'],
        'time'       => date('h:i A, d M', strtotime($row['sent_at'])),
    ];
}

echo json_encode(['ok' => true, 'messages' => $messages]);
