<?php
/**
 * Mobile Money payment API.
 *
 * When MTN_MOMO_SIMULATE is false and the Collection keys are configured, the
 * real MTN MoMo RequestToPay API is called ("initiate" sends the USSD push,
 * the customer approves on their phone, and "confirm" returns the result).
 *
 * When simulating (default / localhost / MTN unreachable), it mirrors a real
 * aggregator push flow:
 *   action=initiate -> USSD prompt "sent" to the phone (status: pending)
 *   action=confirm  -> gateway callback confirming the PIN entry (status: success)
 *
 * purpose  = 'order'  -> externalId "ORD-..." (separate transaction stream)
 *          = 'wallet' -> externalId "WALLET-..." (separate transaction stream)
 *          = 'subscription' -> externalId "SUB-..." (provider monthly fee)
 */
require_once __DIR__ . '/../includes/session.php';
header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['ok' => false, 'error' => 'access_denied']);
    exit;
}

$action  = $_POST['action'] ?? '';
$token   = $_POST['order_token'] ?? $_POST['ref'] ?? '';
$purpose = in_array($_POST['purpose'] ?? '', ['order', 'wallet', 'subscription'], true)
    ? $_POST['purpose']
    : 'order';

if (!$token) {
    echo json_encode(['ok' => false, 'error' => 'missing_token']);
    exit;
}

if (!isset($_SESSION['mm_payments'])) {
    $_SESSION['mm_payments'] = [];
}

/* ---- helper: build a unique externalId per purpose ---- */
function _momo_ext_id($purposeKey, $token, $extra = '')
{
    $prefix = ['order' => 'ORD-', 'wallet' => 'WALLET-', 'subscription' => 'SUB-'][$purposeKey] ?? 'ORD-';
    return $prefix . substr($token, -8) . ($extra !== '' ? '-' . $extra : '');
}

if ($action === 'initiate') {
    $network = ($_POST['network'] ?? 'mtn') === 'airtel' ? 'airtel' : 'mtn';
    $phone   = trim($_POST['phone'] ?? '');
    $amount  = (float)($_POST['amount'] ?? 0);

    if ($phone === '') {
        echo json_encode(['ok' => false, 'error' => 'missing_phone']);
        exit;
    }

    /* ---- try the real MTN Collection API (only when live mode) ---- */
    if (momo_live() && momo_collection_configured()) {
        $msg   = $purpose === 'wallet'
                ? _momo_ext_id($purpose, $token) . ' Laundry Wallet topup payment'
                : ($purpose === 'subscription'
                    ? 'Provider subscription payment'
                    : 'Customer ' . _momo_ext_id($purpose, $token) . ' payment');
        $note  = $purpose === 'wallet'
                ? 'Payment for wallet-topup received'
                : ($purpose === 'subscription'
                    ? 'Subscription received'
                    : 'Payment for ' . _momo_ext_id($purpose, $token) . ' received');
        $res = momo_collect($amount, _momo_ext_id($purpose, $token), $phone, $msg, $note);
        if ($res[0]) {
            $_SESSION['mm_payments'][$token] = [
                'status'     => 'success',
                'network'    => 'mtn',
                'phone'      => $phone,
                'reference'  => $res[1],       // MTN financialTransactionId
                'purpose'    => $purpose,
                'amount'     => $amount,
                'ts'         => time(),
            ];
            echo json_encode([
                'ok'         => true,
                'status'     => 'success',
                'network_name' => 'MTN Mobile Money',
                'reference'  => $res[1],
                'ussd'       => '*165*00#',
            ]);
            exit;
        }
        echo json_encode(['ok' => false, 'error' => 'momo_failed', 'message' => $res[1]]);
        exit;
    }

    /* Airtel Money: no API keys supplied yet — always simulated. */
    if ($network === 'airtel') {
        $att = AIRTEL_MONEY_API_KEY && AIRTEL_MONEY_USERNAME;
        if ($att && !momo_live()) {
            /* placeholder for an Airtel gateway — leave simulated for now */
        }
    }

    /* ---- simulation (default on localhost) ---- */
    $_SESSION['mm_payments'][$token] = [
        'status'   => 'pending',
        'network'  => $network,
        'phone'    => $phone,
        'purpose'  => $purpose,
        'amount'   => $amount,
        'ts'       => time(),
    ];
    echo json_encode([
        'ok'           => true,
        'status'       => 'pending',
        'network_name' => $network === 'mtn' ? 'MTN Mobile Money' : 'Airtel Money',
        'ussd'         => $network === 'mtn' ? '*165*00#' : '*185*00#',
    ]);
    exit;
}

if ($action === 'confirm') {
    if (!isset($_SESSION['mm_payments'][$token])) {
        echo json_encode(['ok' => false, 'error' => 'no_pending_payment']);
        exit;
    }
    $p = $_SESSION['mm_payments'][$token];

    /* Real MTN already succeeded during "initiate" — return the stored result. */
    if (momo_live() && momo_collection_configured() && ($p['status'] ?? '') === 'success') {
        echo json_encode(['ok' => true, 'status' => 'success', 'reference' => $p['reference'] ?? '']);
        exit;
    }

    /* Simulated gateway callback: mark the payment as successful. */
    $_SESSION['mm_payments'][$token]['status'] = 'success';
    echo json_encode(['ok' => true, 'status' => 'success']);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'unknown_action']);
