<?php
/**
 * Provider live location API for the customer Laundry Stations map.
 * GET: logged-in customers receive approved, active provider stations.
 * POST: logged-in providers share GPS or stop sharing (action=stop).
 */
require_once __DIR__ . '/../includes/session.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

$pdo = $GLOBALS['pdo'];

function live_location_json($data, $status = 200)
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function ensure_live_location_table($pdo)
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS provider_live_locations (
        provider_id INT NOT NULL PRIMARY KEY,
        latitude DECIMAL(10,7) NOT NULL,
        longitude DECIMAL(10,7) NOT NULL,
        accuracy_m DECIMAL(8,2) NULL,
        is_sharing TINYINT(1) NOT NULL DEFAULT 1,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_provider_live_sharing (is_sharing, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

try {
    ensure_provider_location_columns();
    ensure_live_location_table($pdo);
} catch (Throwable $e) {
    live_location_json(['ok' => false, 'error' => 'database_setup_failed', 'message' => 'Could not prepare live location storage. Import database/upgrade_provider_live_location.sql and try again.'], 500);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_logged_in() || (($_SESSION['user_type'] ?? '') !== 'provider')) {
        live_location_json(['ok' => false, 'error' => 'provider_login_required'], 403);
    }

    $user = current_user();
    $providerId = (int)$user['user_id'];
    $action = trim((string)($_POST['action'] ?? 'update'));

    if ($action === 'stop') {
        $stmt = $pdo->prepare('UPDATE provider_live_locations SET is_sharing = 0, updated_at = NOW() WHERE provider_id = ?');
        $stmt->execute([$providerId]);
        live_location_json(['ok' => true, 'sharing' => false, 'message' => 'Live location sharing stopped.']);
    }

    $lat = filter_var($_POST['lat'] ?? null, FILTER_VALIDATE_FLOAT);
    $lng = filter_var($_POST['lng'] ?? null, FILTER_VALIDATE_FLOAT);
    $accuracy = filter_var($_POST['accuracy'] ?? null, FILTER_VALIDATE_FLOAT);

    if ($lat === false || $lng === false || $lat === null || $lng === null || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        live_location_json(['ok' => false, 'error' => 'invalid_coordinates'], 422);
    }

    $check = $pdo->prepare("SELECT p.provider_id FROM providers p JOIN users u ON u.user_id = p.provider_id WHERE p.provider_id = ? AND p.is_approved = 1 AND u.status = 'active' LIMIT 1");
    $check->execute([$providerId]);
    if (!$check->fetchColumn()) {
        live_location_json(['ok' => false, 'error' => 'provider_not_approved', 'message' => 'Your provider account must be approved and active before your live location can appear publicly.'], 403);
    }

    $stmt = $pdo->prepare("INSERT INTO provider_live_locations (provider_id, latitude, longitude, accuracy_m, is_sharing, updated_at)
        VALUES (?, ?, ?, ?, 1, NOW())
        ON DUPLICATE KEY UPDATE latitude = VALUES(latitude), longitude = VALUES(longitude), accuracy_m = VALUES(accuracy_m), is_sharing = 1, updated_at = NOW()");
    $stmt->execute([$providerId, $lat, $lng, ($accuracy === false || $accuracy === null) ? null : $accuracy]);
    live_location_json(['ok' => true, 'sharing' => true, 'updated_at' => date('c')]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    live_location_json(['ok' => false, 'error' => 'method_not_allowed'], 405);
}

if (!is_logged_in() || (($_SESSION['user_type'] ?? '') !== 'customer')) {
    live_location_json(['ok' => false, 'error' => 'customer_login_required'], 403);
}

$user = current_user();
$myLoc = ug_geo_find($user['location'] ?? '');
$myLat = $myLoc ? (float)$myLoc['lat'] : 0.3136;
$myLng = $myLoc ? (float)$myLoc['lng'] : 32.5811;

$sql = "SELECT p.provider_id, p.business_name, p.business_location, p.profile_pic,
               p.verification_status, p.latitude AS station_lat, p.longitude AS station_lng,
               COALESCE((SELECT AVG(r.rating) FROM reviews r WHERE r.provider_id = p.provider_id), 0) AS avg_rating,
               (SELECT COUNT(*) FROM orders o WHERE o.provider_id = p.provider_id AND o.status IN ('delivered','completed')) AS completed,
               l.latitude AS live_lat, l.longitude AS live_lng, l.accuracy_m AS live_accuracy,
               l.is_sharing, l.updated_at AS live_updated_at
        FROM providers p
        JOIN users u ON u.user_id = p.provider_id
        LEFT JOIN provider_live_locations l ON l.provider_id = p.provider_id
        WHERE p.is_approved = 1 AND u.status = 'active'
        ORDER BY p.business_name ASC";
$rows = $pdo->query($sql)->fetchAll();
$stations = [];
$now = time();
foreach ($rows as $p) {
    $liveTime = !empty($p['live_updated_at']) ? strtotime($p['live_updated_at']) : 0;
    $isLive = (int)($p['is_sharing'] ?? 0) === 1 && $liveTime > 0 && ($now - $liveTime) <= 120;
    $hasStationGps = is_numeric($p['station_lat']) && is_numeric($p['station_lng']);
    $fallback = ug_geo_find($p['business_location'] ?? '');
    $lat = $isLive ? (float)$p['live_lat'] : ($hasStationGps ? (float)$p['station_lat'] : ($fallback ? (float)$fallback['lat'] : 0.3136));
    $lng = $isLive ? (float)$p['live_lng'] : ($hasStationGps ? (float)$p['station_lng'] : ($fallback ? (float)$fallback['lng'] : 32.5811));
    $stations[] = [
        'provider_id' => (int)$p['provider_id'],
        'business_name' => (string)$p['business_name'],
        'business_location' => (string)$p['business_location'],
        'avg_rating' => (float)$p['avg_rating'],
        'completed' => (int)$p['completed'],
        'verified' => ($p['verification_status'] ?? '') === 'verified',
        'lat' => $lat,
        'lng' => $lng,
        'gps_set' => $isLive || $hasStationGps,
        'live' => $isLive,
        'live_updated_at' => $isLive ? $p['live_updated_at'] : null,
        'accuracy_m' => $isLive && is_numeric($p['live_accuracy']) ? (float)$p['live_accuracy'] : null,
        'km' => ug_geo_km($myLat, $myLng, $lat, $lng),
    ];
}
live_location_json(['ok' => true, 'stations' => $stations, 'server_time' => date('c')]);
